/**************************************************************************
   FILE          :    isr.h
 
   PURPOSE       :    interrupt service routine header.  
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _ISR_H
#define _ISR_H
 
/* ---------------------- macro defination ------------------------------------------------ */
#define MAX_NUM_EXT_INTERRUPTS           (4)
#define EXT_INTERRUPT_LEVEL              (0)
#define EXT_INTERRUPT_EDGE               (1)
#define EXT_INTERRUPT_LOW_LEVEL          (0)
#define EXT_INTERRUPT_HIGH_LEVEL         (1)
#define EXT_INTERRUPT_FALLING_EDGE       (2)
#define EXT_INTERRUPT_RISING_EDGE        (3) 
#define EXT_INTERRUPT_0_REQ_BIT_POS       (14)

#define EXT_INTERRUPT_SENSE_DATA_BIT_POS  (5)
#define EXT_INTERRUPT_REQ_DATA_BIT_POS    (4)

#define INTERRUPT_REQ_IRQ                 (0)
#define INTERRUPT_REQ_FIQ                 (1) 
 
#define VIC_VECTOR_ADDR(slot)           (VICVectAddr##slot) 
#define VIC_VECTOR_CTRL(slot)           (VICVectCntl##slot)

#define ISR_EXT_INTERRUPT(ext_interrupt_id) (unsigned long int) (ISR_Ext_Interrupt_##ext_interrupt_id)
  
/* ---------------------- data type defination -------------------------------------------- */
  
/* -------------------- public variable declaration --------------------------------------- */

/* -------------------- public function declaration --------------------------------------- */
unsigned long int IRQ_Ext_Interrupt(const uint8_t ext_interrupt_id);
uint16_t Init_Ext_Interrupt(const uint8_t ctrl_ext_interrupt, const uint8_t vector_priority);
void ISR_Ext_Interrupt_0(void) __irq;
void ISR_Ext_Interrupt_1(void) __irq;
void ISR_Ext_Interrupt_2(void) __irq;
void ISR_Ext_Interrupt_3(void) __irq;

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
