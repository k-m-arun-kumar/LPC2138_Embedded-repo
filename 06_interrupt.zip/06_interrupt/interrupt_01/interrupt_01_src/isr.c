/* ********************************************************************
FILE                  : isr.c

PURPOSE               : interrupt service routine.  
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 13

*****************************************************************************/
#include "main.h"

#ifdef EXT_INTERRUPT_MOD_ENABLE
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
 
/* ----------------------------- global variable declaration -------------------- */

/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_0

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.01

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_0(void) __irq
{
	 EXTINT |=  (1 << 0); 
	 VICVectAddr = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_1

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.02

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_1(void) __irq
{
	static uint8_t num_ext_intp_1_triggered = 0; 
	
	 switch(cur_state_intp_led)
	 {
		 case STATE_LOW:
		    IO_Channel_Write(INTERRUPT_LED_IO_CH, STATE_HIGH);
			cur_state_intp_led = STATE_HIGH;
		 break;
         case STATE_HIGH:
           	IO_Channel_Write(INTERRUPT_LED_IO_CH, STATE_LOW);
			cur_state_intp_led = STATE_LOW;	
         break; 			
	 }
	 #ifdef TRACE
	   Print("\r Num ISR EXT INTERRUPT 1 called: %u", ++num_ext_intp_1_triggered);
	 #endif
	 EXTINT |= (1 << 1); 
	 VICVectAddr = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_2

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.03

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_2(void) __irq
{
	static uint8_t num_ext_intp_2_triggered = 0; 
	
	IO_Channel_Write(INTERRUPT_LED_IO_CH, STATE_LOW);
	cur_state_intp_led = STATE_LOW;	
	#ifdef TRACE
	   Print("\r Num ISR EXT INTERRUPT 2 called: %u", ++num_ext_intp_2_triggered);
	 #endif
	 EXTINT |= (1 << 2); 
	 VICVectAddr = 0;
}


/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Ext_Interrupt_3

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.04

BUGS           :    
-*------------------------------------------------------------*/
 void ISR_Ext_Interrupt_3(void) __irq
{
	 EXTINT |= (1 << 3); 
	 VICVectAddr = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Init_Ext_Interrupt

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.05

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Init_Ext_Interrupt(const uint8_t ctrl_ext_interrupt, const uint8_t vector_priority)  
{
	uint8_t ext_interrupt_id = ctrl_ext_interrupt & 0x03, ext_interrupt_id_io_ch, ext_interrupt_req, ret_status;
		
    switch(ext_interrupt_id)
    {
        case CH_ID_00:
           ext_interrupt_id_io_ch = CH_ID_01; 
        break;
        case CH_ID_01:
	       ext_interrupt_id_io_ch = CH_ID_03;
        break;
        case CH_ID_02:
	       ext_interrupt_id_io_ch = CH_ID_07;
        break;
        case CH_ID_03:
	       ext_interrupt_id_io_ch = CH_ID_09;
        break;      
    }
	if((ret_status = Non_GPIO_Func_Set(ext_interrupt_id_io_ch, IO_FUNC_MODE_03)) != SUCCESS)
	{
	     sys_error_or_warning_flag = ERR_EXT_INTERRUPT_INIT;
	     Error_or_Warning_Proc("13.05.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	VICIntEnClr |= (1 << (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id));
	switch(ctrl_ext_interrupt >> EXT_INTERRUPT_SENSE_DATA_BIT_POS)
	{
		case EXT_INTERRUPT_LOW_LEVEL:
		   EXTMODE &= ~(1 << ext_interrupt_id);
		   EXTPOLAR &= ~(1 << ext_interrupt_id);
		break;
		case EXT_INTERRUPT_HIGH_LEVEL:
		    EXTMODE &= ~(1 << ext_interrupt_id);
			EXTPOLAR |= (1 << ext_interrupt_id);
		break;
		case EXT_INTERRUPT_FALLING_EDGE:
		    EXTMODE |= (1 << ext_interrupt_id);
			EXTPOLAR &= ~(1 << ext_interrupt_id);
		break;
		case EXT_INTERRUPT_RISING_EDGE:
		    EXTMODE |= (1 << ext_interrupt_id);
			EXTPOLAR |= (1 << ext_interrupt_id);
		break;
		default:
		   sys_error_or_warning_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("13.05.02", ERROR_OCCURED, sys_error_or_warning_flag);
		   return sys_error_or_warning_flag;
	} 
    ext_interrupt_req = (ctrl_ext_interrupt >> EXT_INTERRUPT_REQ_DATA_BIT_POS) & 0x01;
    if(ext_interrupt_req == INTERRUPT_REQ_IRQ)
	{
		//IRQ
        VICIntSelect &= ~(1 << (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id));
		switch(vector_priority)
		{
			case 0:
			  VIC_VECTOR_ADDR(0) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(0) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break; 
			case 1:
			  VIC_VECTOR_ADDR(1) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(1) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 2:
			  VIC_VECTOR_ADDR(2) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(2) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 3:
			  VIC_VECTOR_ADDR(3) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(3) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 4:
			  VIC_VECTOR_ADDR(4) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(4) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 5:
			  VIC_VECTOR_ADDR(5) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(5) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 6:
			  VIC_VECTOR_ADDR(6) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(6) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 7:
			  VIC_VECTOR_ADDR(7) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(7) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 8:
			  VIC_VECTOR_ADDR(8) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(8) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 9:
			  VIC_VECTOR_ADDR(9) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(9) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 10:
			  VIC_VECTOR_ADDR(10) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(10) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 11:
			  VIC_VECTOR_ADDR(11) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(11) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 12:
			  VIC_VECTOR_ADDR(12) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(12) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 13:
			  VIC_VECTOR_ADDR(13) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(13) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 14:
			  VIC_VECTOR_ADDR(14) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(14) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			case 15:
			  VIC_VECTOR_ADDR(15) = IRQ_Ext_Interrupt(ext_interrupt_id);
			  VIC_VECTOR_CTRL(15) = (1<<5) | (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id);
			break;
			default:
			   sys_error_or_warning_flag = ERR_IRQ_VECTOR_SLOT;
		       Error_or_Warning_Proc("13.05.03", ERROR_OCCURED, sys_error_or_warning_flag);
		       return sys_error_or_warning_flag;
		}
		
	}
    else
	{
		//FIQ
		VICIntSelect |= (1 << (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id));
	}	
    EXTINT |= (1 << ext_interrupt_id);        
    VICIntEnable |= (1 << (EXT_INTERRUPT_0_REQ_BIT_POS + ext_interrupt_id));    	
    return SUCCESS;  
}

/*------------------------------------------------------------*
FUNCTION NAME  : IRQ_Ext_Interrupt

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 13.06

BUGS           :    
-*------------------------------------------------------------*/
unsigned long int IRQ_Ext_Interrupt(const uint8_t ext_interrupt_id)
{
	switch(ext_interrupt_id)
	{
		case CH_ID_00:
           return ISR_EXT_INTERRUPT(0);
       // break;
        case CH_ID_01:
		   return ISR_EXT_INTERRUPT(1);
       // break;
       case CH_ID_02:
		  return ISR_EXT_INTERRUPT(2);
       // break;
       case CH_ID_03:
		  return ISR_EXT_INTERRUPT(3);
       // break;       
	}
	sys_error_or_warning_flag = ERR_DEV_CH_ID_EXCEEDS;
	Error_or_Warning_Proc("13.06.01", ERROR_OCCURED, sys_error_or_warning_flag);
	return sys_error_or_warning_flag;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
