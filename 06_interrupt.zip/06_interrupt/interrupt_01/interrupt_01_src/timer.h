/**************************************************************************
   FILE          :    timer.h
 
   PURPOSE       :    timer header.  
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _TIMER_H
#define _TIMER_H

 
/* ---------------------- macro defination ------------------------------------------------ */
#define TMR_OR_COUNTER_STOP_STATE                  (0X1F)
#define TMR_PRESET_TIME_DELAY_IN_MULTIPLE            (0U)
#define TMR_POSTSET_TIME_DELAY_IN_MULTIPLE           (1U) 

#define TIMER_MODE                                    (0)
#define COUNTER_MODE                                  (1)

/* ---------------------- data type defination -------------------------------------------- */
 typedef struct
 {
	 uint8_t timer_or_counter_id;
	 uint8_t mode_type                      : 1;
	 uint8_t expiry_service_type            : 1;
     uint8_t                                : 6;
     uint16_t conf_timeout_in_ms_or_max_count; 
 } timer_or_counter_ctrl_t;

 typedef struct
 {
	 uint16_t actual_timeout_in_ms_or_max_count;
	 uint16_t cur_elapsed_time_in_ms_or_count;	
	 uint8_t timer_or_counter_cur_run_id; 
	 uint8_t timer_or_counter_last_run_id_before_stop;
     uint8_t timer_timeout_occured_flag	        : 1;
	 uint8_t                                    : 7; 
 } timer_or_counter_status_t;
 
/* -------------------- public variable declaration --------------------------------------- */
extern timer_or_counter_ctrl_t timer_or_counter_ctrl[];
extern timer_or_counter_status_t timer_or_counter_status[];

/* -------------------- public function declaration --------------------------------------- */
uint8_t Timer_Run(const uint8_t timer_ch_id, const uint8_t set_timer_run_id); 
uint8_t Timer_Stop(const uint8_t timer_ch_id );

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
