/* ********************************************************************
FILE                   : timer.c

PURPOSE                :  Timer library 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 12

*****************************************************************************/
#include "main.h"

#ifdef TIMER_MOD_ENABLE

/* ------------------------------ macro defination ------------------------------ */
        

/* ----------------------------- global variable defination --------------------- */
static uint8_t volatile *const tmr_ctcr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint8_t *) &T0CTCR, (uint8_t *) &T1CTCR };
static uint32_t volatile *const tmr_pr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0PR, (uint32_t *) &T1PR };
static uint8_t volatile *const tmr_tcr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint8_t *) &T0TCR, (uint8_t *) &T1TCR };
static uint32_t volatile *const tmr_tc_ptr[NUM_TIMER_DEV_ID_CHS] =   {(uint32_t *) &T0TC, (uint32_t *) &T1TC};
/*static uint32_t volatile *const tmr_mr_ptr[NUM_TIMER_DEV_ID_CHS][NUM_MATCH_REGS] = {
	                                                                     {(uint32_t *) &T0MR0, (uint32_t *) &T0MR1, (uint32_t *) &T0MR2,(uint32_t *) &T0MR3},
                                                                         {(uint32_t *) &T1MR0, (uint32_t *) &T1MR1, (uint32_t *) &T1MR2,(uint32_t *) &T1MR3}
                                                                      }; */
static uint32_t volatile *const tmr0_mr_ptr[NUM_MATCH_REGS] = {(uint32_t *) &T0MR0, (uint32_t *) &T0MR1, (uint32_t *) &T0MR2,(uint32_t *) &T0MR3};																	  
static uint32_t volatile *const tmr1_mr_ptr[NUM_MATCH_REGS] = {(uint32_t *) &T1MR0, (uint32_t *) &T1MR1, (uint32_t *) &T1MR2,(uint32_t *) &T1MR3};
uint16_t volatile *const tmr_mcr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint16_t *) &T0MCR, (uint16_t *) &T1MCR};
//static uint32_t volatile *const *timer_mr_ptr[NUM_TIMER_DEV_ID_CHS] = {tmr0_mr_ptr, tmr1_mr_ptr};
timer_or_counter_status_t timer_or_counter_status[NUM_TIMER_DEV_ID_CHS];
 
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
uint32_t volatile *const *Tmr_Match_Ptr(const uint8_t timer_id);

/* ----------------------------- function pointer defination -------------------- */
typedef uint16_t (*timer_timeout_func_ptr_t)(const uint8_t timer_cur_run_id);
timer_timeout_func_ptr_t Timer_Timeout_Proc_Func_Ptr[NUM_TIMER_DEV_ID_CHS] = {Timer_0_Timeout_Proc, Timer_1_Timeout_Proc}; 

/*------------------------------------------------------------*
FUNCTION NAME  : Timer_Run

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : XTAL_FREQ = 12MHz, CCLK = 60 MHz, PCLK = 15MHz 

Func ID        : 12.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Timer_Run(const uint8_t timer_ch_id, const uint8_t set_timer_run_id)
{
	timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
	timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
	uint16_t ret_status;
	uint8_t timer_tick, timer_remainder, timeout_proc_flag = STATE_YES;
	
	if(set_timer_run_id >= NUM_TIMER_AND_COUNTER_IDS )
	{
		 sys_error_or_warning_flag = ERR_TIMER_ID_EXCEEDS;
		 Error_or_Warning_Proc("12.01.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	if((ret_status = Timer_Stop(timer_ch_id)) != SUCCESS)
  {
     sys_error_or_warning_flag = ERR_TIMER_STOP_PROC;
		 Error_or_Warning_Proc("12.01.02", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag; 
  }
	cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + set_timer_run_id;
	cur_timer_or_counter_status_ptr = timer_or_counter_status + timer_ch_id;
	cur_timer_or_counter_status_ptr->timer_or_counter_last_run_id_before_stop = cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id =  set_timer_run_id;
	if(cur_timer_or_counter_ctrl_ptr->mode_type == TIMER_MODE)
	{
		    switch(timer_ch_id)
		    {
		    	case CH_ID_00:		
			       timer_tick = TIMER0_TICK_IN_MILLI_SEC;
			    break;			
			    case CH_ID_01:		
			       timer_tick = TIMER1_TICK_IN_MILLI_SEC;
			    break;
		     }		
		     timer_remainder = cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count % timer_tick;
         if(timer_remainder == 0)
		     {
		      	cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count = cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count;
		     } 
             else
		     {			 
		          // set_timer_req_time_delay_in_ms is not in multiples of timer_tick
		          #if TIMER_SET_TIME_DELAY_IN_MULTIPLE == TIMER_PRESET_TIME_DELAY_IN_MULTIPLE
		             //actual_timeout_in_ms_or_max_count is previous valid req_time_delay_in_milli_sec, which is multiple of timer_tick
		             cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count = cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count - timer_remainder;
		          #else //TIMER_SET_TIME_DELAY_IN_MULTIPLE == TIMER_POSTSET_TIME_DELAY_IN_MULTIPLE
		             //actual_timeout_in_ms_or_max_count is next valid req_time_delay_in_milli_sec, which is multiple of timer_tick
                     cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count =  cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count + timer_tick - timer_remainder ;	
                  #endif	
		     }
			 *tmr_ctcr_ptr[timer_ch_id] = 0x00; // Timer mode, increment on every rising edge 
	         *tmr_pr_ptr[timer_ch_id] = (timer_tick * 1000 - 1) ; // Load Pre-Scalar counter with timer_tick (0 to 14 = 15), so that timer counts every 1msec 
			 *tmr_mcr_ptr[timer_ch_id] = 0;
			 cur_timer_or_counter_status_ptr->cur_num_timeouts = 0;
			 cur_timer_or_counter_status_ptr->timer_timeout_occured_flag = STATE_NO;
			 //TC and PC will reset, if MR matches the TC.
			 *tmr_mcr_ptr[timer_ch_id] |= (1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));
			// *tmr_mr_ptr[timer_ch_id][cur_timer_or_counter_ctrl_ptr->match_or_capture_id] = cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count;
       // *timer_mr_ptr[timer_ch_id][cur_timer_or_counter_ctrl_ptr->match_or_capture_id] = cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count;
        *tmr1_mr_ptr[cur_timer_or_counter_ctrl_ptr->match_or_capture_id] = cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count; 
			 if(cur_timer_or_counter_ctrl_ptr->match_interrupt_or_capture_rising_flag == STATE_YES)
	         {
				 //EXPIRY_SERVICE_INTERRUPT
              if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts == 1)
              {                
				      	 *tmr_mcr_ptr[timer_ch_id] &= ~(1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));
				        	//TC and PC will stop and TCR[0]= 0 if MR matches the TC.					
				        	*tmr_mcr_ptr[timer_ch_id] |= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));	
              }
              else
              {                 
                  *tmr_mcr_ptr[timer_ch_id] &= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));	
                // TC and PC will reset and TCR[0]= 0 if MR matches the TC.					
                  *tmr_mcr_ptr[timer_ch_id] |= (1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));	
              }
				 *tmr_mcr_ptr[timer_ch_id] |= (1 << (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id));	
				 if(cur_timer_or_counter_status_ptr->exec_timer_init_interrupt_proc == STATE_NO)
				 {
				    if((ret_status =  Init_Interrupt(INTP_REQ_TMR0 + timer_ch_id)) != SUCCESS)
	                {
	            	    sys_error_or_warning_flag = ERR_INTERRUPT_INIT;
	            	    Error_or_Warning_Proc("12.01.04", ERROR_OCCURED, sys_error_or_warning_flag);
		                return sys_error_or_warning_flag;
	                }
				    cur_timer_or_counter_status_ptr->exec_timer_init_interrupt_proc = STATE_YES;
				 }
				  *tmr_tcr_ptr[timer_ch_id] = 0x01;  		  // Enable timer 
	         }
             else
			 {
				// EXPIRY_SERVICE_POLLING 
          if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts != NO_NUM_COUNT_TIMEOUTS)  
          {            
              if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts == 1)
              {                
				      	 *tmr_mcr_ptr[timer_ch_id] &= ~(1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));
				        	//TC and PC will stop and TCR[0]= 0 if MR matches the TC.					
				        	*tmr_mcr_ptr[timer_ch_id] |= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));	
              }
              else
              {                 
                  *tmr_mcr_ptr[timer_ch_id] &= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));	
                // TC and PC will reset and TCR[0]= 0 if MR matches the TC.					
                  *tmr_mcr_ptr[timer_ch_id] |= (1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));	
              }
         }
        *tmr_mcr_ptr[timer_ch_id] &= ~(1 << (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id));	    
			  *tmr_tcr_ptr[timer_ch_id] = 0x01;  		  // Enable timer 
				do 
				{
          //	while(*tmr_tc_ptr[timer_ch_id] != *(tmr_mr_ptr[timer_ch_id][cur_timer_or_counter_ctrl_ptr->match_or_capture_id]));
            //  while(*tmr_tc_ptr[timer_ch_id] != *timer_mr_ptr[timer_ch_id][cur_timer_or_counter_ctrl_ptr->match_or_capture_id]);
			       
           while(*tmr_tc_ptr[timer_ch_id] != *tmr1_mr_ptr[cur_timer_or_counter_ctrl_ptr->match_or_capture_id]);
		            if((ret_status = (*Timer_Timeout_Proc_Func_Ptr[timer_ch_id])(cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id)) != SUCCESS)
					{
								Timer_Stop(timer_ch_id);
						    	sys_error_or_warning_flag = ERR_TIMEOUT_PROC;
		                        Error_or_Warning_Proc("12.01.05", ERROR_OCCURED, sys_error_or_warning_flag);
		                        return sys_error_or_warning_flag;
					}
					if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts != NO_NUM_COUNT_TIMEOUTS)
			        {
						++cur_timer_or_counter_status_ptr->cur_num_timeouts;
				    	if(cur_timer_or_counter_status_ptr->cur_num_timeouts == cur_timer_or_counter_ctrl_ptr->max_num_timeouts - 1)
				    	{
					        	*tmr_mcr_ptr[timer_ch_id] &= ~(1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));
					         	//TC and PC will stop and TCR[0]= 0 if MR matches the TC.
				            *tmr_mcr_ptr[timer_ch_id] |= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));     					    
					    }					    			    
			        }
			    } while(cur_timer_or_counter_ctrl_ptr->max_num_timeouts == NO_NUM_COUNT_TIMEOUTS || cur_timer_or_counter_status_ptr->cur_num_timeouts < cur_timer_or_counter_ctrl_ptr->max_num_timeouts);
          if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts != NO_NUM_COUNT_TIMEOUTS) 
          {
               Timer_Stop(timer_ch_id);            
          }
		  }
	 }
	 return SUCCESS;	
}
 
/*------------------------------------------------------------*
FUNCTION NAME  : Timer_Stop

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : XTAL_FREQ = 12MHz, CCLK = 60 MHz, PCLK = 15MHz 

Func ID        : 12.02

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Timer_Stop(const uint8_t timer_ch_id )
{	
  timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
  timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
  
	if(timer_ch_id >= NUM_TIMER_DEV_ID_CHS)
	{
		 sys_error_or_warning_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("12.02.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
   cur_timer_or_counter_status_ptr = timer_or_counter_status + timer_ch_id;
   cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id;
   cur_timer_or_counter_status_ptr->timer_or_counter_last_run_id_before_stop = cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id;
   *tmr_mcr_ptr[timer_ch_id] &= ~(7 << (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id));			
   /* When one, the Timer Counter and the Prescale Counter are synchronously reset on the next positive edge of
     PCLK. The counters remain reset until TCR[1] is returned to zero. */  
   *tmr_tcr_ptr[timer_ch_id] = 0x03;  
   *tmr_tcr_ptr[timer_ch_id] = 0x00; // Stop timer 
	 cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id = TMR_OR_COUNTER_STOP_STATE;
   cur_timer_or_counter_status_ptr->cur_num_timeouts = 0;
   return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Timer_0

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : XTAL_FREQ = 12MHz, CCLK = 60 MHz, PCLK = 15MHz 

Func ID        : 12.03

BUGS           :    
-*------------------------------------------------------------*/
void ISR_Timer_0(void) __irq
{
	timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
	timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
	uint16_t ret_status;
		
	cur_timer_or_counter_status_ptr = timer_or_counter_status + CH_ID_00;
	cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id;
  
  ++cur_timer_or_counter_status_ptr->cur_num_timeouts;
  if((ret_status = Timer_0_Timeout_Proc(cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id)) != SUCCESS)
	{
		    Timer_Stop(CH_ID_00);
			  sys_error_or_warning_flag = ERR_TIMEOUT_PROC;
		    Error_or_Warning_Proc("12.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
	 }
   if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts != NO_NUM_COUNT_TIMEOUTS)
		{
				if(cur_timer_or_counter_status_ptr->cur_num_timeouts < cur_timer_or_counter_ctrl_ptr->max_num_timeouts - 1)
				{
                   ;
                }
				else if(cur_timer_or_counter_status_ptr->cur_num_timeouts == cur_timer_or_counter_ctrl_ptr->max_num_timeouts - 1)
				    	{
					    	*tmr_mcr_ptr[CH_ID_00] &= ~(1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));
					    	//TC and PC will stop and TCR[0]= 0 if MR matches the TC.
				        *tmr_mcr_ptr[CH_ID_00] |= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));     					    
					    }              
              else
              {
                 Timer_Stop(CH_ID_00);						
				         cur_timer_or_counter_status_ptr->timer_timeout_occured_flag = STATE_YES;                                
			        }					    
		}
    else
	  {
		     Timer_Stop(CH_ID_00);
	  } 
    T0IR = (1 << cur_timer_or_counter_ctrl_ptr->match_or_capture_id); //Write back to IR to clear Interrupt Flag	    
  	VICVectAddr = 0x0; //This is to signal end of interrupt execution
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_Timer_1

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : XTAL_FREQ = 12MHz, CCLK = 60 MHz, PCLK = 15MHz 

Func ID        : 12.04

BUGS           :    
-*------------------------------------------------------------*/
void ISR_Timer_1(void) __irq
{
	timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
	timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
	uint16_t ret_status; 
  
	cur_timer_or_counter_status_ptr = timer_or_counter_status + CH_ID_01;
	cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id;
    ++cur_timer_or_counter_status_ptr->cur_num_timeouts;
	if(cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id != TMR_OR_COUNTER_STOP_STATE)
	{
    	if((ret_status = Timer_1_Timeout_Proc(cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id)) != SUCCESS)
	    {
		    Timer_Stop(CH_ID_01);
			  sys_error_or_warning_flag = ERR_TIMEOUT_PROC;
		    Error_or_Warning_Proc("12.04.01", ERROR_OCCURED, sys_error_or_warning_flag);
	   	}
        if(cur_timer_or_counter_ctrl_ptr->max_num_timeouts != NO_NUM_COUNT_TIMEOUTS)
		    {
				if(cur_timer_or_counter_status_ptr->cur_num_timeouts < cur_timer_or_counter_ctrl_ptr->max_num_timeouts - 1)
				{
                   ;
                }
				else if(cur_timer_or_counter_status_ptr->cur_num_timeouts == cur_timer_or_counter_ctrl_ptr->max_num_timeouts - 1)
				    	{
					    	*tmr_mcr_ptr[CH_ID_01] &= ~(1 << (1 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));
					    	//TC and PC will stop and TCR[0]= 0 if MR matches the TC.
				        *tmr_mcr_ptr[CH_ID_01] |= (1 << (2 + (3 * cur_timer_or_counter_ctrl_ptr->match_or_capture_id)));     					    
					    }              
              else
              {
                 Timer_Stop(CH_ID_01);						
				         cur_timer_or_counter_status_ptr->timer_timeout_occured_flag = STATE_YES;                                
					    }					    
		} 
	}
	else
	{
		  Timer_Stop(CH_ID_01);
	} 
  
	T1IR = (1 << cur_timer_or_counter_ctrl_ptr->match_or_capture_id); //Write back to IR to clear Interrupt Flag	    
	VICVectAddr = 0x0; //This is to signal end of interrupt execution
}

#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
