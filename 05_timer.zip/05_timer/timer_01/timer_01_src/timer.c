/* ********************************************************************
FILE                   : timer.c

PURPOSE                :  Timer library 
	 
AUTHOR                :   K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 12

*****************************************************************************/
#include "main.h"

#ifdef TIMER_MOD_ENABLE

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
static uint8_t volatile *const tmr_ctcr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint8_t *) &T0CTCR, (uint8_t *) &T1CTCR };
static uint32_t volatile *const tmr_tc_ptr[NUM_TIMER_DEV_ID_CHS] =   {(uint32_t *) &T0TC, (uint32_t *) &T1TC };
static uint32_t volatile *const tmr_pc_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0PC, (uint32_t *) &T1PC };
static uint32_t volatile *const tmr_pr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0PR, (uint32_t *) &T1PR };
static uint8_t volatile *const tmr_tcr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint8_t *) &T0TCR, (uint8_t *) &T1TCR };
static uint32_t volatile *const tmr_mr0_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0MR0, (uint32_t *) &T1MR0};
static uint32_t volatile *const tmr_mr1_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0MR1, (uint32_t *) &T1MR1};
static uint32_t volatile *const tmr_mr2_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0MR2, (uint32_t *) &T1MR2};
static uint32_t volatile *const tmr_mr3_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint32_t *) &T0MR3, (uint32_t *) &T1MR3};
static uint16_t volatile *const tmr_mcr_ptr[NUM_TIMER_DEV_ID_CHS] = {(uint16_t *) &T0MCR, (uint16_t *) &T1MCR};

timer_or_counter_status_t timer_or_counter_status[NUM_TIMER_DEV_ID_CHS];
 
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Timer_Run

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : XTAL_FREQ = 12MHz, CCLK = 60 MHz, PCLK = 15MHz 

Func ID        : 12.01

BUGS           :    
-*------------------------------------------------------------*/
 uint8_t Timer_Run(const uint8_t timer_ch_id, const uint8_t set_timer_run_id)
{
	timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
	timer_or_counter_ctrl_t  *cur_timer_or_counter_ctrl_ptr;
	uint8_t timer_tick, timer_remainder;
	
	if(timer_ch_id >= NUM_TIMER_DEV_ID_CHS)
	{
		 sys_error_or_warning_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("12.01.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	if(set_timer_run_id >= NUM_TIMER_AND_COUNTER_IDS )
	{
		 sys_error_or_warning_flag = ERR_TIMER_ID_EXCEEDS;
		 Error_or_Warning_Proc("12.01.02", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	cur_timer_or_counter_ctrl_ptr = timer_or_counter_ctrl + set_timer_run_id;
	cur_timer_or_counter_status_ptr = timer_or_counter_status + timer_ch_id;
	cur_timer_or_counter_status_ptr->timer_or_counter_last_run_id_before_stop = cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id =  set_timer_run_id;
	if(cur_timer_or_counter_ctrl_ptr->expiry_service_type == EXPIRY_SERVICE_POLLING)
	{
		if(cur_timer_or_counter_ctrl_ptr->mode_type == TIMER_MODE)
		{
		    switch(timer_ch_id)
		    {
		    	case CH_ID_00:		
			       timer_tick = TIMER0_TICK_IN_MILLI_SEC;
			    break;			
			    case CH_ID_01:		
			       timer_tick = TIMER1_TICK_IN_MILLI_SEC;
			    break;
		     }		
		     cur_timer_or_counter_status_ptr->timer_timeout_occured_flag = STATE_NO;
	         timer_remainder = cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count % timer_tick;
             if(timer_remainder == 0)
		     {
		      	cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count = cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count;
		     } 
             else
		     {			 
		          // set_timer_req_time_delay_in_ms is not in multiples of timer_tick
		          #if TIMER_SET_TIME_DELAY_IN_MULTIPLE == TIMER_PRESET_TIME_DELAY_IN_MULTIPLE
		             //actual_timeout_in_ms_or_max_count is previous valid req_time_delay_in_milli_sec, which is multiple of timer_tick
		             cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count = cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count - timer_remainder;
		          #else //TIMER_SET_TIME_DELAY_IN_MULTIPLE == TIMER_POSTSET_TIME_DELAY_IN_MULTIPLE
		             //actual_timeout_in_ms_or_max_count is next valid req_time_delay_in_milli_sec, which is multiple of timer_tick
                     cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count =  cur_timer_or_counter_ctrl_ptr->conf_timeout_in_ms_or_max_count + timer_tick - timer_remainder ;	
                  #endif	
		     }
			 *tmr_tcr_ptr[timer_ch_id] = 0x02; // disable timer and Reset TC and PR 
	         *tmr_ctcr_ptr[timer_ch_id] = 0x00; // Timer mode, increment on every rising edge 
		     *tmr_pr_ptr[timer_ch_id] = (timer_tick * 1000 - 1) ; // Load Pre-Scalar counter with timer_tick (0 to 14 = 15), so that timer counts every 1msec   
             *tmr_mr0_ptr[timer_ch_id] = cur_timer_or_counter_status_ptr->actual_timeout_in_ms_or_max_count; 
             *tmr_tcr_ptr[timer_ch_id] = 0x01;                  // Enable timer 
             while(*tmr_tc_ptr[timer_ch_id] != *tmr_mr0_ptr[timer_ch_id]);			 
             *tmr_mcr_ptr[timer_ch_id] = 0x02;  //Reset on MR0: the TC will be reset if MR0 matches it.
			 /* the Timer Counter and the Prescale Counter are synchronously reset on the next positive edge of PCLK. The counters remain reset until TCR[1] is
               returned to zero */
              *tmr_tcr_ptr[timer_ch_id] = 0x02; 
              *tmr_tc_ptr[timer_ch_id] = 0;
			  cur_timer_or_counter_status_ptr->timer_timeout_occured_flag = STATE_YES; 
        cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id = TMR_OR_COUNTER_STOP_STATE;
		}
	}
	else
	{
		;
	}
    return SUCCESS;	
}
 
/*------------------------------------------------------------*
FUNCTION NAME  : Timer_Stop

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : XTAL_FREQ = 12MHz, CCLK = 60 MHz, PCLK = 15MHz 

Func ID        : 12.02

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Timer_Stop(const uint8_t timer_ch_id )
{	
  timer_or_counter_status_t *cur_timer_or_counter_status_ptr;
  
	if(timer_ch_id >= NUM_TIMER_DEV_ID_CHS)
	{
		 sys_error_or_warning_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("12.02.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
  cur_timer_or_counter_status_ptr = timer_or_counter_status + timer_ch_id;
	*tmr_tcr_ptr[timer_ch_id] = 0x02; // disable timer and Reset TC and PR 
  *tmr_tc_ptr[timer_ch_id] = 0;
   cur_timer_or_counter_status_ptr->timer_or_counter_cur_run_id = TMR_OR_COUNTER_STOP_STATE;
	return SUCCESS; 
}

#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
