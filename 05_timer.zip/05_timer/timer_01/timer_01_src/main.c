/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : By using timer by polling service, flash led ON and OFF periodically.                                                     

	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : FOR reusable firmware development and data can be inputed by multi input source and outputed to multi output source.                        
                      
		                
					   YET_TO_COMPLETE. 	 
						
CAUTION               :  

               LCD    :  Only display least numeric digits and from left to right display is implemented.
			   UART   :  Only display least numeric digits and from left to right display is implemented.
			          :  Only 9600 baud rate is supported.
	     LED MATRIX   :  Does not support data type in str. 
                      :  Disp map ie led_dot_disp_map[] is coded for only seq write type = SEQ_WRITE_COL.
           KEYBOARD   :  If Keyboard is used, then u must hold CPU by using While(read_sw_pressed_state) by defining macro SW_PRESS_HOLD_CPU.
			          :  If ENTER_SW or BACKSPACE_SW is not a part of keyboard, then set IO channnel of that ENTER_SW or BACKSPACE_SW must set to IO_CH_INVALID.
					  :  Keypad's each row are activated in a sequential (serial) order and the columns of that row are sequentially checked for the pressed state. 
		        SW    :  If only independent SW's are used, then no need to hold CPU by using sw read level transition by not defining macro SW_PRESS_HOLD_CPU. 
				      :  NUM_INPUT_DEV_ID_SW_CHS must be appropiately set to accommodate independent SW's(if any) and (if any) Keyboard's required SW's. 
					     Keyboard's required SW's are KEYPAD_NUM_COLS, and ENTER_SW or/and BACKSPACE_SW(if ENTER_SW or/and BACKSPACE_SW are part of keyboard).						 			  
  SW & KEYBOARD INIT  :  First initialise independent SW if any, then only initialize Keyboard, if any.
  
	
DATA & DEV CTRL CONF  :  Configuration of data id and device control must be correct and appropriate. 
    	ERROR PROC    :  Process to do when a error or warning has occured is not implemented, but communicates with error status in LCD(ch: 0) or/and UART(ch: 0).
		  CTRL CHARS  :  Only Backspace ctrl char is supported and enter ctrl char can be used as terminator char. 
		  DATA STREAM :  Data Stream is not supported.
		STDOUT OPER   :  For Put_Char(), Put_Str() and Print() operations, macro UART_MOD_ENABLE must be defined 
		                 and if UART dev is not one of the transmit data source in cur_data_id, then TRACE_UART_CH_ID is used for STDOUT operations.
        STDIN OPER    :  For Get_Char(), Get_Str() and Scan() operations, macros UART_MOD_ENABLE and KEYBOARD_MOD_ENABLE must be defined. 
		                 Keyboard dev must be one of the input data source in cur_data_id and IO Channel of ENTER_SW must not be IO_CH_INVALID(ie must be valid IO channel).
						 If UART dev is not one of the transmit data source in cur_data_id, then TRACE_UART_CH_ID is used for STDIN operations(for UART, to display read char(s)).		
		FLOW CONTROL  :  Only Stop and Wait ARQ is to be supported. 
	     	CHAR CODE :  Only ASCII 7bit character code is supported. 
		    DEV INIT  :  All data ids dev source must be initialized and make sure that same dev source(dev id and dev ch id) must not initialized more than once.
          DEV DEINIT  :  All data ids dev source can be deinitialized and make sure that same dev source(dev id and dev ch id) must not deinitialized more than once.
                                    
CHANGE LOGS           :  

FILE ID               : 01

*****************************************************************************/
#include "main.h"
#include "dev_chs_map.h"
#include "data_and_timer_ids_map.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
num_value_t disp_trace_num;
disp_num_fmt_t disp_trace_num_fmt;
uint32_t sys_error_or_warning_flag = NO_ERROR;
data_id_status_para_t data_id_status_para[NUM_DATA_IDS];
uint8_t cur_data_id = DATA_ID_INVALID;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t System_Init(void); 
static uint8_t HW_Init(const void *const get_init_ptr);
static uint8_t PLL_Init(void);
extern uint16_t Appl_Proc(void);
extern uint16_t Appl_Init(const void *const data_ptr);
extern uint16_t Appl_HW_Init(void);
extern uint16_t Appl_Reset(const uint8_t reset_type);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint8_t ret_status;
	  	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return ret_status;
	}	
    if((ret_status = Appl_Init(NULL_PTR)) != SUCCESS)
	{
		  return ret_status;
    }
	while(1)
	{
	    if((ret_status = Appl_Proc()) != SUCCESS)
	    {
			return FAILURE;
	    }
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Process

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Reset_Process(const uint8_t reset_type)
{
	uint8_t ret_status;
  
	switch(reset_type)
	{
		case RESET_WHOLE:		 
		  #ifdef SW_MOD_ENABLE
	         Disable_All_SWs();
	      #endif   
          #ifdef KEYBOARD_MOD_ENABLE	
            Disable_All_Keyboards();
	      #endif
	      #ifdef SEG7_MOD_ENABLE
	        Disable_All_Seg7s();
	      #endif
	      #ifdef LED_MATRIX_MOD_ENABLE
	         Disable_All_LED_Matrixs();
	      #endif
	      #ifdef LCD_MOD_ENABLE
	         Disable_All_LCDs();
	      #endif 
		  #ifdef UART_MOD_ENABLE
		    Disable_All_UARTs();
		  #endif
		   //memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));
		case RESET_DATA_IDS_AND_APPL: 
		   Reset_Data_IDs_Status();
		case RESET_APPL:
           if((ret_status = Appl_Reset(RESET_APPL)) != SUCCESS)
		  {
			  sys_error_or_warning_flag = ERR_RESET_OPER;
		      Error_or_Warning_Proc("01.02.01", ERROR_OCCURED, sys_error_or_warning_flag);
		     return sys_error_or_warning_flag;
		  }
        break;
        default:
           sys_error_or_warning_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("01.02.02", ERROR_OCCURED, sys_error_or_warning_flag);
		   return sys_error_or_warning_flag;		
	}
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t System_Init(void)
{
	 uint8_t ret_status; 
	 
	 if((ret_status = HW_Init(NULL_PTR)) != SUCCESS)
	 {
		 sys_error_or_warning_flag = ERR_HW_INIT;
		 Error_or_Warning_Proc("01.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag; 
	 }
	 if((ret_status = Reset_Process(RESET_WHOLE)) != SUCCESS)
	 {
		 sys_error_or_warning_flag = ERR_RESET_OPER;
		 Error_or_Warning_Proc("01.03.02", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	 }	 
	 if((ret_status = Data_IDs_Set_Para()) != SUCCESS)
	 {
         sys_error_or_warning_flag = ERR_DATA_ID_CONF;
		 Error_or_Warning_Proc("01.03.03", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag; 
	 }
     return SUCCESS;	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW if any, then initialize Keyboard, if any.

Func ID        : 01.04  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t HW_Init(const void *const get_init_ptr)
{
	uint8_t ret_status = SUCCESS ;
	
	PLL_Init();
	Reset_IO_Chs();	
    if((ret_status = Appl_HW_Init()) != SUCCESS)
	{
		 sys_error_or_warning_flag = ERR_HW_INIT;
		 Error_or_Warning_Proc("01.04.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}    
    return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.05  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x00; // or APBDIV, PCLK = CCLK / 4 
   	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
