/**************************************************************************
   FILE          :    appl.h
 
   PURPOSE       :    application header.  
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _APPL_H
#define _APPL_H

 
/* ---------------------- macro defination ------------------------------------------------ */

/* ---------------------- data type defination -------------------------------------------- */
 
 typedef enum
 {
	ERR_UART_NOT_DATA_SRC = NUM_SYS_STATUS, ERR_LCD_NOT_DATA_SRC, ERR_AUTH_FSM_PROC, ERR_LCD_LOC_CTRL, ERR_AFTER_SW_PRESS_STROKE, 
	ERR_DISP_STATUS, ERR_UART_TRANSMIT, NUM_APPL_STATUS
 } appl_status_t;
 
 typedef enum 
 {
	 FSM_TIMER_TRIGGERED_TO_STOP, FSM_TIMER_STOPPED, FSM_TIMER_TRIGGERED_TO_RUN, FSM_TIMER_RUNNING, FSM_TIMER_TRIGGERED_TO_PAUSE,
	 FSM_TIMER_PAUSED, FSM_TIMER_TRIGGERED_TO_RESUME, NUM_FSM_TIMER_STATES
 } timer_state_t;
 
/* -------------------- public variable declaration --------------------------------------- */
extern uint16_t appl_error_or_warning_flag;

/* -------------------- public function declaration --------------------------------------- */
uint16_t Appl_Reset(const uint8_t reset_type);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
