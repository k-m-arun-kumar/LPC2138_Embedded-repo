/* ********************************************************************
FILE                   : appl.c

PURPOSE                :  Application 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 11

*****************************************************************************/
#include "main.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
 
uint8_t appl_error_or_warning_flag ;
 
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint8_t Appl_Reset(const uint8_t reset_type)
{
	dev_id_t lcd_dev_id;	
	uint8_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:
		   Set_Status_Reset_Data_IDs(DATA_ID_RESET_INIT_STATUS);		  
		break;
		default:
		   appl_error_or_warning_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.01", ERROR_OCCURED, appl_error_or_warning_flag);
		   return appl_error_or_warning_flag;
	}
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.02

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Appl_Proc(void)
{	
     int num_32;
     char read_char, read_str[STREAM_BUFFER_LEN];
	   uint8_t ret_status = 40;
  
	switch(cur_data_id) 
	{	
        case DATA_ID_DISP:
		   Print("\r Enter a Char = ");
		   read_char = Get_Char();
		   Print("\r Entered Char = ");
		   Put_Char(read_char);	
           Print("\r Enter a str = ");
		   Get_Str(read_str);
		   Print("\r Entered str = ");
		   Put_Str(read_str);
           Print("\r Enter str = ");
           Scan("%s", &read_str);
		   Print("\r Enter num = ");
		   Scan("%d", &num_32);
           Print("\r signed num = %d, Entered str = %s & num = %d", -20, read_str, num_32);  
           Print("\r ret_status = %u ", ret_status);		   
		break;
		default:
		    appl_error_or_warning_flag = ERR_CUR_DATA_ID_INVALID;
		    Error_or_Warning_Proc("11.02.02", ERROR_OCCURED, appl_error_or_warning_flag);
		    return appl_error_or_warning_flag;
	} 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.03  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Appl_Init(const void *const data_ptr)
{	
    dev_id_t cur_data_devs_src_allow[1] = { CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER};
    uint8_t ret_status;	
	
	if((ret_status =  Next_Data_Conf_Parameter(DATA_ID_DISP)) != SUCCESS)
	{
		 appl_error_or_warning_flag = ERR_NEXT_DATA_CONF;
		 Error_or_Warning_Proc("11.03.01", ERROR_OCCURED, sys_error_or_warning_flag);
		 return sys_error_or_warning_flag;
	}
	Set_Data_Devs_Src_Allow(DEV_INPUT_TYPE, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
	if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ENABLE_OPER_FUNC, DEV_INPUT_TYPE, cur_data_devs_src_allow)) != SUCCESS)
	{
	    appl_error_or_warning_flag = ERR_DEV_OPER_ENABLE_FUNC;
	    Error_or_Warning_Proc("11.03.02", ERROR_OCCURED, appl_error_or_warning_flag);
	    return appl_error_or_warning_flag; 
	} 
    Set_Data_Devs_Src_Allow(DEV_RECEIVE_TYPE, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
	if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(COMM_DEV_ENABLE_OPER_FUNC, DEV_RECEIVE_TYPE, cur_data_devs_src_allow)) != SUCCESS)
	{
	    appl_error_or_warning_flag = ERR_DEV_OPER_ENABLE_FUNC;
	    Error_or_Warning_Proc("11.03.03", ERROR_OCCURED, appl_error_or_warning_flag);
	    return appl_error_or_warning_flag; 
	} 
	Set_Data_Devs_Src_Allow(DEV_TRANSMIT_TYPE, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
	if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(COMM_DEV_ENABLE_OPER_FUNC,DEV_TRANSMIT_TYPE , cur_data_devs_src_allow)) != SUCCESS)
	{
	    appl_error_or_warning_flag = ERR_DEV_OPER_ENABLE_FUNC;
	    Error_or_Warning_Proc("11.03.04", ERROR_OCCURED, appl_error_or_warning_flag);
	    return appl_error_or_warning_flag; 
	} 	
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW in order from SW_CH_ID from 0 if any, then initialize Keyboard, if any.

Func ID        : 11.04  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Appl_HW_Init(void)
{
    uint8_t ret_status ;
	
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_TRANSMIT_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_RECEIVE_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(INTERNAL_ERROR_LED_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Keyboard_Init(CH_ID_00, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	return SUCCESS; 
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
