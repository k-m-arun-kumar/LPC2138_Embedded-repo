/**************************************************************************
   FILE          :    keyboard.h
 
   PURPOSE       :    keyboard Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _KEYBOARD_H
 #define _KEYBOARD_H
 
 /* ---------------------- macro defination ------------------------------------------------ */
 
#define ENTER_SW_CODE                           ('E')
#define BACKSPACE_SW_CODE                       ('B')

#define RCVD_CHAR_PLAIN_DISP_FORMAT              (1)
#define RCVD_CHAR_HIDDEN_DISP_FORMAT             (2)  

#define KEYPAD_ROWA_SELECT                       (1)
#define KEYPAD_ROWB_SELECT                       (2)
#define KEYPAD_ROWC_SELECT                       (3)
#define KEYPAD_ROWD_SELECT                       (4)

/* ---------------------- data type defination --------------------------------------------- */
typedef struct 
{
	uint8_t io_ch_rowa;
	uint8_t io_ch_col1;
    uint8_t access_flag               : 1; 
	uint8_t enable_flag               : 1;
	uint8_t keypad_keys_enable_flag   : 1;    	
	uint8_t pressed_state             : 1;
    uint8_t base_sw_ch_id             :	4;    //col1's key as base sw
} keyboard_ctrl_t;

typedef struct
{
	  uint8_t data_id; 
         	  
} keyboard_status_t;

/* -------------------- public variable declaration --------------------------------------- */
extern keyboard_ctrl_t keyboard_ctrl[NUM_INPUT_DEV_ID_KEYBOARD_CHS];

 /* -------------------- public prototype declaration --------------------------------------- */
uint8_t Keyboard_Read(const uint8_t keyboard_ch_id, void *const pressed_key_ptr);
uint8_t Entered_Key_No_Long_Press_Proc(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr);
uint8_t Keyboard_Disable(const uint8_t keyboard_ch_id);
uint8_t Disable_All_Keyboards(void);
uint8_t Keyboard_Enable(const uint8_t keyboard_ch_id);
uint8_t Keyboard_Allow_Access(const uint8_t keyboard_ch_id);
uint8_t Keyboard_No_Access(const uint8_t keyboard_ch_id);
uint8_t Get_Data_By_Keyboard(const uint8_t keyboard_ch_id, const uint8_t data_id );
uint8_t Keyboard_Init(const uint8_t keyboard_ch_id);
uint8_t Keyboard_DeInit(const uint8_t keyboard_ch_id);
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
