/**************************************************************************
   FILE          :    appl_data.h
 
   PURPOSE       :     
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _APPL_DATA_H
#define _APPL_DATA_H

/* ---------------------- macro defination ------------------------------------------------ */
//#define SW_PRESS_HOLD_CPU        (0)
//#define DMA_DATA_ID_STR          (1)

/* ---------------------- data type defination -------------------------------------------- */
typedef enum
{  
   DISP_LED_DOT_MATRIX_INC, DISP_LED_DOT_MATRIX_DCR, DISP_LED_DOT_MATRIX_NO_CHANGE 
} disp_data_ctrl_para_t;

/* -------------------- public variable declaration --------------------------------------- */



/* -------------------- public function declaration --------------------------------------- */

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
