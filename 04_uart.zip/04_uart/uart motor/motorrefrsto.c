/*  type on in virtual terminal to run motor and to turn off motor, type off in virtual terminal 

Author: K.M. Arun Kumar alias Arunkumar Murugeswaran */


#include<lpc213x.h>
#define en 1<<16
#define rw 1<<17
#define rs 1<<18
#define rl1 1<<8
#define rl2 1<<9
char i,j,x,a[3], m = 0;
void delay(unsigned int n)
{
	while(n--);
}
void pulse()
{
	IOSET1=en;
	delay(1000);
	IOCLR1=en;
	delay(1000);
}
void cmd(unsigned char a)
{
	IOCLR1=0xff<<20;
	IOCLR1=rs;
	IOCLR1=rw;
	IOSET1=a<<20;
	pulse();
	delay(50000);
}
void data(char b)
	{
	IOCLR1=0xff<<20;
	IOSET1=rs;
	IOCLR1=rw;
	IOSET1=b<<20;
	pulse();
	delay(50000);
}
	void string(const char *b)
	{
		while(*b)
		{
			data(*b++);
		}
	}
	void tx(char c)
	{
		U0THR=c;
		while(!(U0LSR&0x40));
		//U0LSR=0;
	}
	void rx(void)
	{
		 while(!(U0LSR&0x01));
			x=U0RBR;
		//U0LSR=0;			
			a[i]=x;
		data(a[i]);	
		tx(x);	
		
		
	}


	int main()
	{
		PINSEL0=0X00000005;
		PINSEL2=0X00000000;
		IODIR0=0XFFFFFFFF;
		IOCLR0=0XFFFFFFFF;
		IODIR1=0XFFFFFFFF;
		IOCLR1=0XFFFFFFFF;
		U0LCR=0X83;
		U0DLL=98;
		U0LCR=0X03;
		U0FCR=0X30;
		cmd(0x0c);
		cmd(0x38);
		cmd(0xc0);
		while(1)
		{
			rx();
			switch(m)
			{
				case 0:
				   cmd(0x01);
				   data(a[i]);
					if(a[i] == 'o')
					{					
						m = 1;
						++i;
					}
				break;
				case 1:
				 if(a[i] == 'n')
				 {
					 IOSET0=rl1;
				   IOCLR0=rl2;
				   i = 0;
					 m = 0;
				}
				 else
				 {
					 if(a[i] == 'f')
					 {
						 	m = 2;
						   ++i;
					 }
				 }
				break;
				case 2:
					if(a[i] == 'f')
					{						
						IOCLR0=rl2;
				    IOCLR0=rl1;				   
				  	i = 0;
					    m = 0;
					}
					break;
			}
		}
	}
