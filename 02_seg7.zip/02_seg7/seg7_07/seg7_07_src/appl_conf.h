/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/* -------------------------------- Debug Conf -----------------------------------------*/
 //#define TRACE                                   (1U)
#define TRACE_ERROR                                 (2U)

/*------------------------------- LCD Disp Conf ------------------------------------------*/


/* -------------------------------Timer State Conf ---------------------------------------*/


/* ------------------------------ ADC input signal val Conf ------------------------------*/


/* ------------------------------ Appl Data Types --------------------------------------- */
#define MAX_DATA_INPUT_DEVS                 (2)
#define MAX_DATA_OUTPUT_DEVS                (2)
#define MAX_DATA_COMM_DEVS                 (1)

typedef enum 
{
  DATA_ID_7SEG_1, DATA_ID_7SEG_1_2, DATA_ID_7SEG_2, NUM_DATA_IDS    	
} cur_data_id_t;

/* ------------------------------- Application Conf --------------------------------------*/
#define MAX_ICOUNT_7SEG_SW_DELAY                 (1000)
#define MAX_JCOUNT_7SEG_SW_DELAY                 (1000)

#define MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY           (100) 
#define MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY           (100)

#define HIDDEN_KEY_DISP_CHAR                      ('X') 
#define DATA_MAX_NUM_ALLOCATED_CHARS               (5U) 
#define HIDDEN_CHAR_LCD_DISP_TIME_IN_MILLI_SEC   (1000)

#define KEYPAD_CONF_MAX_NUM_CHARS_ENTERED         (15)
#define DATA_MAX_NUM_CHARS_TO_READ                (15)
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
