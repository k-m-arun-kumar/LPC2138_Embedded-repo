
/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

/* ---------------------- macro defination ------------------------------------------------ */
typedef enum 
{
 	IO_CH_SEG7_CH_00_A_LED = (IO_CH_03), IO_CH_SEG7_CH_00_UNIT_DIGIT =  (IO_CH_11), IO_CH_SEG7_CH_00_TENS_DIGIT = (IO_CH_12), 
	IO_CH_KEYPAD_CH_00_ROWA = (IO_CH_48), IO_CH_KEYPAD_CH_00_ROWB , IO_CH_KEYPAD_CH_00_ROWC ,IO_CH_KEYPAD_CH_00_ROWD,
	IO_CH_SEG7_CH_01_A_LED = (IO_CH_16), IO_CH_SEG7_CH_01_UNIT_DIGIT =  (IO_CH_25), IO_CH_SEG7_CH_01_TENS_DIGIT = (IO_CH_26), 
	IO_CH_KEYPAD_CH_01_ROWA = (IO_CH_55), IO_CH_KEYPAD_CH_01_ROWB , IO_CH_KEYPAD_CH_01_ROWC ,IO_CH_KEYPAD_CH_01_ROWD
} io_ch_map_op_ch_t;
    
typedef enum 
{ 
   IO_CH_KEYPAD_CH_00_COL1 = (IO_CH_52), IO_CH_KEYPAD_CH_00_COL2, IO_CH_KEYPAD_CH_00_COL3, 
   IO_CH_KEYPAD_CH_01_COL1 = (IO_CH_59), IO_CH_KEYPAD_CH_01_COL2, IO_CH_KEYPAD_CH_01_COL3 
} io_ch_map_ip_ch_t ;

/* ---------------------- data type defination -------------------------------------------- */

/* -------------------- public variable declaration --------------------------------------- */
 
/* -------------------- public function declaration --------------------------------------- */

 
#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
