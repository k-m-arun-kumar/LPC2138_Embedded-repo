/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : for every SW_INC press increment display NUMBER, in a 7 segment LED 4 digit multiplexed.  
                         for every SW_DEC press decrement display number, in a 7 segment LED 4 digit multiplexed.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Cathode 7 segment 4 digit multiplexed is used.

CAUTION               :  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

typedef struct 
{
	uint_32 consucc_val;
	uint_8 start_bit_pos;
	uint_8 bits_len;
} consucc_bit_type;

value_types to_disp;
uint_8 inc_sw_enable_flag = STATE_YES_IN_CHAR, dcr_sw_enable_flag = STATE_YES_IN_CHAR;

static void Seg7_Disp_Num(uint_16 seg7_disp_num);
void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);
static uint_8 System_Init(void);
static uint_8 Appl_Init(const void *const data_ptr);
static uint_8 HW_Init(const void *const get_init_ptr);
static uint_8 PLL_Init(void);
static uint_8 GPIO_Init(void );
uint_8 Config_Consucc_Bits(void *const data_ptr, const uint_8 consucc_bit_flag);
uint_8 Test_Consucc_Bits(const void *const data_ptr, const uint_8 flag_consucc_bit);
uint_8 Config_Port0_Pins(const void *const data_ptr);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 000  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint_16 seg7_disp_num = 0;
	uint_8 ret_status;
	
	static uint_8 fsm_inc_sw_state = KEY_RELEASED, fsm_dcr_sw_state = KEY_RELEASED;	
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return FAILURE;
	}	
  if((ret_status = Appl_Init(NULL)) != SUCCESS)
	{
		  return FAILURE;
  }		
	while(1)
	{	
        if(inc_sw_enable_flag == STATE_YES_IN_CHAR && fsm_inc_sw_state == KEY_RELEASED && (!(IO1PIN & 1 << INC_SW_PORT1_PIN))) 
		{
			fsm_inc_sw_state = KEY_PRESSED;  
      			
		}
        else
		{
			if(inc_sw_enable_flag == STATE_YES_IN_CHAR && fsm_inc_sw_state == KEY_PRESSED && (IO1PIN & 1 << INC_SW_PORT1_PIN))
			{
			   fsm_inc_sw_state = KEY_RELEASED;	
         inc_sw_enable_flag = STATE_NO_IN_CHAR;
				 dcr_sw_enable_flag = STATE_NO_IN_CHAR;
         if(seg7_disp_num >= 9999)
				 {
             seg7_disp_num  = 0;
				 }
         else
				 {										
             ++seg7_disp_num; 
				 }		
			}	   
		}
				
		if(dcr_sw_enable_flag == STATE_YES_IN_CHAR && fsm_dcr_sw_state == KEY_RELEASED && (!(IO1PIN & 1 << DCR_SW_PORT1_PIN))) 
		{
			fsm_dcr_sw_state = KEY_PRESSED;	            					 
		}
    else
		{
			if(fsm_dcr_sw_state == KEY_PRESSED && (IO1PIN & 1 << DCR_SW_PORT1_PIN))
			{
			   fsm_dcr_sw_state = KEY_RELEASED;	
				 inc_sw_enable_flag = STATE_NO_IN_CHAR;
				 dcr_sw_enable_flag = STATE_NO_IN_CHAR;
         if(seg7_disp_num <= 0)
				 {
             seg7_disp_num  = 9999;
				 }
         else
				 {										
                    --seg7_disp_num; 
				 }	
			}			   
		}
		Seg7_Disp_Num(seg7_disp_num);
	}
	return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 001  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 011  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 Appl_Init(const void *const data_ptr)
{
	  Seg7_Disp_Num(0);
	  return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 002  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(const void *const get_init_ptr)
{
	uint_8 ret_status = SUCCESS;
	PLL_Init();
	if((ret_status = GPIO_Init()) != SUCCESS)
	  return FAILURE;	
  return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 003  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
   	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 004  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 GPIO_Init(void)
{
	consucc_bit_type consucc_bit_data;
	uint_8 ret_status;
		
	consucc_bit_data.start_bit_pos = SEG7_PORT0_LSB_PIN;
	consucc_bit_data.bits_len = 8;
	consucc_bit_data.consucc_val = 0x0;
	if((ret_status = Config_Consucc_Bits((void *)&consucc_bit_data, FLAG_CONSUCC_BITS_1)) != SUCCESS)
	{
		   return FAILURE;
	}
	PINSEL2 = 0x0;
	PINSEL0 = 0x0;	
	IO0DIR = consucc_bit_data.consucc_val | 1 << UNIT_DIGIT_PORT0_PIN | 1 << TENS_DIGIT_PORT0_PIN | 1 << HUND_DIGIT_PORT0_PIN | 1 << THOS_DIGIT_PORT0_PIN;
  IO0CLR = consucc_bit_data.consucc_val | 1 << UNIT_DIGIT_PORT0_PIN | 1 << TENS_DIGIT_PORT0_PIN | 1 << HUND_DIGIT_PORT0_PIN | 1 << THOS_DIGIT_PORT0_PIN;	
	IO1DIR = 0 << INC_SW_PORT1_PIN | 0 << DCR_SW_PORT1_PIN ;	
  return SUCCESS; 	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 006 

BUGS           :
-*------------------------------------------------------------*/
uint_8 Config_Consucc_Bits(void *const data_ptr, const uint_8 flag_consucc_bit)
{
	uint_32 from_bit0_consucc_bits = 0;	
	consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	uint_8 i, ret_status = SUCCESS;    
	
	if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	{
		return  FAILURE;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    ret_status = FAILURE;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 007 

BUGS           :
-*------------------------------------------------------------*/
uint_8 Test_Consucc_Bits(const void *const data_ptr, const uint_8 flag_consucc_bit)
{
	uint_32 from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	uint_8 i, ret_status = SUCCESS;	
	
	if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	{
		return FAILURE;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == consucc_bit_ptr->consucc_val & mask_configured_bits)
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == consucc_bit_ptr->consucc_val | mask_configured_bits)
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
			 default:
		      ret_status = FAILURE;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for common cathode 7 seg led display

Func ID        : 008 

BUGS           :
-*------------------------------------------------------------*/
static void Seg7_Disp_Num(uint_16 seg7_disp_num)
{
	    uint_32 digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x00};
		consucc_bit_type consucc_bit_data;	
        int_8 cur_digit;
		
        IO0SET = 1 << UNIT_DIGIT_PORT0_PIN | 1 << TENS_DIGIT_PORT0_PIN | 1 << HUND_DIGIT_PORT0_PIN | 1 << THOS_DIGIT_PORT0_PIN;
        consucc_bit_data.start_bit_pos = SEG7_PORT0_LSB_PIN;
      	consucc_bit_data.bits_len = 8;	
		for( cur_digit = 4 ; cur_digit > 0 ; cur_digit--)
		{
            //Turn on a digit for a short amount of time
            switch(cur_digit)
	        {
               case 1:
                 IO0CLR = 1 << UNIT_DIGIT_PORT0_PIN;
               break;
               case 2:
                 IO0CLR = 1 << TENS_DIGIT_PORT0_PIN;
               break;
               case 3:
                 IO0CLR = 1 << HUND_DIGIT_PORT0_PIN;
               break;
               case 4:
                 IO0CLR =  1 << THOS_DIGIT_PORT0_PIN;
               break;
           }
		   consucc_bit_data.consucc_val = digit[seg7_disp_num % 10];
		   seg7_disp_num  /= 10;				
		   Config_Port0_Pins(&consucc_bit_data); 
		   //Display digit for fraction of a second (1us to 5000us, 500us is pretty good)
           SW_Time_Delay(MAX_ICOUNT_DISP_BRIGHT_SW_DELAY, MAX_JCOUNT_DISP_BRIGHT_SW_DELAY); 
		   consucc_bit_data.consucc_val = digit[10];
		   Config_Port0_Pins(&consucc_bit_data);
		   switch(cur_digit)
	       {
                 case 1:
                   IO0SET = 1 << UNIT_DIGIT_PORT0_PIN;
                 break;
                 case 2:
                   IO0SET = 1 << TENS_DIGIT_PORT0_PIN;
                 break;
                 case 3:
                   IO0SET = 1 << HUND_DIGIT_PORT0_PIN;
                 break;
                 case 4:
                   IO0SET =  1 << THOS_DIGIT_PORT0_PIN;
                 break;
           }
		   
       	}		
      	//Wait for 20ms to pass before we paint the display again
		 SW_Time_Delay(MAX_ICOUNT_DISP_PAINT_SW_DELAY, MAX_JCOUNT_DISP_PAINT_SW_DELAY); 
        inc_sw_enable_flag = STATE_YES_IN_CHAR;
	    dcr_sw_enable_flag = STATE_YES_IN_CHAR;
		return;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 009  

BUGS           :              
-*------------------------------------------------------------*/
void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count)
{
	 uint_32 i, j;
	 for(i = 0; i < max_i_count; ++i)
	 { 
         for(j = 0;j < max_j_count; ++j);
	 } 
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 010  

BUGS           :              
-*------------------------------------------------------------*/
uint_8 Config_Port0_Pins(const void *const data_ptr)
{
	 uint_8 i; 
	 consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	
	 if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	 {
		   return FAILURE;
	 } 
	 for(i = consucc_bit_ptr->start_bit_pos ; i < consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len; ++i)
	 {
		   if(consucc_bit_ptr->consucc_val & 1 << i)
			 {
				   IO0SET = 1 << i;
			 }
			 else
			 {
				   IO0CLR = 1 << i;
			 }
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
