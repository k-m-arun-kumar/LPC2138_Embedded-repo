/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/* -------------------------------- debug conf -----------------------------------------*/
 //#define TRACE                                   (1U)
#define TRACE_ERROR                                 (2U)

/*------------------------------- LCD disp conf ------------------------------------------*/


/* -------------------------------Timer state conf ---------------------------------------*/


/* ---------------------------------- ADC input signal val conf -------------------------- */


/* ------------------------------- application conf --------------------------------------*/
#define MAX_ICOUNT_DISP_BRIGHT_SW_DELAY      (100)
#define MAX_JCOUNT_DISP_BRIGHT_SW_DELAY      (100)
#define MAX_ICOUNT_DISP_PAINT_SW_DELAY       (1000)
#define MAX_JCOUNT_DISP_PAINT_SW_DELAY       (1000) 

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
