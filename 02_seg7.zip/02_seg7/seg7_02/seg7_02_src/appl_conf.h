/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/* -------------------------------- debug conf -----------------------------------------*/
 //#define TRACE                                   (1U)
#define TRACE_ERROR                                 (2U)

/*------------------------------- LCD disp conf ------------------------------------------*/


/* -------------------------------Timer state conf ---------------------------------------*/


/* ---------------------------------- ADC input signal val conf -------------------------- */


/* ------------------------------- application conf --------------------------------------*/
#define MAX_ICOUNT_7SEG_SW_DELAY                 (1000)
#define MAX_JCOUNT_7SEG_SW_DELAY                 (1000)

#define MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY           (100) 
#define MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY           (100)

//#define CONFIG_PORTX_PINS                         (0)

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
