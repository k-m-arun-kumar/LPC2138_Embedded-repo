/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : In a keypad, when a first digit is pressed, then display is blank in a 7 segment Common Anode LED 2 digit multiplexed 
                         when a 2 digit is pressed in keypad, then display that number with first pressed key as Tens digit value in a 7 segment 
						 Common Anode LED 2 digit multiplexed. 						
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : FOR reusable firmware development and data can be inputed by multi input source and outputed to multi output source.                        
                      
CAUTION               :  
                                    
CHANGE LOGS           : modified from seg_06_02. 

IMPLEMENTED           : from seg_06_02, Keyboard_Proc(keyboard_ch_id, data_id) is to be modified as Keyboard_Proc(keyboard_ch_id, *pressed_key_ptr) and 
						 function pointer based calling source's appropiate device operation function.

FILE ID               : 01

*****************************************************************************/
#include <string.h> 
#include "main.h"
#include "port_pins_map.h"
#include "dev_chs_map.h"
#include "appl_conf.h"
/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
num_value_t to_disp_in_num;
uint32_t error_flag = NO_ERROR;
sw_para_t sw_para[ NUM_INPUT_DEV_ID_SW_CHS];
data_id_status_para_t data_id_status_para[NUM_DATA_IDS];
uint8_t cur_data_id = DATA_ID_INVALID;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t System_Init(void);
static uint8_t Appl_Init(const void *const data_ptr);
static uint8_t HW_Init(const void *const get_init_ptr);
static uint8_t PLL_Init(void);


/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint8_t ret_status, i = 0, dev_ch_id, dev_id, io_ch ;
	dev_id_t cur_data_dev_filter[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS), MAX_DATA_COMM_DEVS) ] = { {INPUT_DEV_ID_KEYBOARD, CH_ID_00}},
  cur_data_dev_src[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS), MAX_DATA_COMM_DEVS)];
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return ret_status;
	}	
    if((ret_status = Appl_Init(NULL_PTR)) != SUCCESS)
	{
		  return ret_status;
    }		
	while(1)
	{	
		switch(cur_data_id)
		{
			case DATA_ID_SEG7:
		        ret_status = Cur_Data_ID_Input_Devs_Read_Oper_Func();				
				switch(ret_status)
	            {
		            case CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS:
					     if((ret_status = Str_to_Num_Conv(&data_id_status_para[cur_data_id].data_value.data_num.val_uint_32[0], data_id_status_para[cur_data_id].data_value.data_str)) != SUCCESS)
						 {
							 return FAILURE;
						 }
						 if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_DISABLE_OPER_FUNC, cur_data_dev_filter, cur_data_dev_src)) != SUCCESS)
						 {
							 return FAILURE;
						 }  
						 cur_data_dev_filter[0].dev_id = OUTPUT_DEV_ID_SEG7;
						 cur_data_dev_filter[0].dev_ch_id = CH_ID_00;
                        if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(OUTPUT_DEV_ENABLE_OPER_FUNC, cur_data_dev_filter, cur_data_dev_src)) != SUCCESS)
						 {
							 return FAILURE;
						 }              
			           				  	   
					     ret_status = Cur_Data_ID_Write_Devs_Write_Oper_Func();
					     switch(ret_status)
					     {
					         case  ERR_CUR_DATA_ID_DEV_DISABLED:
					         case ERR_CUR_DATA_ID_DEV_CH_ID_NO_ACCESS:
					         case SUCCESS:
						     break;
						     default:
						       return FAILURE;
					     }
						 Reset_Data_ID_Status(cur_data_id, DATA_ID_RESET_WHOLE_STATUS);
						 cur_data_dev_filter[0].dev_id = INPUT_DEV_ID_KEYBOARD;
						 cur_data_dev_filter[0].dev_ch_id = CH_ID_00;
						 if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ENABLE_OPER_FUNC, cur_data_dev_filter, cur_data_dev_src)) != SUCCESS)
						 {
							 return FAILURE;
						 }

			        	
				  break;
		      case CUR_DATA_ID_REACH_MAX_CHARS_READ_WAIT_TERMINATOR_CHAR:
		      case ERR_CUR_DATA_ID_DEV_DISABLED:
		      case ERR_CUR_DATA_ID_DEV_CH_ID_NO_ACCESS:		         
		      case CUR_DATA_ID_CHAR_NOT_READ:		      
          break;
				  case CUR_DATA_ID_VALID_CHAR_READ:
				  case ERR_CUR_DATA_ID_SPECIAL_CHAR_READ_BUT_DISABLED:
				  case ERR_CUR_DATA_ID_NUM_CHAR_READ_BUT_DISABLED:
				  case ERR_CUR_DATA_ID_SMALL_ENGLISH_ALPHA_CHAR_READ_BUT_DISABLED:
				  case ERR_CUR_DATA_ID_BIG_ENGLISH_ALPHA_CHAR_READ_BUT_DISABLED:
				  case ERR_CUR_DATA_ID_CTRL_CHAR_READ_BUT_DISABLED:
		              if(data_id_status_para[cur_data_id].reach_max_alloc_input_chars_flag == STATE_NO) 
                      {
                        for(i = 0; i < MAX_DATA_OUTPUT_DEVS; ++i)
                        {
                            dev_id =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i].dev_id;
                            if(dev_id >= DEV_ID_INVALID)
                            {
                               break;
                            }
                            dev_ch_id =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i].dev_ch_id;
                            switch(dev_id)
                            {
                               case OUTPUT_DEV_ID_SEG7:
                                  io_ch =  seg7_ctrl[dev_ch_id].io_ch_unit_digit;
                               break;
                            }
				                   	if((ret_status = IO_Channel_Write(io_ch, STATE_LOW)) != SUCCESS)
		                        {
			                          return ret_status;										  
		                        }	 
                        }
						cur_data_dev_filter[0].dev_id = OUTPUT_DEV_ID_SEG7;
						 cur_data_dev_filter[0].dev_ch_id = CH_ID_00;
	                     if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(OUTPUT_DEV_DISABLE_OPER_FUNC, cur_data_dev_filter, cur_data_dev_src)) != SUCCESS)
						           {
							            return FAILURE;
						            }            
	                  } 	 
		          break;
		          default:
		             return FAILURE;
	            }	
            break;				
		 }				
	}	
	return FAILURE;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Appl_Init(const void *const data_ptr)
{
	    uint8_t dev_id, dev_ch_id, i = 0, ret_status = SUCCESS;
		dev_id_t cur_data_dev_filter[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS),MAX_DATA_COMM_DEVS)] = { {CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER}},
        cur_data_dev_src[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS), MAX_DATA_COMM_DEVS)];
		
	    Reset_Parameters();
	    Data_IDs_Set_Para();    
	    Next_Data_Conf_Parameter(DATA_ID_SEG7); 
		if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ENABLE_OPER_FUNC, cur_data_dev_filter, cur_data_dev_src)) != SUCCESS)
		{
		   return FAILURE;
	    }
	    return SUCCESS; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : Next_Data_Conf_Parameter

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Next_Data_Conf_Parameter(const uint8_t set_data_id)
{
    static uint8_t prev_data_id = DATA_ID_INVALID;
	
	 prev_data_id = cur_data_id;
	 switch(cur_data_id)
	 {
		  case DATA_ID_INVALID:
		  	cur_data_id = DATA_ID_SEG7;           
          break;
          default:
		    error_flag = ERR_CUR_DATA_ID_INVALID;
			return error_flag;
	 }	
	#ifndef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
    Data_Dev_Src_Access_Oper_Func(prev_data_id); 
    #endif	
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.04

BUGS           :    
-*------------------------------------------------------------*/
void Reset_Parameters(void)
{
	Reset_Data_IDs_Status();
    #ifdef KEYPAD_MOD_ENABLE	
       Disable_All_Keyboards();
	#endif
	#ifdef SEG7_MOD_ENABLE
	    Disable_All_Seg7s();
	#endif
	//Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.05  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t System_Init(void)
{
	return HW_Init(NULL_PTR);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.06  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t HW_Init(const void *const get_init_ptr)
{
	uint8_t ret_status = SUCCESS;
	
	PLL_Init();
	Reset_IO_Chs();	
	#ifdef PORT_PINS_MAP
	if((ret_status = IO_Channels_Func_Set(io_config, sizeof(io_config)/ sizeof(io_config_t))) != SUCCESS)
	  return ret_status; 
    #endif
  return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.07  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
   	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
