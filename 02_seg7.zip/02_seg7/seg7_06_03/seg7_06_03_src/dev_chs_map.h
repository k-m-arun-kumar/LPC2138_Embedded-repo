/**************************************************************************
   FILE          :    dev_chs_map.h
 
   PURPOSE       :   
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _DEV_CHS_MAP_H
 #define _DEV_CHS_MAP_H
 //                                                 IO_CH_ROWA,     IO_CH_COL1,   KEYBOARD_ACCESS, KEYBOARD_ENABLE, KEYS_ENABLE, PRESSED_STATE                                           
keyboard_ctrl_t keyboard_ctrl[]  = {  
	                                         { IO_CH_KEYPAD_CH_00_ROWA, IO_CH_KEYPAD_CH_00_COL1, STATE_NO, STATE_NO,  STATE_NO, STATE_LOW }
                                    };
 
//                            IO_CH_A_LED,           IO_CH_UNIT_DIGIT,             ACCESS, ENABLE,       TYPE      ,      NUM_DIGITS            											 
seg7_ctrl_t seg7_ctrl[] = {
                            { IO_CH_SEG7_CH_00_A_LED, IO_CH_SEG7_CH_00_UNIT_DIGIT, STATE_NO, STATE_NO, SEG7_COMMON_ANODE, SEG7_4_DIGIT }    
                          }; 
                               
#endif
																					
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
																		
