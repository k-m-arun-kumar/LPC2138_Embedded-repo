
/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran 
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#define INC_SW_PORT1_PIN         (16)  
#define DCR_SW_PORT1_PIN         (17)

#define SEG7_PORT0_LSB_PIN       (00)
#define UNIT_DIGIT_PORT0_PIN     (11) 
#define TENS_DIGIT_PORT0_PIN     (10)
#define HUND_DIGIT_PORT0_PIN     (9)
#define THOS_DIGIT_PORT0_PIN     (8) 
 
#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
