/* ********************************************************************
FILE                   : appl_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 02 

*****************************************************************************/

#include <string.h>
#include "main.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.01  

BUGS           :              
-*------------------------------------------------------------*/
void SW_Time_Delay(const uint32_t max_i_count, const uint32_t max_j_count)
{
	 uint32_t i, j;
	 for(i = 0; i < max_i_count; ++i)
	 { 
         for(j = 0;j < max_j_count; ++j);
	 } 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.02 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0;	
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;     
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return  error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    error_flag = ERR_CONSUCC_PARA;
		    ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.03 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;	
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == (consucc_bit_ptr->consucc_val & mask_configured_bits))
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					   error_flag = ERR_TEST_FAIL_1_CONSUCC_BITS;
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == (consucc_bit_ptr->consucc_val | mask_configured_bits))
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    error_flag = ERR_TEST_FAIL_0_CONSUCC_BITS;
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
			 default:
			 error_flag = ERR_CONSUCC_PARA;
		      ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.04  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_to_Num_Conv(uint32_t *const num_conv_from_str, const char *const num_in_str  )
{
	
	 uint32_t num = 0, place = 1;
	 int32_t cur_unit;
	 uint8_t num_chars = 0, cur_digit= 0, ten = 10, pos = 0;
	
	 if(num_conv_from_str == NULL_PTR || num_in_str == NULL_PTR )
	 {
		 error_flag = ERR_STR_TO_NUM_PARA;
		 return error_flag;
	 }
	 num_chars = Str_Len(num_in_str);
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - ZERO_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
		/* #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: 1: Non numeric char in str_to_num\r");
		 #endif */
		 *num_conv_from_str = 0;
         error_flag = ERR_STR_TO_NUM_PARA;		 
		 return error_flag;
	 }	
     num = place * cur_unit;
     for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
     {
         place =  place * ten;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - ZERO_CHAR;
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			/* #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: 2: Non numeric char in str_to_num \r");
		     #endif */
			  *num_conv_from_str = 0;
			 error_flag = ERR_STR_TO_NUM_PARA; 
			 return error_flag;
		 }			 
         num += (cur_unit * place);     
     }
	 *num_conv_from_str = num; 
     return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_Len(const char *const str)
{
    uint8_t num_chars = 0;
	
	  if(str == NULL_PTR)
		{
			 error_flag = ERR_STR_PTR_NULL;	
			 return 0;
		}
    while(*(str + num_chars++));
    return num_chars - 1;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Cur_Data_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.06

BUGS           :
-*------------------------------------------------------------*/
void Reset_Cur_Data_Status(const uint8_t set_cur_data_status_reset_type)
{
	switch(set_cur_data_status_reset_type)
	{
		case CUR_DATA_RESET_STATUS_WHOLE:
		  cur_data_status.cur_data_id = CUR_DATA_ID_INVALID;
	      cur_data_conf_parameter.cur_data_id = CUR_DATA_ID_INVALID;
		  cur_data_status.cur_data_input_num_try = 0;
		break;  
	}
	memset(cur_data_status.cur_data_rcvd_str, NULL_CHAR, sizeof(cur_data_status.cur_data_rcvd_str)/sizeof(char));
	cur_data_status.cur_data_num_chars_rcvd = 0;
	cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR;
	cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_NO_IN_CHAR;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Next_Data_Conf_Parameter

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.07

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Next_Data_Conf_Parameter(const set_next_data_config_t *const set_next_data_conf_ptr)
{
	if(set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv == CHARS_RCV_TILL_TERMINATOR_CHAR_MODE)
	{
		cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_TERMINATOR;
		cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
		cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
	}
	else
	{
		if(set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv <= DATA_MAX_NUM_ALLOCATED_CHARS)
		{
		   cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_ALLOCATED;
		   cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv;
		   cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv;
		}
	    else
		{
		/*	#ifdef TRACE_ERROR
			    UART_Transmit_Str("ERR: set max chars to enter > configured \r");
			#endif */
			return FAILURE;
		}
	}
    cur_data_status.cur_data_id = set_next_data_conf_ptr->set_next_data_id;
    cur_data_conf_parameter.cur_data_id = set_next_data_conf_ptr->set_next_data_id;
	cur_data_conf_parameter.cur_data_input_dev_id = set_next_data_conf_ptr->set_next_data_input_dev_id;
	cur_data_conf_parameter.cur_data_output_dev_id = set_next_data_conf_ptr->set_next_data_output_dev_id;
	cur_data_conf_parameter.cur_data_input_max_num_try = set_next_data_conf_ptr->set_next_data_input_max_num_try;
	cur_data_conf_parameter.cur_data_input_can_also_nonnum_key = set_next_data_conf_ptr->set_next_data_input_can_also_nonnum_key;
	cur_data_conf_parameter.cur_data_rcvd_char_disp_format = set_next_data_conf_ptr->set_next_data_rcvd_char_disp_format;
    return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
