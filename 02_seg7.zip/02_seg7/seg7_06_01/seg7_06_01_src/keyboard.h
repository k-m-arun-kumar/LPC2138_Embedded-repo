/**************************************************************************
   FILE          :    keyboard.h
 
   PURPOSE       :    keyboard Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _KEYBOARD_H
 #define _KEYBOARD_H
 
 /* ---------------------- macro defination ------------------------------------------------ */
 
#define ENTER_SW_CODE                           ('E')
#define BACKSPACE_SW_CODE                       ('B')

#define RCVD_CHAR_PLAIN_DISP_FORMAT              (1)
#define RCVD_CHAR_HIDDEN_DISP_FORMAT             (2)  

#define KEYPAD_ROWA_SELECT                       (1)
#define KEYPAD_ROWB_SELECT                       (2)
#define KEYPAD_ROWC_SELECT                       (3)
#define KEYPAD_ROWD_SELECT                       (4)

/* ---------------------- data type defination --------------------------------------------- */
typedef struct 
{
	uint8_t keyboard_input_enable_flag: 1;
	uint8_t keypad_keys_enable_flag   : 1;	
} keypad_sw_ctrl_t;

/* -------------------- public variable declaration --------------------------------------- */
 
extern char cur_pressed_key_or_sw;
extern keypad_sw_ctrl_t keypad_sw_ctrl;

 /* -------------------- public prototype declaration --------------------------------------- */

uint8_t Keyboard_Proc(void);
uint8_t Entered_Key_No_Long_Press_Proc(const char key_data);
void Entered_Backspace_Sw_No_Long_Press_Proc(void);
uint8_t Disable_Keyboard(void);
void After_Switch_Stoke_Proc(const char pressed_sw);
uint8_t Enable_Keyboard(void);
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
