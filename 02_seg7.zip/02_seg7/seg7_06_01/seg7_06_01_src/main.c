/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  In a keypad, when a first digit is pressed, then display is blank in a 7 segment Common Anode LED 2 digit multiplexed 
                         when a 2 digit is pressed in keypad, then display that number with first pressed key as Tens digit value in a 7 segment 
												 Common Anode LED 2 digit multiplexed. 
                                                  
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  :  FOR reusable firmware development and data can be inputed only by single input source and outputed only to  single output source
                      
CAUTION               :  
                                    
CHANGE LOGS           :  data can be inputed by multi input source and outputed to multi output source in simple manner in given in seg7_06_2.

FILE ID               : 01

*****************************************************************************/
#include <string.h> 
#include "main.h"
#include "port_pins_map.h"
#include "keyboard.h"
#include "seg7_lib.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
value_t to_disp;
uint32_t error_flag = NO_ERROR;
sw_para_t sw_para[ NUM_SW_CHS];
cur_data_conf_parameter_t cur_data_conf_parameter;
cur_data_status_parameter_t cur_data_status;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t System_Init(void);
static uint8_t Appl_Init(const void *const data_ptr);
static uint8_t HW_Init(const void *const get_init_ptr);
static uint8_t PLL_Init(void);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint32_t seg7_disp_num = 0;
	uint8_t ret_status;
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return ret_status;
	}	
    if((ret_status = Appl_Init(NULL_PTR)) != SUCCESS)
	{
		  return ret_status;
    }		
	while(1)
	{	
		    ret_status = Keyboard_Proc();
				switch(ret_status)
				{
					case KEYPAD_DATA_READY:
						 if((ret_status = Str_to_Num_Conv(&seg7_disp_num, cur_data_status.cur_data_rcvd_str)) != SUCCESS)
						 {
							 return FAILURE;
						 }
					 	Reset_Parameters();
						Seg7_Disp_2Digit_Num(seg7_disp_num);	
            Enable_Keyboard();	
				  break;
          case SUCCESS:
          case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:
					case KEYPAD_REACH_MAX_CHARS_WAIT_TERMINATOR_KEY:
          case ERR_SW_NOT_PRESSED:
          break;
		  case KEYPAD_PRESSED_KEY_DETECT:
		     if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR) 
             {
	             if((ret_status = IO_Channel_Write(IO_CH_SEG7_UNIT_DIGIT,  STATE_LOW)) != SUCCESS)
		         {
			         return ret_status;										  
		         }
                 if((ret_status = IO_Channel_Write(IO_CH_SEG7_TENS_DIGIT,  STATE_LOW)) != SUCCESS)
		         {
			        return ret_status;										  
		         }	
	         } 	 
		  break;		   
          default:
           return FAILURE;          
				 
			}				
	}
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t System_Init(void)
{
	return HW_Init(NULL_PTR);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Appl_Init(const void *const data_ptr)
{
	   set_next_data_config_t  set_next_data_config;
	
      Reset_Parameters();
	   set_next_data_config.set_next_data_id = CUR_DATA_ID_SEG7;
	   set_next_data_config.set_next_data_input_can_also_nonnum_key = STATE_NO_IN_CHAR;
	   set_next_data_config.set_next_data_input_dev_id = INPUT_DEV_ID_KEYBOARD;
    	set_next_data_config.set_next_data_input_max_num_try = DATA_SEG7_MAX_RETRY;
    	set_next_data_config.set_next_data_max_num_chars_to_rcv = DATA_SEG7_REQ_CHARS ;
    	set_next_data_config.set_next_data_output_dev_id = OUTPUT_DEV_ID_SEG7;
	    set_next_data_config.set_next_data_rcvd_char_disp_format = RCVD_CHAR_PLAIN_DISP_FORMAT;
      Enable_Keyboard();	
	   Next_Data_Conf_Parameter(&set_next_data_config);
	  return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t HW_Init(const void *const get_init_ptr)
{
	uint8_t ret_status = SUCCESS;
	PLL_Init();
	if((ret_status = IO_Channels_Func_Set(io_config, sizeof(io_config)/ sizeof(io_config_t))) != SUCCESS)
	  return ret_status;	
  return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.04  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
   	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.05

BUGS           :    
-*------------------------------------------------------------*/
void Reset_Parameters(void)
{
	Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_WHOLE);
  Disable_Keyboard();
	//Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
