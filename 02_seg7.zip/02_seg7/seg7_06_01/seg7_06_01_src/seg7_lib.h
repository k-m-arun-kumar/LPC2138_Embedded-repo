/**************************************************************************
   FILE          :    seg7_lib.h
 
   PURPOSE       :   
 
   AUTHOR        :     K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _SEG7_LIB_H
#define _SEG7_LIB_H

/* ---------------------- macro defination ------------------------------------------------ */
#define SEG7_COMMON_CATHODE               (0)
#define SEG7_COMMON_ANODE                 (1)

/* ---------------------- data type defination -------------------------------------------- */
typedef enum 
{
	SEG7_1_DIGIT = 1, SEG7_2_DIGIT, SEG7_3_DIGIT, SEG7_4_DIGIT, SEG7_5_DIGIT, SEG7_6_DIGIT 
} seg7_num_digit_t;

/* -------------------- public variable declaration --------------------------------------- */
 
/* -------------------- public function declaration --------------------------------------- */
uint8_t Seg7_Disp_2Digit_Num(const uint32_t seg7_rcv_disp_num);

#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
