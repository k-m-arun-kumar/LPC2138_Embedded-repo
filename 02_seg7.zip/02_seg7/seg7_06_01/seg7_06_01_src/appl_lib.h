/**************************************************************************
   FILE          :    appl_lib.h
 
   PURPOSE       :   
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_LIB_H
 #define _APPL_LIB_H
 
 #include "appl_conf.h"
 
/* ---------------------- macro defination ------------------------------------------------ */ 
#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

 /* Bit Operation macros */
     /* Set bit pos  in byte data   */
#define Set_Bit_in_Data(data , bit_pos)                         ((*(data)) |=   (1<<(bit_pos)))     
      /* Clear bit pos in byte data */ 
#define Clear_Bit_in_Data(data ,bit_pos)                         ((*(data)) &= (~(1<<(bit_pos))))      
    /* flip bit pos in byte data  */ 
#define Toggle_Bit_in_Data(data , bit_pos)                       ((*(data)) ^=   (1<<(bit_pos)))        
    /* Test if bit pos in byte data  is set   */
#define Test_Bit_Is_Set_in_Data(data ,bit_pos)                    ((*(data)) & (1<<bit_pos))       
   /* Test if bit pos in byte data is clear */  
#define Test_Bit_Is_Clear_in_Data(data ,bit_pos)                  (!((*(data)) & (1<<bit_pos))) 

#define RCVD_CHAR_DONT_DISP_FORMAT (0)
#define RCVD_CHAR_PLAIN_DISP_FORMAT (1)
#define RCVD_CHAR_HIDDEN_DISP_FORMAT (2)

#define  CUR_DATA_RESET_STATUS_WHOLE (0)
#define  CUR_DATA_RESET_STATUS_RETRY (1)

/* ---------------------- data type defination -------------------------------------------- */
typedef struct 
{
	uint32_t consucc_val;
	uint8_t start_bit_pos;
	uint8_t bits_len;
} consucc_bit_t;

typedef enum {
   CUR_DATA_RCV_MODE_TILL_ALLOCATED , CUR_DATA_RCV_MODE_TILL_TERMINATOR
} cur_data_rcv_mode_types;

typedef struct 
{
	cur_data_id_t cur_data_id;
	input_dev_id_t cur_data_input_dev_id;
	output_dev_id_t cur_data_output_dev_id;
	cur_data_rcv_mode_types cur_data_rcv_mode;
	uint8_t cur_data_conf_max_num_chars_to_rcv;
	uint8_t cur_data_allocated_max_num_chars_to_rcv;
	uint8_t cur_data_input_max_num_try; 
	char cur_data_input_can_also_nonnum_key;
	uint8_t cur_data_rcvd_char_disp_format;
}cur_data_conf_parameter_t; 

typedef struct
{
	 cur_data_id_t set_next_data_id;
   input_dev_id_t set_next_data_input_dev_id;
   output_dev_id_t set_next_data_output_dev_id; 
   uint8_t set_next_data_max_num_chars_to_rcv;
   uint8_t set_next_data_input_max_num_try;
   char set_next_data_input_can_also_nonnum_key; 
   uint8_t set_next_data_rcvd_char_disp_format; 
} set_next_data_config_t; 
	
typedef struct cur_data_status_parameter_types
{
	cur_data_id_t cur_data_id;
	uint8_t cur_data_num_chars_rcvd;
	uint8_t cur_data_input_num_try;
	char cur_data_rcvd_str[DATA_MAX_NUM_ALLOCATED_CHARS + 1];
	char cur_data_valid_end_rcvd_flag;
	char cur_data_max_allocated_num_chars_rcvd_flag;
}cur_data_status_parameter_t;  

/* -------------------- public variable declaration --------------------------------------- */
 extern cur_data_conf_parameter_t cur_data_conf_parameter;
 extern cur_data_status_parameter_t cur_data_status;
 
/* -------------------- public function declaration --------------------------------------- */
 
void SW_Time_Delay(const uint32_t max_i_count, const uint32_t max_j_count);
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr);
uint8_t Test_Consucc_Bits(const uint8_t flag_consucc_bit, const void *const data_ptr );
uint8_t Str_to_Num_Conv(uint32_t *const num_conv_from_str, const char *const num_in_str );
uint8_t Str_Len(const char *const str);
void Reset_Parameters(void);
void Reset_Cur_Data_Status(uint8_t set_cur_data_status_reset_type);
uint8_t Next_Data_Conf_Parameter(const set_next_data_config_t *const set_next_data_conf_ptr);
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
