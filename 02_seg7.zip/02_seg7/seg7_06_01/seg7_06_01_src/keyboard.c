/**************************************************************************
   FILE          :    keyboard.c
 
   PURPOSE       :     
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 04  
	   
 **************************************************************************/
  
 #include "main.h" 
 
 #ifdef KEYPAD_MOD_ENABLE
 #include "keyboard.h" 
 #include <string.h>

 
/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
char cur_pressed_key_or_sw;
keypad_sw_ctrl_t keypad_sw_ctrl;

/* ----------------------------- global variable declaration -------------------- */



/* ----------------------------- global function declaration -------------------- */
static uint8_t KeyBoard_Col_Scan(const uint8_t select_row );

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : switch debounce, long key press and no key press timeout is not implemented.                 

Func ID        : 04.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t Keyboard_Proc(void)
{
		uint8_t ret_status = SUCCESS, error_status_flag = STATE_NO;
	
	   if(cur_data_conf_parameter.cur_data_input_dev_id != INPUT_DEV_ID_KEYBOARD || keypad_sw_ctrl.keyboard_input_enable_flag != STATE_YES) 
	   {  
          error_flag = ERR_KEYPAD_NO_ACCESS;	
          return  error_flag;
	   }		  
          switch( cur_data_conf_parameter.cur_data_rcv_mode) 
	      {
			 //enter data till enter key is pressed
		     case CUR_DATA_RCV_MODE_TILL_TERMINATOR:
	           if(cur_data_status.cur_data_num_chars_rcvd + 1 > KEYPAD_CONF_MAX_NUM_CHARS_ENTERED)
	           {
		           cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_YES_IN_CHAR;
                   cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR; 
			       return KEYPAD_REACH_MAX_CHARS_WAIT_TERMINATOR_KEY;
		       }
		     break;
			 //enter data till max nums of chars is reached
             case CUR_DATA_RCV_MODE_TILL_ALLOCATED:	
         		if(cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv > KEYPAD_CONF_MAX_NUM_CHARS_ENTERED ) 
		        {
						  	error_flag = ERR_KEYPAD_EXCEEDS_CHARS;
				        return error_flag;
						}
			       if(cur_data_status.cur_data_num_chars_rcvd >= cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv)
			       {
				               cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = NULL_CHAR;	
                       cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR;
                       cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_YES_IN_CHAR; 
                       return KEYPAD_DATA_READY; 							 
			       }				
		     break;
		  }
	   		  
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWA,  STATE_LOW)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	         
             goto KEYPAD_ROW_INVALID_WRITE;
		}		
	    if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWB,  STATE_HIGH)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	
             goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWC,  STATE_HIGH)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	
             goto KEYPAD_ROW_INVALID_WRITE; 
		}
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWD,  STATE_HIGH)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;
		}
        ret_status = KeyBoard_Col_Scan(KEYPAD_ROWA_SELECT);
		switch(ret_status)
		{
		  case KEYPAD_DATA_READY:
			case KEYPAD_PRESSED_KEY_DETECT:
				return ret_status;
			//break;	
			case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			case ERR_SW_NOT_PRESSED:
			break;	
			default:
			  return ERR_KEYBOARD_PROC;
		} 
		
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWA,  STATE_HIGH)) != SUCCESS)
		{	
              error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWB,  STATE_LOW)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;     			
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWC,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;
		}
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWD,  STATE_HIGH)) != SUCCESS)
		{		
              error_status_flag = ERR_KEYPAD_ROW_WRITE;	     	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        ret_status = KeyBoard_Col_Scan(KEYPAD_ROWB_SELECT);
		switch(ret_status)
		{
		  	case KEYPAD_DATA_READY:
			  case KEYPAD_PRESSED_KEY_DETECT:
			   	return ret_status;
			    //break;	
		  	case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			  case ERR_SW_NOT_PRESSED:
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		} 
		
		
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWA,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWB,  STATE_HIGH)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE; 
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWC,  STATE_LOW)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWD,  STATE_HIGH)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        ret_status = KeyBoard_Col_Scan(KEYPAD_ROWC_SELECT);
		switch(ret_status)
		{
		    case KEYPAD_DATA_READY:
			  case KEYPAD_PRESSED_KEY_DETECT:
			   	return ret_status;
			    //break;	
		  	case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			  case ERR_SW_NOT_PRESSED:
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		} 
		          
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWA,  STATE_HIGH)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWB,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWC,  STATE_HIGH)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
		if((ret_status = IO_Channel_Write(IO_CH_KEYPAD_ROWD,  STATE_LOW)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
		ret_status = KeyBoard_Col_Scan(KEYPAD_ROWD_SELECT); 
		switch(ret_status)
		{
		    case KEYPAD_DATA_READY:
			  case KEYPAD_PRESSED_KEY_DETECT:			   
		  	case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			  case ERR_SW_NOT_PRESSED:
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		}
KEYPAD_ROW_INVALID_WRITE: 
   switch(error_status_flag)
   {
	   case ERR_KEYPAD_ROW_WRITE:
         error_flag = ERR_KEYBOARD_PROC;	
         ret_status = error_flag;
		     Disable_Keyboard();
	   break;	 
   }
   return ret_status;	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used
                 
Func ID        : 04.02  

BUGS           :     
-*------------------------------------------------------------*/
static uint8_t KeyBoard_Col_Scan(const uint8_t select_row )
{
	uint8_t ret_status = SUCCESS, key_pressed_flag = STATE_NO;
	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
	
	if(keypad_sw_ctrl.keypad_keys_enable_flag != STATE_YES)
	{
		  error_flag = ERR_KEYPAD_NO_ACCESS;	
      return  error_flag;
	}
	if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_YES_IN_CHAR || cur_data_status.cur_data_valid_end_rcvd_flag == STATE_YES_IN_CHAR)
	{
		  return KEYPAD_DATA_READY;
	}
	if((ret_status = SW_Pressed_Proc(IO_CH_KEYPAD_COL1)) == SUCCESS)
	{
		switch(select_row)
	   {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch
			     key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch
			     key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWD_SELECT:
             if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
		         {													
		           cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch
				       key_pressed_flag = STATE_YES;
			       break;
		        }
                return ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED;   			 	
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		}
    goto KEY_PRESSED_PROC;		 
	}
    if((ret_status = SW_Pressed_Proc(IO_CH_KEYPAD_COL2)) == SUCCESS)
  	{
		switch(select_row)
	    {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch
			     key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWD_SELECT:
               cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch
			       key_pressed_flag = STATE_YES;
          break;					
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		} 
    goto KEY_PRESSED_PROC;				
	}
   if((ret_status = SW_Pressed_Proc(IO_CH_KEYPAD_COL3)) == SUCCESS)
	{
		switch(select_row)
	    {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWD_SELECT:
                if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
		        {													
		           cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch
				       key_pressed_flag = STATE_YES;
			       break;
		        }
                return ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED;   			 	
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
			} 
	}
	KEY_PRESSED_PROC:
   if(key_pressed_flag == STATE_YES)
   {
		  if(( ret_status = Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw)) != SUCCESS)
	    {
	        return ret_status;
	    } 		
	   return KEYPAD_PRESSED_KEY_DETECT;
   }
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Entered_Key_No_Long_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : make sure that entered key is within max available lcd loc and line, currently cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv 
	 sures that entered key is within max available lcd loc and within max line 

Func ID        : 04.03

BUGS           :   
-*------------------------------------------------------------*/
uint8_t Entered_Key_No_Long_Press_Proc(const char cur_key_char)
{	
   uint8_t ret_status = SUCCESS;   
   
   cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = cur_key_char;   
   ++cur_data_status.cur_data_num_chars_rcvd;   	
   return ret_status; 	  
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Keyboard_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.04  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_Keyboard(void)
{
	 keypad_sw_ctrl.keyboard_input_enable_flag = STATE_NO;
	 keypad_sw_ctrl.keypad_keys_enable_flag = STATE_NO;	
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Keyboard_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.05  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Enable_Keyboard(void)
{
	 sw_para_t *sw_para_ptr = NULL_PTR;
	 uint8_t sw_ch_index, ret_status = SUCCESS;	
   
  if((ret_status = IO_Ch_To_SW_Ch(IO_CH_KEYPAD_COL1, &sw_ch_index )) != SUCCESS)
	{
		   return ret_status;
	}
	sw_para_ptr = sw_para + sw_ch_index;
  sw_para_ptr->sw_enable = STATE_YES;	
	if((ret_status = IO_Ch_To_SW_Ch(IO_CH_KEYPAD_COL2, &sw_ch_index )) != SUCCESS)
	{
		   return ret_status;
	}
	sw_para_ptr = sw_para + sw_ch_index; 
 	sw_para_ptr->sw_enable = STATE_YES;	
	if((ret_status = IO_Ch_To_SW_Ch(IO_CH_KEYPAD_COL3, &sw_ch_index )) != SUCCESS)
	{
		   return ret_status;
	}
	 sw_para_ptr = sw_para + sw_ch_index;   
   sw_para_ptr->sw_enable = STATE_YES;	
   keypad_sw_ctrl.keypad_keys_enable_flag = STATE_YES;	
	 keypad_sw_ctrl.keyboard_input_enable_flag = STATE_YES;
	 return SUCCESS;
}

#endif
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
