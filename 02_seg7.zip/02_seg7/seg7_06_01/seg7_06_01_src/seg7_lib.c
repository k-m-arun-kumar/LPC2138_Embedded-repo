/* ********************************************************************
FILE                   : seg7_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 06 

*****************************************************************************/

#include "main.h"
#ifdef SEG7_MOD_ENABLE
#include <string.h>
#include "seg7_lib.h"


/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */


/* ----------------------------- global variable declaration -------------------- */



/* ----------------------------- global function declaration -------------------- */

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_2Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.08 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Seg7_Disp_2Digit_Num(const uint32_t seg7_rcv_disp_num)
{
	  	uint32_t seg7_num = seg7_rcv_disp_num;		
		uint8_t seg7_digit[10],unit_digit, ten_digit, port, port_pin, ret_status = SUCCESS;
		consucc_bit_t consucc_bit_data;	
		
		#if SEG7_2DIGIT_TYPE == SEG7_COMMON_CATHODE
	      uint8_t cc_digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
		  memcpy(seg7_digit, cc_digit, sizeof(cc_digit)/ sizeof(uint8_t) );
	   #elif SEG7_2DIGIT_TYPE == SEG7_COMMON_ANODE
		  uint8_t ca_digit[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
	      memcpy(seg7_digit, ca_digit, sizeof(ca_digit)/ sizeof(uint8_t) );   
	  #endif
		
		 port_pin = IO_CH_SEG7_A_LED % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
         consucc_bit_data.bits_len = 8;
        	   
		seg7_num %= 100;
		ten_digit = seg7_num / 10;				
		if((ret_status = IO_Channel_Write(IO_CH_SEG7_UNIT_DIGIT,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
        if((ret_status = IO_Channel_Write(IO_CH_SEG7_TENS_DIGIT,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		}  			
					  
		 consucc_bit_data.consucc_val = seg7_digit[ten_digit];
		 if((ret_status = Port_Write(IO_CH_SEG7_A_LED, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);			 
		  	
		unit_digit = seg7_num % 10;
		if((ret_status = IO_Channel_Write(IO_CH_SEG7_UNIT_DIGIT,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
        if((ret_status = IO_Channel_Write(IO_CH_SEG7_TENS_DIGIT,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 	 
		consucc_bit_data.consucc_val = seg7_digit[unit_digit];
		if((ret_status = Port_Write(IO_CH_SEG7_A_LED, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }
       SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY); 
	   return SUCCESS;
}
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
