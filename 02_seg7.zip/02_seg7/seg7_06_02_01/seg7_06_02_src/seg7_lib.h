/**************************************************************************
   FILE          :    seg7_lib.h
 
   PURPOSE       :   
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _SEG7_LIB_H
#define _SEG7_LIB_H

/* ---------------------- macro defination ------------------------------------------------ */
#define SEG7_COMMON_CATHODE               (0)
#define SEG7_COMMON_ANODE                 (1)

/* ---------------------- data type defination -------------------------------------------- */
typedef enum 
{
	SEG7_1_DIGIT = 1, SEG7_2_DIGIT, SEG7_3_DIGIT, SEG7_4_DIGIT, SEG7_5_DIGIT, SEG7_6_DIGIT 
} seg7_num_digit_t;

typedef struct 
{
	uint8_t io_ch_a_led;
	uint8_t io_ch_unit_digit;
	uint8_t access_flag              : 1; 
	uint8_t enable_flag              : 1;
	uint8_t seg7_type                : 1; 
  seg7_num_digit_t num_digits  	   : 3;
	uint8_t                          : 2;
} seg7_ctrl_t;


typedef uint8_t (*seg7_disp_num_ptr_t)(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);

/* -------------------- public variable declaration --------------------------------------- */
 extern seg7_ctrl_t seg7_ctrl[NUM_OUTPUT_DEV_ID_SEG7_CHS];

/* -------------------- public function declaration --------------------------------------- */
uint8_t Seg7_Proc(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);

uint8_t Disable_Seg7(const uint8_t seg7_ch_id);
uint8_t Enable_Seg7(const uint8_t seg7_ch_id);
uint8_t Disable_All_Seg7s(void);
uint8_t Seg7_Allow_Access(const uint8_t seg7_ch_id);
uint8_t Seg7_No_Access(const uint8_t seg7_ch_id);
#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
