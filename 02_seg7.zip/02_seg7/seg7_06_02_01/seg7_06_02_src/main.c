/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  In a keypad, when a first digit is pressed, then display is blank in a 7 segment Common Anode LED 2 digit multiplexed 
                         when a 2 digit is pressed in keypad, then display that number with first pressed key as Tens digit value in a 7 segment 
												 Common Anode LED 2 digit multiplexed. 
                                                  
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : TESTED OK on ARM BOARD.
                        FOR reusable firmware development and data can be inputed by multi input source and outputed to multi output source.                        
                      
CAUTION               :  
                                    
CHANGE LOGS           : modified from seg_06_01. 

YET TO IMPLEMENT      : Keyboard_Proc(keyboard_ch_id, data_id) is to be modified as Keyboard_Proc(keyboard_ch_id, *pressed_key_ptr) and Data_Dev_Src_Allow_Access()
						is to modified with function pointer based calling source's appropiate function.

FILE ID               : 01

*****************************************************************************/
#include <string.h> 
#include "main.h"
#include "port_pins_map.h"
#include "keyboard.h"
#include "seg7_lib.h"
#include "dev_chs_map.h"
#include "appl_conf.h"
/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
value_t to_disp;
uint32_t error_flag = NO_ERROR;
sw_para_t sw_para[ NUM_INPUT_DEV_ID_SW_CHS];
data_id_status_para_t data_id_status_para[NUM_DATA_IDS];
uint8_t cur_data_id = DATA_ID_INVALID;


/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t System_Init(void);
static uint8_t Appl_Init(const void *const data_ptr);
static uint8_t HW_Init(const void *const get_init_ptr);
static uint8_t PLL_Init(void);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint32_t seg7_disp_num = 0;
	uint8_t ret_status;
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return ret_status;
	}	
    if((ret_status = Appl_Init(NULL_PTR)) != SUCCESS)
	{
		  return ret_status;
    }		
	while(1)
	{	
		switch(cur_data_id)
		{
			case DATA_ID_SEG7:
		    ret_status = Keyboard_Proc(CH_ID_00, cur_data_id);
				switch(ret_status)
				{
					case KEYPAD_DATA_READY:
						 if((ret_status = Str_to_Num_Conv(&seg7_disp_num, data_id_status_para[cur_data_id].data_str)) != SUCCESS)
						 {
							 return FAILURE;
						 }
                        Disable_Keyboard(CH_ID_00);
			            Enable_Seg7(CH_ID_00);
				  	    Reset_Data_ID_Status(cur_data_id, DATA_ID_RESET_WHOLE_STATUS);
						 if((ret_status = Seg7_Proc(CH_ID_00, seg7_disp_num)) != SUCCESS)
						 {
                   return ret_status;
						 }						   
             Enable_Keyboard(CH_ID_00);	
				  break;
          case SUCCESS:
          case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:
          case ERR_KEYPAD_DISABLED:
		      case KEYPAD_REACH_MAX_CHARS_WAIT_TERMINATOR_KEY:
          case ERR_SW_NOT_PRESSED:
          break;
		      case KEYPAD_PRESSED_KEY_DETECT:
		         if(data_id_status_para[cur_data_id].reach_max_alloc_input_chars_flag == STATE_NO) 
                 {
					if((ret_status = IO_Channel_Write(seg7_ctrl[CH_ID_00].io_ch_unit_digit,  STATE_LOW)) != SUCCESS)
		            {
			           return ret_status;										  
		            }	 
	                Disable_Seg7(CH_ID_00);
	             } 	 
		      break;		   
          default:
            return FAILURE; 
		  	}
        break;				
		 }				
	}
	EXIT_MAIN:
	return FAILURE;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Appl_Init(const void *const data_ptr)
{
	    Reset_Parameters();
	    Data_IDs_Set_Para();    
	    Next_Data_Conf_Parameter(DATA_ID_SEG7);
	    return SUCCESS; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : Next_Data_Conf_Parameter

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Next_Data_Conf_Parameter(const uint8_t set_data_id)
{
   static uint8_t prev_data_id = DATA_ID_INVALID;
	
	 prev_data_id = cur_data_id;
	 switch(cur_data_id)
	 {
		  case DATA_ID_INVALID:
		  	cur_data_id = DATA_ID_SEG7;           
      break;		 
	 }	
	#ifndef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
    Data_Dev_Src_Allow_Access(prev_data_id); 
    #endif	
    return SUCCESS;
}
#ifndef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
/*------------------------------------------------------------*
FUNCTION NAME  : Data_Dev_Src_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.04

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_Dev_Src_Allow_Access(const uint8_t prev_data_id)
{
	uint8_t dev_id, dev_ch_id, i = 0, ret_status = SUCCESS;
	
	 if(cur_data_id == prev_data_id)
	 {
		  error_flag = ERR_PREV_AND_CUR_DATA_MATCH;
		  return error_flag;
	 }
	 if(prev_data_id < NUM_DATA_IDS)
	 {
   		 dev_id =  data_ids_dev_srcs[prev_data_id].data_input_dev_ids[i].dev_id;
		   while(dev_id < NUM_INPUT_DEVS)
			 {
				  dev_ch_id = data_ids_dev_srcs[prev_data_id].data_input_dev_ids[i].dev_ch_id;
				  switch(dev_id)
					{
					  	#ifdef USART_MOD_ENABLE
			        case INPUT_DEV_ID_UART:
								if(dev_ch_id >= NUM_INPUT_DEV_ID_UART_CHS)
								{
										error_flag = ERR_DEV_CH_ID_EXCEEDS;
										return error_flag;
								}
									/* disable uart for dev_ch_id channel */
						 break;
              #endif								
							#ifdef I2C_MOD_ENABLE
						 case INPUT_DEV_ID_I2C:
								if(dev_ch_id >= NUM_INPUT_DEV_ID_I2C_CHS)
				        {
					        error_flag = ERR_DEV_CH_ID_EXCEEDS;
					        return error_flag;
				        }
			      	break;
							#endif
							#ifdef SPI_MOD_ENABLE
			      	case INPUT_DEV_ID_SPI:
				      if(dev_ch_id >= NUM_INPUT_DEV_ID_SPI_CHS)
				      {
					        error_flag = ERR_DEV_CH_ID_EXCEEDS;
					        return error_flag;
				      }
			      	break;
							#endif
			      	case INPUT_DEV_ID_MISC:
				         if(dev_ch_id >= NUM_INPUT_DEV_ID_MISC_CHS)
				         {
					          error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				         }
			      	break;
							#ifdef ADC_MOD_ENABLE	 
			      	case INPUT_DEV_ID_ADC:
			       	  if(dev_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
			      	  {
				       	  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					        return error_flag;
				        }
			      	break;
							#endif
							#ifdef KEYPAD_MOD_ENABLE
			      	case INPUT_DEV_ID_KEYBOARD:
			      	  if((ret_status = Keyboard_No_Access(dev_ch_id)) != SUCCESS)
			      	  {
				       	   error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
				      break;
						 	#endif
			      	case INPUT_DEV_ID_SW:
				         if(dev_ch_id >= NUM_INPUT_DEV_ID_SW_CHS)
				         {
				        	  error_flag = ERR_DEV_CH_ID_EXCEEDS;
				        	  return error_flag;
				         }
			       	break;
			      	default:
			       	  error_flag = ERR_DATA_ID_CONF;
			      	  return error_flag;
		      	}
				    ++i;
				    dev_id =  data_ids_dev_srcs[prev_data_id].data_input_dev_ids[i].dev_id; 
			 }
			 i = 0;
			 
			 dev_id =  data_ids_dev_srcs[prev_data_id].data_output_dev_ids[i].dev_id;
		   while(dev_id < NUM_OUTPUT_DEVS)
			 {
				  dev_ch_id = data_ids_dev_srcs[prev_data_id].data_output_dev_ids[i].dev_ch_id;
			    switch(dev_id)
			    {
							#ifdef USART_MOD_ENABLE
			      	case OUTPUT_DEV_ID_UART:
				        if(dev_ch_id >= NUM_OUTPUT_DEV_ID_UART_CHS)
				        {
					         error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
			       	break;
              #endif
							#ifdef I2C_MOD_ENABLE
			      	case OUTPUT_DEV_ID_I2C:
			      	   if(dev_ch_id >= NUM_OUTPUT_DEV_ID_I2C_CHS)
				         {
					           error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				         }
				      break; 
							 #endif
							 #ifdef SPI_MOD_ENABLE
			      	case OUTPUT_DEV_ID_SPI:
			         	if(dev_ch_id >= NUM_OUTPUT_DEV_ID_SPI_CHS)
			      	   {
				        	  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				         }
				       break;
			     		#endif
			      	case OUTPUT_DEV_ID_MISC:
			         	if(dev_ch_id >= NUM_OUTPUT_DEV_ID_MISC_CHS)
				        {
					         error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
				      break;
							#ifdef 	DAC_MOD_ENABLE
			      	case OUTPUT_DEV_ID_DAC:
			         	if(dev_ch_id >= NUM_OUTPUT_DEV_ID_DAC_CHS)
				        {
					         error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				        }
				      break;
							#endif
              #ifdef PWM_MOD_ENABLE								
				      case OUTPUT_DEV_ID_PWM:
				         if(dev_ch_id >= NUM_OUTPUT_DEV_ID_PWM_CHS)
				          {
					           error_flag = ERR_DEV_CH_ID_EXCEEDS;
					           return error_flag;
				         }
			      	break;
							#endif
							#ifdef LCD_MOD_ENABLE
			      	case OUTPUT_DEV_ID_LCD:
				         if(dev_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
				         {
					            error_flag = ERR_DEV_CH_ID_EXCEEDS;
					           return error_flag;
				         }
				      break;
							#endif
							#ifdef SEG7_MOD_ENABLE
			      	case OUTPUT_DEV_ID_SEG7:
			         	if((ret_status = Seg7_No_Access(dev_ch_id)) != SUCCESS)
			      	  {
				       	   error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
				      break;
							#endif
			      	default:
				          error_flag = ERR_DATA_ID_CONF;
				        return error_flag;
			     }
			    ++i;
			    dev_id =  data_ids_dev_srcs[prev_data_id].data_output_dev_ids[i].dev_id; 
	    } 
   }
	 i = 0;	    
	 if(cur_data_id < NUM_DATA_IDS)
	 {
   		 dev_id =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i].dev_id;
		   while(dev_id < NUM_INPUT_DEVS)
			 {
				  dev_ch_id = data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i].dev_ch_id;
				  switch(dev_id)
					{
					  	#ifdef USART_MOD_ENABLE
			       case INPUT_DEV_ID_UART:
								if(dev_ch_id >= NUM_INPUT_DEV_ID_UART_CHS)
								{
										error_flag = ERR_DEV_CH_ID_EXCEEDS;
										return error_flag;
								}
									/* enable uart for dev_ch_id channel */
						 break;
              #endif								
							#ifdef I2C_MOD_ENABLE
						 case INPUT_DEV_ID_I2C:
								if(dev_ch_id >= NUM_INPUT_DEV_ID_I2C_CHS)
				        {
					        error_flag = ERR_DEV_CH_ID_EXCEEDS;
					        return error_flag;
				        }
			      	break;
							#endif
							#ifdef SPI_MOD_ENABLE
			      	case INPUT_DEV_ID_SPI:
				      if(dev_ch_id >= NUM_INPUT_DEV_ID_SPI_CHS)
				      {
					        error_flag = ERR_DEV_CH_ID_EXCEEDS;
					        return error_flag;
				      }
			      	break;
							#endif
			      	case INPUT_DEV_ID_MISC:
				         if(dev_ch_id >= NUM_INPUT_DEV_ID_MISC_CHS)
				         {
					          error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				         }
			      	break;
							#ifdef ADC_MOD_ENABLE	 
			      	case INPUT_DEV_ID_ADC:
			       	  if(dev_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
			      	  {
				       	  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					        return error_flag;
				        }
			      	break;
							#endif
							#ifdef KEYPAD_MOD_ENABLE
			      	case INPUT_DEV_ID_KEYBOARD:
			      	  if((ret_status = Keyboard_Allow_Access(dev_ch_id)) != SUCCESS)
			      	  {
				       	   error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
                 Enable_Keyboard(dev_ch_id);  
				      break;
						 	#endif
			      	case INPUT_DEV_ID_SW:
				         if(dev_ch_id >= NUM_INPUT_DEV_ID_SW_CHS)
				         {
				        	  error_flag = ERR_DEV_CH_ID_EXCEEDS;
				        	  return error_flag;
				         }
			       	break;
			      	default:
			       	  error_flag = ERR_DATA_ID_CONF;
			      	  return error_flag;
		      	}
				    ++i;
				    dev_id =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i].dev_id; 
			 }
			 i = 0;
			 
			 dev_id =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i].dev_id;
		   while(dev_id < NUM_OUTPUT_DEVS)
			 {
				  dev_ch_id = data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i].dev_ch_id;
			    switch(dev_id)
			    {
							#ifdef USART_MOD_ENABLE
			      	case OUTPUT_DEV_ID_UART:
				        if(dev_ch_id >= NUM_OUTPUT_DEV_ID_UART_CHS)
				        {
					         error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
			       	break;
              #endif
							#ifdef I2C_MOD_ENABLE
			      	case OUTPUT_DEV_ID_I2C:
			      	   if(dev_ch_id >= NUM_OUTPUT_DEV_ID_I2C_CHS)
				         {
					           error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				         }
				      break; 
							 #endif
							 #ifdef SPI_MOD_ENABLE
			      	case OUTPUT_DEV_ID_SPI:
			         	if(dev_ch_id >= NUM_OUTPUT_DEV_ID_SPI_CHS)
			      	   {
				        	  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				         }
				       break;
			     		#endif
			      	case OUTPUT_DEV_ID_MISC:
			         	if(dev_ch_id >= NUM_OUTPUT_DEV_ID_MISC_CHS)
				        {
					         error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }
				      break;
							#ifdef 	DAC_MOD_ENABLE
			      	case OUTPUT_DEV_ID_DAC:
			         	if(dev_ch_id >= NUM_OUTPUT_DEV_ID_DAC_CHS)
				        {
					         error_flag = ERR_DEV_CH_ID_EXCEEDS;
					          return error_flag;
				        }
				      break;
							#endif
              #ifdef PWM_MOD_ENABLE								
				      case OUTPUT_DEV_ID_PWM:
				         if(dev_ch_id >= NUM_OUTPUT_DEV_ID_PWM_CHS)
				          {
					           error_flag = ERR_DEV_CH_ID_EXCEEDS;
					           return error_flag;
				         }
			      	break;
							#endif
							#ifdef LCD_MOD_ENABLE
			      	case OUTPUT_DEV_ID_LCD:
				         if(dev_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
				         {
					            error_flag = ERR_DEV_CH_ID_EXCEEDS;
					           return error_flag;
				         }
				      break;
							#endif
							#ifdef SEG7_MOD_ENABLE
			      	case OUTPUT_DEV_ID_SEG7:
			         	if((ret_status = Seg7_Allow_Access(dev_ch_id)) != SUCCESS)
			      	    {
				       	   error_flag = ERR_DEV_CH_ID_EXCEEDS;
					         return error_flag;
				        }                        
				      break;
							#endif
			      	default:
				          error_flag = ERR_DATA_ID_CONF;
				        return error_flag;
			     }
			    ++i;
			    dev_id =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i].dev_id; 
	    } 
   }
	 
    return SUCCESS;
}
#endif
/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.05

BUGS           :    
-*------------------------------------------------------------*/
void Reset_Parameters(void)
{
	Reset_Data_IDs_Status();
    #ifdef KEYPAD_MOD_ENABLE	
       Disable_All_Keyboards();
	#endif
	#ifdef SEG7_MOD_ENABLE
	    Disable_All_Seg7s();
	#endif
	//Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.06  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t System_Init(void)
{
	return HW_Init(NULL_PTR);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.07  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t HW_Init(const void *const get_init_ptr)
{
	uint8_t ret_status = SUCCESS;
	PLL_Init();
	if((ret_status = IO_Channels_Func_Set(io_config, sizeof(io_config)/ sizeof(io_config_t))) != SUCCESS)
	  return ret_status;	
  return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.08  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
   	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
