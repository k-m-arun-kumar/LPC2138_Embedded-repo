/* ********************************************************************
FILE                   : seg7_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 06 

*****************************************************************************/

#include "main.h"
#ifdef SEG7_MOD_ENABLE
#include <string.h>
#include "seg7_lib.h"
#include "appl_conf.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */

/* ----------------------------- global variable declaration -------------------- */

/* ----------------------------- global function declaration -------------------- */
static uint8_t Seg7_Disp_1Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);
static uint8_t Seg7_Disp_2Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);
static uint8_t Seg7_Disp_3Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);
static uint8_t Seg7_Disp_4Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);
static uint8_t Seg7_Disp_5Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);
static uint8_t Seg7_Disp_6Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num);

/* ----------------------------- const function pointer defination --------------- */
seg7_disp_num_ptr_t Seg7_Disp_Num_Ptr[] = {NULL_PTR, Seg7_Disp_1Digit_Num, Seg7_Disp_2Digit_Num, Seg7_Disp_3Digit_Num, Seg7_Disp_4Digit_Num, Seg7_Disp_5Digit_Num, Seg7_Disp_6Digit_Num };


/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_2Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.01 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Seg7_Proc(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
    uint8_t ret_status = SUCCESS;
  
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS )
		 {
			   error_flag = ERR_DEV_CH_ID_EXCEEDS;
			   return error_flag;
		 }		 
     cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
	 
	 #ifndef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
     if(  cur_seg7_ctrl_ptr->access_flag != STATE_YES) 
	   {  
          error_flag = ERR_DEV_CH_ID_NO_ACCESS;	
          return  error_flag;
	   }
	 #endif
	 
	   if( cur_seg7_ctrl_ptr->enable_flag != STATE_YES) 
	   {  
          error_flag = ERR_SEG7_DISABLED;	
          return  error_flag;
	   }
     if(cur_seg7_ctrl_ptr->num_digits > SEG7_6_DIGIT || Seg7_Disp_Num_Ptr[cur_seg7_ctrl_ptr->num_digits] == NULL_PTR)
     {
          error_flag = ERR_NULL_PTR;
          return error_flag;
     }
     ret_status = (*Seg7_Disp_Num_Ptr[cur_seg7_ctrl_ptr->num_digits])(seg7_ch_id, seg7_rcv_disp_num);      
     return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_1Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.02 

BUGS           :
-*------------------------------------------------------------*/
static uint8_t Seg7_Disp_1Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
	  uint32_t seg7_num = seg7_rcv_disp_num;		
	  consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
		uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, unit_digit,  port, port_pin, ret_status = SUCCESS;
    
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	  {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	  }
    cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
    
		seg7_num %= 10;
		unit_digit = seg7_num ;				
		
    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		}  			
		 port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
     consucc_bit_data.bits_len = 8;	
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[unit_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[unit_digit];
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);
	   return SUCCESS;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_2Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.03 

BUGS           :
-*------------------------------------------------------------*/
static uint8_t Seg7_Disp_2Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
	  uint32_t seg7_num = seg7_rcv_disp_num;		
	  consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
		uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, unit_digit, ten_digit, port, port_pin, ret_status = SUCCESS;
   	
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	  {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	  }
    cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
		
    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_LOW)) != SUCCESS)
	{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
	}
    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1, STATE_LOW )) != SUCCESS)
	{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
	}  	
		seg7_num %= 100;
		ten_digit = seg7_num / 10;				
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit, STATE_LOW )) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		}  			
		 port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
     consucc_bit_data.bits_len = 7;	
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[ten_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[ten_digit] & 0xFF;
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);			 
		  	
		unit_digit = seg7_num % 10;
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
        
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[unit_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[unit_digit] & 0xFF;;
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }
       SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY); 
	   return SUCCESS;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_3Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.04 

BUGS           :
-*------------------------------------------------------------*/
static uint8_t Seg7_Disp_3Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
	  uint32_t seg7_num = seg7_rcv_disp_num;		
	  consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
		uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, hund_digit, port, port_pin, ret_status = SUCCESS;
    
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	  {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	  }
    cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
    
		seg7_num %= 1000;
		hund_digit = seg7_num / 100;				
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
       if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 2,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		 port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
     consucc_bit_data.bits_len = 8;	
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[hund_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[hund_digit] & 0xFF;;
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);
		
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 2,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		
		ret_status = Seg7_Disp_2Digit_Num(seg7_ch_id, seg7_rcv_disp_num);
        return  ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_4Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.05 

BUGS           :
-*------------------------------------------------------------*/
static uint8_t Seg7_Disp_4Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
	  uint32_t seg7_num = seg7_rcv_disp_num;		
	  consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
		uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, ten_hund_digit, port, port_pin, ret_status = SUCCESS;
    
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	  {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	  }
    cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
    
	    seg7_num %= 10000;
		ten_hund_digit = seg7_num / 1000;				
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
       if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 2,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 3,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		 port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
     consucc_bit_data.bits_len = 8;	
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[ten_hund_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[ten_hund_digit] & 0xFF;;
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);	
	
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 3,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		ret_status = Seg7_Disp_3Digit_Num(seg7_ch_id, seg7_rcv_disp_num);
		return ret_status;		
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_5Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.06 

BUGS           :
-*------------------------------------------------------------*/
static uint8_t Seg7_Disp_5Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
	  uint32_t seg7_num = seg7_rcv_disp_num;		
	  consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
		uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, lakh_digit, port, port_pin, ret_status = SUCCESS;
    
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	  {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	  }
    cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
    
	   seg7_num %= 100000;
		lakh_digit = seg7_num / 10000;				
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
       if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 2,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 3,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		}
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 4,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		 port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
     consucc_bit_data.bits_len = 8;	
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[lakh_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[lakh_digit] & 0xFF;;
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);		
	
	    if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 4,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
	    ret_status = Seg7_Disp_4Digit_Num(seg7_ch_id, seg7_rcv_disp_num);
		return ret_status;
}


/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_6Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.07 

BUGS           :
-*------------------------------------------------------------*/
static uint8_t Seg7_Disp_6Digit_Num(const uint8_t seg7_ch_id, const uint32_t seg7_rcv_disp_num)
{
	  uint32_t seg7_num = seg7_rcv_disp_num;		
	  consucc_bit_t consucc_bit_data;	
    seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
		uint8_t cc_digit[] = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F}, ten_lakh_digit, port, port_pin, ret_status = SUCCESS;
    
    if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	  {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	  }
    cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id;
	
    seg7_num %= 1000000;
		ten_lakh_digit = seg7_num / 100000;				
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		}
       if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 1,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 2,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 3,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		}
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 4,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		}
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 5,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
		 port_pin = cur_seg7_ctrl_ptr->io_ch_a_led % NUM_PINS_PER_PORT;
		 consucc_bit_data.start_bit_pos = port_pin;
     consucc_bit_data.bits_len = 8;	
     if(cur_seg7_ctrl_ptr->seg7_type == SEG7_COMMON_CATHODE)   
     {       
		     consucc_bit_data.consucc_val = cc_digit[ten_lakh_digit];
     }
     else
     {
        consucc_bit_data.consucc_val = ~cc_digit[ten_lakh_digit] & 0xFF; ;
     }
		 if((ret_status = Port_Write(cur_seg7_ctrl_ptr->io_ch_a_led, &consucc_bit_data)) != SUCCESS)
		 {
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;
		 }			 
        SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY);	
		
		if((ret_status = IO_Channel_Write(cur_seg7_ctrl_ptr->io_ch_unit_digit + 5,  STATE_LOW)) != SUCCESS)
		{						 
			 error_flag = ERR_SEG7_NO_WRITE;
			 return error_flag;  
		} 
	    ret_status = Seg7_Disp_5Digit_Num(seg7_ch_id, seg7_rcv_disp_num);
		return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_Seg7

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.08  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_Seg7(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
   cur_seg7_ctrl_ptr->enable_flag = STATE_NO;
	 
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Enable_Seg7

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.09  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Enable_Seg7(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
   cur_seg7_ctrl_ptr->enable_flag = STATE_YES;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_Seg7s

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.10  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_Seg7s(void)
{
	 uint8_t seg7_ch_id =0;
	
	 for(seg7_ch_id = 0; seg7_ch_id < NUM_OUTPUT_DEV_ID_SEG7_CHS; ++seg7_ch_id)
	 {
		   Disable_Seg7(seg7_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.11  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_Allow_Access(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	  cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
    cur_seg7_ctrl_ptr->access_flag = STATE_YES;
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 06.12  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Seg7_No_Access(const uint8_t seg7_ch_id)
{
	 seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;
	
	 if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	  cur_seg7_ctrl_ptr = seg7_ctrl + seg7_ch_id ;  
    cur_seg7_ctrl_ptr->access_flag = STATE_NO;
	 return SUCCESS;
}
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
