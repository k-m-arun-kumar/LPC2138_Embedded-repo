/**************************************************************************
   FILE          :    keyboard.c
 
   PURPOSE       :     
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 04  
	   
 **************************************************************************/
  
 #include "main.h" 
 
 #ifdef KEYPAD_MOD_ENABLE
 
/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
keyboard_status_t keyboard_status[NUM_INPUT_DEV_ID_KEYBOARD_CHS];
static uint32_t cur_pressed_key_or_sw;	

/* ----------------------------- global variable declaration -------------------- */
extern uint8_t last_sw_ch_id;

/* ----------------------------- global function declaration -------------------- */
static uint8_t KeyBoard_Col_Scan(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr, const uint8_t select_row );

/* ----------------------------- function pointer defination -------------------- */

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Read

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.                 

Func ID        : 04.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t Keyboard_Read(const uint8_t keyboard_ch_id, void *const rcvd_pressed_key_ptr)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;    
	 char *pressed_key_ptr = (char *) rcvd_pressed_key_ptr;
	 uint8_t ret_status = SUCCESS, ret1_status, error_status_flag = STATE_NO, row_select_state;
	 
	   if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS || pressed_key_ptr == NULL_PTR)
		 {
			   error_flag = ERR_DEV_CH_ID_OR_DATA_ID_INVALID;
			   return error_flag;
		 }
		   
     cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
	    if(  cur_keyboard_ctrl_ptr->access_flag != STATE_YES) 
	   {  
          error_flag = ERR_CUR_DATA_ID_DEV_NO_ACCESS;	
          return  error_flag;
	   }
	   if( cur_keyboard_ctrl_ptr->enable_flag != STATE_YES) 
	   {  
          error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
          return  error_flag;
	   }
       row_select_state = cur_keyboard_ctrl_ptr->pressed_state;	  			
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  row_select_state)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	         
             goto KEYPAD_READ_EXIT;
		}		
	    if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  !row_select_state)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	
             goto KEYPAD_READ_EXIT;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  !row_select_state)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	
             goto KEYPAD_READ_EXIT; 
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  !row_select_state)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_READ_EXIT;
		}
        ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, KEYPAD_ROWA_SELECT);
    if((ret1_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa ,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		switch(ret_status)
		{
		    case DATA_CHAR_READ:
			    *pressed_key_ptr = cur_pressed_key_or_sw;
				return ret_status;
			//break;	
			case SW_OR_KEY_NOT_PRESSED:
            case ERR_CUR_DATA_ID_DEV_DISABLED:  
			break;	
			default:
			  return ERR_KEYBOARD_PROC;
		} 
		
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  !row_select_state)) != SUCCESS)
		{	
              error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  row_select_state)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_READ_EXIT;     			
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  !row_select_state)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_READ_EXIT;
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  !row_select_state)) != SUCCESS)
		{		
              error_status_flag = ERR_KEYPAD_ROW_WRITE;	     	
			  goto KEYPAD_READ_EXIT;
		}
        ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, KEYPAD_ROWB_SELECT);
    if((ret1_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		switch(ret_status)
		{
    		  case DATA_CHAR_READ:
			    *pressed_key_ptr = cur_pressed_key_or_sw;
			   	return ret_status;
			    //break;		  			
			  case SW_OR_KEY_NOT_PRESSED:
              case ERR_CUR_DATA_ID_DEV_DISABLED:  
		      break;	
		  	  default:
			    return ERR_KEYBOARD_PROC;
		} 
		
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  !row_select_state)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_READ_EXIT;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  !row_select_state)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_READ_EXIT; 
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
        ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, KEYPAD_ROWC_SELECT);
     if((ret1_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		switch(ret_status)
		{
		    case DATA_CHAR_READ:
		     *pressed_key_ptr = cur_pressed_key_or_sw;
			 return ret_status;
			    //break;		  			
			case SW_OR_KEY_NOT_PRESSED:
      case ERR_CUR_DATA_ID_DEV_DISABLED:  
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		} 
		          
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1, !row_select_state )) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, KEYPAD_ROWD_SELECT); 
    if((ret1_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  !row_select_state)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_READ_EXIT;
		}
		switch(ret_status)
		{
		     case DATA_CHAR_READ:
			   *pressed_key_ptr = cur_pressed_key_or_sw;
           break;		  				
		   case SW_OR_KEY_NOT_PRESSED:
           case ERR_CUR_DATA_ID_DEV_DISABLED: 
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		}
KEYPAD_READ_EXIT: 
   switch(error_status_flag)
   {
	   case ERR_KEYPAD_ROW_WRITE:
         error_flag = ERR_KEYBOARD_PROC;	
         ret_status = error_flag;
		 Keyboard_Disable(keyboard_ch_id);
	   break;	 
   }
   return ret_status;	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used
                 
Func ID        : 04.02  

BUGS           :     
-*------------------------------------------------------------*/
static uint8_t KeyBoard_Col_Scan(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr, const uint8_t select_row )
{
	data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	uint8_t ret_status = SUCCESS, pressed_status = 0;
	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
	
	if(cur_keyboard_ctrl_ptr->keypad_keys_enable_flag == STATE_NO)
	{
		  error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
      return  error_flag;
	}
	
	if((ret_status = SW_Press_Proc(cur_keyboard_ctrl_ptr->base_sw_ch_id)) == SUCCESS)
	{
		pressed_status = 0x01;
		switch(select_row)
	   {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch			  
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch			    
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch			      
	        break;
	        case KEYPAD_ROWD_SELECT:
             cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch				 
			    break;		 	
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		}
    goto KEY_PRESSED_PROC;		 
	}
    if((ret_status = SW_Press_Proc(cur_keyboard_ctrl_ptr->base_sw_ch_id + 1)) == SUCCESS)
  	{
		pressed_status = 0x01;
		switch(select_row)
	    {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch			   
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch			  
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch			   
	        break;
	        case KEYPAD_ROWD_SELECT:
               cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch			  
            break;					
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		  } 
       goto KEY_PRESSED_PROC;				
	}
   if((ret_status = SW_Press_Proc(cur_keyboard_ctrl_ptr->base_sw_ch_id + 2)) == SUCCESS)
	{
		 pressed_status = 0x01;
		switch(select_row)
	    {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch			   
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch			   
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch			  
	        break;
	        case KEYPAD_ROWD_SELECT:
               cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch			  
			break;		 	
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		} 
	}
	KEY_PRESSED_PROC:
   if(pressed_status == 0x01)
   {
		if(( ret_status = Entered_Key_No_Long_Press_Proc(cur_keyboard_ctrl_ptr)) != SUCCESS)
	    {
	        return ret_status;
	    }
        return DATA_CHAR_READ;
   }
	return SW_OR_KEY_NOT_PRESSED;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Entered_Key_No_Long_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : make sure that entered key is within max available lcd loc and line, currently cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv 
	 sures that entered key is within max available lcd loc and within max line 

Func ID        : 04.03

BUGS           :   
-*------------------------------------------------------------*/
uint8_t Entered_Key_No_Long_Press_Proc(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr)
{ 
    return SUCCESS; 
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Disable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.04  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_Disable(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
	 uint8_t ret_status = SUCCESS, i;	
	 
	 if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;  
     cur_keyboard_ctrl_ptr->enable_flag = STATE_NO;
	 cur_keyboard_ctrl_ptr->keypad_keys_enable_flag = STATE_NO;	
	 for(i = 0; i < 3; ++i)
	 {
		SW_Disable(cur_keyboard_ctrl_ptr->base_sw_ch_id + i);
	 }
	 
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Enable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.05  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_Enable(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
	 uint8_t i, ret_status = SUCCESS;	
   
	if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	{
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	}
	cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
    for(i = 0; i < 3; ++i)
	{
		SW_Enable(cur_keyboard_ctrl_ptr->base_sw_ch_id + i);		
	}
	cur_keyboard_ctrl_ptr->keypad_keys_enable_flag = STATE_YES;	
    cur_keyboard_ctrl_ptr->enable_flag = STATE_YES;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_Keyboards

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.06  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_Keyboards(void)
{
	 uint8_t keyboard_ch_id =0;
	
	 for(keyboard_ch_id = 0; keyboard_ch_id < NUM_INPUT_DEV_ID_KEYBOARD_CHS; ++keyboard_ch_id)
	 {
		   Keyboard_Disable(keyboard_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.07  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_Allow_Access(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
     uint8_t i;
	 
     if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
    cur_keyboard_ctrl_ptr->access_flag = STATE_YES;
	for(i = 0; i < 3 ; ++i)
	{
		SW_Allow_Access(cur_keyboard_ctrl_ptr->base_sw_ch_id + i);	
	}
	 return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.07  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_No_Access(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
     uint8_t i;
	 
   if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
    cur_keyboard_ctrl_ptr->access_flag = STATE_NO;
	for(i = 0; i < 3 ; ++i)
	{
		SW_No_Access(cur_keyboard_ctrl_ptr->base_sw_ch_id + i);	
	}
    Keyboard_Disable(keyboard_ch_id);
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.09  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_Init(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
	 io_config_t keyboard_config;
	 uint8_t ret_status = SUCCESS ;
	 
	 if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	  cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
	  
	 keyboard_config.io_ch = cur_keyboard_ctrl_ptr->io_ch_rowa;
	 keyboard_config.signal = PIN_SIG_DIGITAL;
	 keyboard_config.func = IO_FUNC_GPIO;
	 keyboard_config.dir = IO_DIR_OUTPUT;
	 keyboard_config.state = STATE_LOW;
	 keyboard_config.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 keyboard_config.port_pin_len = 4;
		 
	 if((ret_status = IO_Channels_Func_Set(&keyboard_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	  keyboard_config.io_ch = cur_keyboard_ctrl_ptr->io_ch_col1;
	  keyboard_config.port_pin_len = 3;
	  keyboard_config.state = cur_keyboard_ctrl_ptr->pressed_state;
	  keyboard_config.func_type = IO_FUNC_TYPE_GPIO_SW;
	   keyboard_config.ch_id_alloc_type = CH_ID_ALLOC_DYNAMIC;
	  keyboard_config.dir = IO_DIR_INPUT;
	  cur_keyboard_ctrl_ptr->base_sw_ch_id = last_sw_ch_id;
	 if((ret_status = IO_Channels_Func_Set(&keyboard_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	 return SUCCESS; 	
}
/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_DeInit

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.10 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_DeInit(const uint8_t keyboard_ch_id)
{
	 io_config_t keyboard_unconfig;
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
	 uint8_t ret_status = SUCCESS;
	 
	 if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 Keyboard_No_Access(keyboard_ch_id);
	 cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
	 keyboard_unconfig.io_ch = cur_keyboard_ctrl_ptr->io_ch_rowa;
	 keyboard_unconfig.func = IO_FUNC_GPIO;
	 keyboard_unconfig.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 keyboard_unconfig.port_pin_len = 4;
	 
	 if((ret_status = IO_Ch_Func_Reset(&keyboard_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }
	 
	 keyboard_unconfig.io_ch = cur_keyboard_ctrl_ptr->io_ch_col1;
	 keyboard_unconfig.port_pin_len = 3;	
	 keyboard_unconfig.func_type = IO_FUNC_TYPE_GPIO_SW;
	 keyboard_unconfig.ch_id_alloc_type = CH_ID_ALLOC_DYNAMIC;
	 cur_keyboard_ctrl_ptr->base_sw_ch_id = CH_ID_INVALID;
	 if((ret_status = IO_Ch_Func_Reset(&keyboard_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }
	 return SUCCESS;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
