/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  When a numeric key is pressed in keypad, then corresponding numeric digit will be displayed in 7 segment LED.
                          ie if '0' is pressed in keypad, then '0' is displayed in 7 Segment LED.  
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : FOR reusable firmware development and data can be inputed by multi input source and outputed to multi output source.                        
                       			
						
CAUTION               : 
         LED MATRIX   :  Does not support data type in str. 
                      :  Disp map ie led_dot_disp_map[] is not coded for Row scan.					  
		SW			          :  if only sw is used, then no need to hold CPU by using sw read level transition by not defining SW_PRESS_HOLD_CPU. 
        KEYPAD    	  :  If keypad is used, then u must hold CPU by using While(read_sw_pressed_state) by defining SW_PRESS_HOLD_CPU.				  
                                    
CHANGE LOGS           :  

FILE ID               : 01

*****************************************************************************/
#include "main.h"
#include "dev_chs_map.h"
#include "data_ids_map.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
num_value_t to_disp_in_num;
uint32_t error_flag = NO_ERROR;
data_id_status_para_t data_id_status_para[NUM_DATA_IDS];
uint8_t cur_data_id = DATA_ID_INVALID;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t System_Init(void);
static uint8_t Appl_Init(const void *const data_ptr);
static uint8_t HW_Init(const void *const get_init_ptr);
static uint8_t PLL_Init(void);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
  uint8_t Cur_Data_Output_Dev_Disp(void);  
	uint8_t ret_status, reset_sw_ch_id ;
	  	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return ret_status;
	}	
    if((ret_status = Appl_Init(NULL_PTR)) != SUCCESS)
	{
		  return ret_status;
    }
	data_id_status_para[cur_data_id].data_value.data_str[data_id_status_para[cur_data_id].data_value.data_str_len_or_pos] = '0';
	if((ret_status = IO_Ch_To_SW_Ch(RESET_SW_IO_CH, &reset_sw_ch_id)) != SUCCESS)
	{
		return FAILURE;
	}
    while(1)
	{
		    ret_status = SW_Press_Proc(reset_sw_ch_id);
        switch(ret_status)
		{
			  case SUCCESS:
           Reset_Data_ID_Status(cur_data_id , DATA_ID_RESET_WHOLE_STATUS);
           (data_id_status_para + cur_data_id)->data_value.data_str[0] = '0';
			     if((ret_status =  SW_Disable(reset_sw_ch_id)) != SUCCESS)
           {
                  return FAILURE;
           } 
			  break;
			  case SW_OR_KEY_NOT_PRESSED:
			  case ERR_CUR_DATA_ID_DEV_NO_ACCESS:
			  case ERR_CUR_DATA_ID_DEV_DISABLED:
              break;
              default:
                 return FAILURE; 			
		}		
      switch(cur_data_id)
	  {
        case DATA_ID_SEG7:
            if((ret_status = Cur_Data_Output_Dev_Disp()) != SUCCESS)
			{
			   	return FAILURE;
			} 	
           	ret_status = Cur_Data_ID_Input_Devs_Read_Oper_Func();				
		      	switch(ret_status)
	        {
		           case CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS: 
                   if((ret_status =  SW_Enable(reset_sw_ch_id)) != SUCCESS)
                   {
                       return FAILURE;
                   }                     
	             break;
		         case CUR_DATA_ID_REACH_MAX_CHARS_READ_WAIT_TERMINATOR_CHAR:
		         case ERR_CUR_DATA_ID_DEV_DISABLED:
		         case ERR_CUR_DATA_ID_DEV_NO_ACCESS:		         
		         case SW_OR_KEY_NOT_PRESSED:
		         case ERR_CUR_DATA_ID_SPECIAL_CHAR_READ_BUT_DISABLED:
		         case ERR_CUR_DATA_ID_NUM_CHAR_READ_BUT_DISABLED:
		         case ERR_CUR_DATA_ID_SMALL_ENGLISH_ALPHA_CHAR_READ_BUT_DISABLED:
		         case ERR_CUR_DATA_ID_BIG_ENGLISH_ALPHA_CHAR_READ_BUT_DISABLED:
		         case ERR_CUR_DATA_ID_CTRL_CHAR_READ_BUT_DISABLED:
                 break;
		         case CUR_DATA_ID_VALID_CHAR_READ:		  
		         break;
                 default:
                    return FAILURE;  		  
	        }
	    break;
        default:
            return FAILURE; 
      }
   }
   return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Cur_Data_Output_Dev_Disp

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Cur_Data_Output_Dev_Disp(void)
{ 
   dev_id_t cur_data_devs_src_allow[1]; 
	 output_data_ctrl_para_t seg7_ctrl; 
   uint8_t ret_status ;
  
   Set_Data_Devs_Src_Allow(TYPE_INPUT_DEV, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
	if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_DISABLE_OPER_FUNC, cur_data_devs_src_allow)) != SUCCESS)
	{
	     return FAILURE;
	}
	ret_status = Cur_Data_ID_Output_Devs_Write_Oper_Func(&seg7_ctrl);
	switch(ret_status)
	{
	    case ERR_CUR_DATA_ID_DEV_DISABLED:
	    case ERR_CUR_DATA_ID_DEV_NO_ACCESS:
	    break;
	    case SUCCESS:
          Set_Data_Devs_Src_Allow(TYPE_INPUT_DEV, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
	        if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ENABLE_OPER_FUNC, cur_data_devs_src_allow)) != SUCCESS)
	        {
	            return FAILURE;
	        }	       
	    break;
	    default:
	      return FAILURE;
	}
	return SUCCESS;
}	
/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Appl_Init(const void *const data_ptr)
{
	  uint8_t ret_status = SUCCESS, reset_sw_ch_id;
	 	dev_id_t cur_data_devs_src_allow[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS),MAX_DATA_COMM_DEVS)];        
		
	    Reset_Parameters();
	    if((ret_status = Data_IDs_Set_Para()) != SUCCESS)
		{
           return FAILURE;
		}		   
	    Next_Data_Conf_Parameter();
		Set_Data_Devs_Src_Allow(TYPE_OUTPUT_DEV, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
		if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(OUTPUT_DEV_ENABLE_OPER_FUNC, cur_data_devs_src_allow)) != SUCCESS)
		{
		   return FAILURE;
	    }
		Set_Data_Devs_Src_Allow(TYPE_INPUT_DEV, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
		if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ENABLE_OPER_FUNC, cur_data_devs_src_allow)) != SUCCESS)
		{
		   return FAILURE;
	  }
    if((ret_status = IO_Ch_To_SW_Ch(RESET_SW_IO_CH, &reset_sw_ch_id)) != SUCCESS)
   {
       return FAILURE;
   }
   if((ret_status = SW_Allow_Access(reset_sw_ch_id)) != SUCCESS)
   {
       return FAILURE;
   }
   if((ret_status = SW_Enable(reset_sw_ch_id)) != SUCCESS)
   {
       return FAILURE;
   }
	    return SUCCESS; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : Next_Data_Conf_Parameter

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Next_Data_Conf_Parameter(void)
{
    static uint8_t prev_data_id = DATA_ID_INVALID;
	
	 prev_data_id = cur_data_id;
	 switch(cur_data_id)
	 {
		  case DATA_ID_INVALID:
		  	cur_data_id = DATA_ID_SEG7;           
          break;
          default:
		    error_flag = ERR_CUR_DATA_ID_INVALID;
			return error_flag;
	 }	
	Data_Dev_Src_Access_Oper_Func(prev_data_id); 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.04

BUGS           :    
-*------------------------------------------------------------*/
void Reset_Parameters(void)
{
	Reset_Data_IDs_Status();
	#ifdef SW_MOD_ENABLE
	   Disable_All_SWs();
	#endif   
    #ifdef KEYPAD_MOD_ENABLE	
       Disable_All_Keyboards();
	#endif
	#ifdef SEG7_MOD_ENABLE
	    Disable_All_Seg7s();
	#endif
	#ifdef LED_MATRIX_MOD_ENABLE
	   Disable_All_LED_Matrixs();
	#endif
	#ifdef LCD_MOD_ENABLE
	   Disable_All_LCDs();
	#endif
	//Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.05  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t System_Init(void)
{
	return HW_Init(NULL_PTR);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW if any, then initialize Keyboard, if any.

Func ID        : 01.06  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t HW_Init(const void *const get_init_ptr)
{
	uint8_t ret_status = SUCCESS, reset_sw_ch_id;
	
	PLL_Init();
	Reset_IO_Chs();	
	if((ret_status = Seg7_Init(CH_ID_00)) != SUCCESS)
	{
	   return FAILURE;
	}
	if((ret_status = IO_Ch_To_SW_Ch(RESET_SW_IO_CH, &reset_sw_ch_id)) != SUCCESS)
   {
       return FAILURE;
   }
   if((ret_status = SW_Init(reset_sw_ch_id)) != SUCCESS)
   {
       return FAILURE;
   }
   if((ret_status = Keyboard_Init(CH_ID_00)) != SUCCESS)
	 {
	   return FAILURE;
	 } 
   return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.07  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x00; // or APBDIV, PCLK  = CCLK/4 
   	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
