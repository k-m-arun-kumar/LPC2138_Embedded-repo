/**************************************************************************
   FILE          :    dev_oper.h
 
   PURPOSE       :    Device Operation
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _DEV_OPER_H
#define _DEV_OPER_H

/* ---------------------- macro defination ------------------------------------------------ */
#define CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER      NUM_DEVS 
 
/* ---------------------- data type defination -------------------------------------------- */
typedef enum
{
	TYPE_INPUT_DEV, TYPE_OUTPUT_DEV, TYPE_COMM_DEV
} dev_type_t;

 typedef enum
{
  OUTPUT_DEV_ID_DAC, OUTPUT_DEV_ID_PWM, OUTPUT_DEV_ID_SEG7, OUTPUT_DEV_ID_LCD, OUTPUT_DEV_ID_LED_MATRIX, COMM_DEV_ID_UART, COMM_DEV_ID_I2C,
  COMM_DEV_ID_SPI, COMM_DEV_ID_MISC, INPUT_DEV_ID_KEYBOARD, INPUT_DEV_ID_ADC, INPUT_DEV_ID_SW, INPUT_DEV_ID_MISC, NUM_DEVS, DEV_ID_INVALID 	
} dev_src_id_t;
 
 #define    BEGIN_OUTPUT_DEV_ID            OUTPUT_DEV_ID_DAC
 #define    END_OUTPUT_DEV_ID              OUTPUT_DEV_ID_LED_MATRIX
 #define    BEGIN_COMM_DEV_ID             COMM_DEV_ID_UART
 #define    END_COMM_DEV_ID               COMM_DEV_ID_MISC
 #define    BEGIN_INPUT_DEV_ID             INPUT_DEV_ID_KEYBOARD
 #define    END_INPUT_DEV_ID               INPUT_DEV_ID_SW 
 
typedef enum
 { 
   INPUT_DEV_DEINIT_OPER_FUNC,  INPUT_DEV_INIT_OPER_FUNC, INPUT_DEV_NO_ACCESS_OPER_FUNC, INPUT_DEV_ALLOW_ACCESS_OPER_FUNC, 
   INPUT_DEV_DISABLE_OPER_FUNC, INPUT_DEV_ENABLE_OPER_FUNC,  INPUT_DEV_OPEN_OPER_FUNC, INPUT_DEV_CLOSE_OPER_FUNC,
   INPUT_DEV_INPUT_OPER_FUNC, OUTPUT_DEV_DEINIT_OPER_FUNC,  OUTPUT_DEV_INIT_OPER_FUNC, OUTPUT_DEV_NO_ACCESS_OPER_FUNC, 
   OUTPUT_DEV_ALLOW_ACCESS_OPER_FUNC, OUTPUT_DEV_DISABLE_OPER_FUNC, OUTPUT_DEV_ENABLE_OPER_FUNC, OUTPUT_DEV_OPEN_OPER_FUNC, 
   OUTPUT_DEV_CLOSE_OPER_FUNC, OUTPUT_DEV_OUTPUT_OPER_FUNC, COMM_DEV_DEINIT_OPER_FUNC,  COMM_DEV_INIT_OPER_FUNC, 
   COMM_DEV_NO_ACCESS_OPER_FUNC, COMM_DEV_ALLOW_ACCESS_OPER_FUNC, COMM_DEV_DISABLE_OPER_FUNC, COMM_DEV_ENABLE_OPER_FUNC,
   COMM_DEV_OPEN_OPER_FUNC, COMM_DEV_CLOSE_OPER_FUNC, COMM_DEV_RECEIVE_OPER_FUNC, COMM_DEV_TRANSMIT_OPER_FUNC
 } dev_oper_func_t; 

#define START_INPUT_DEV_OPER_FUNC              INPUT_DEV_DEINIT_OPER_FUNC
#define END_INPUT_DEV_OPER_FUNC                INPUT_DEV_INPUT_OPER_FUNC
#define START_OUTPUT_DEV_OPER_FUNC             OUTPUT_DEV_DEINIT_OPER_FUNC
#define END_OUTPUT_DEV_OPER_FUNC               OUTPUT_DEV_OUTPUT_OPER_FUNC
#define START_COMM_DEV_OPER_FUNC               COMM_DEV_DEINIT_OPER_FUNC
#define END_COMM_DEV_OPER_FUNC                 COMM_DEV_TRANSMIT_OPER_FUNC

#define START_INPUT_DEV_BASIC_OPER_FUNC        INPUT_DEV_DEINIT_OPER_FUNC
#define END_INPUT_DEV_BASIC_OPER_FUNC          INPUT_DEV_ENABLE_OPER_FUNC
#define START_OUTPUT_DEV_BASIC_OPER_FUNC       OUTPUT_DEV_DEINIT_OPER_FUNC
#define END_OUTPUT_DEV_BASIC_OPER_FUNC         OUTPUT_DEV_ENABLE_OPER_FUNC
#define START_COMM_DEV_BASIC_OPER_FUNC        COMM_DEV_DEINIT_OPER_FUNC
#define END_COMM_DEV_BASIC_OPER_FUNC          COMM_DEV_ENABLE_OPER_FUNC
 
typedef uint8_t (*dev_deinit_t)(const uint8_t dev_ch_id);
typedef uint8_t (*dev_init_t)(const uint8_t dev_ch_id);
typedef uint8_t (*dev_no_access_t)(const uint8_t dev_ch_id);
typedef uint8_t (*dev_allow_access_t)(const uint8_t dev_ch_id);
typedef uint8_t (*dev_disable_t)(const uint8_t dev_ch_id);
typedef uint8_t (*dev_enable_t)(const uint8_t dev_ch_id);
typedef uint8_t (*dev_open_t)(const uint8_t dev_ch_id, const void *const open_option_ptr );
typedef uint8_t (*dev_close_t)(const uint8_t dev_ch_id, const void *const close_option_ptr );
typedef uint8_t (*dev_read_t)(const uint8_t dev_ch_id, void *const input_devs_ptr);
typedef uint8_t (*dev_write_t)(const uint8_t dev_ch_id, const void *const output_devs_ptr);
typedef uint8_t (*dev_receive_t)(const uint8_t dev_ch_id, void *const receive_data_ptr);
typedef uint8_t (*dev_transmit_t)(const uint8_t dev_ch_id, const void *const transmit_data_ptr);

typedef struct 
{
	dev_deinit_t Dev_DeInit_Func_Ptr;
	dev_init_t   Dev_Init_Func_Ptr;
	dev_no_access_t Dev_No_Access_Func_Ptr;
	dev_allow_access_t Dev_Allow_Access_Func_Ptr;
	dev_disable_t Dev_Disable_Func_Ptr;
	dev_enable_t Dev_Enable_Func_Ptr;
	dev_receive_t Dev_Receive_Func_Ptr;
	dev_transmit_t Dev_Transmit_Func_Ptr;
	dev_read_t  Dev_Read_Func_Ptr;
	dev_write_t Dev_Write_Func_Ptr;	
	/*dev_open_t  Dev_Open_Func_Ptr;
	dev_close_t Dev_Close_Func_Ptr; */
}  Dev_Oper_Func_t;

typedef union
{
	uint8_t led_matrix_scroll_fmt;
	#ifdef LCD_MOD_ENABLE
	  lcd_disp_ctrl_t lcd_disp_para;
	#endif
} output_data_ctrl_para_t;

 /* -------------------- public variable declaration --------------------------------------- */
   extern Dev_Oper_Func_t Dev_Oper_Func_Table[];
  
/* -------------------- public function declaration --------------------------------------- */
uint8_t Data_Dev_Src_Access_Oper_Func(const uint8_t prev_data_id);
uint8_t Data_ID_Devs_Src_Set(const data_id_dev_src_t *const data_id_dev_src_conf_ptr, const uint8_t num_conf_size);
uint8_t Cur_Data_ID_Input_Devs_Read_Oper_Func(void);
uint8_t Cur_Data_ID_Output_Devs_Write_Oper_Func(const output_data_ctrl_para_t *const data_ctrl_para);
uint8_t Cur_Data_ID_Devs_Src_Basic_Oper_Func(const uint8_t dev_src_basic_oper_func, const dev_id_t *const cur_data_devs_src_allow_ptr);
uint8_t Set_Data_Devs_Src_Allow(const uint8_t dev_type, const uint8_t data_dev_allow_type, dev_id_t *const cur_data_devs_src_allow_ptr);
uint8_t Reset_Data_Devs_Src_Allow(dev_id_t *const cur_data_devs_src_allow_ptr);
uint8_t Cur_Data_ID_Comm_Devs_Receive_Oper_Func(void);
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
