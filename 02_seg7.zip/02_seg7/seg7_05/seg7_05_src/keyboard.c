/**************************************************************************
   FILE          :    keyboard.c
 
   PURPOSE       :     
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 02  
	   
 **************************************************************************/
 #include "main.h"
 #include "port.h" 
 #include "keyboard.h" 
 #include "string.h"
 #include "io_conf.h"
 #include "appl_conf.h"
 #include "appl.h"
 
char cur_pressed_key_or_sw;
int_8 keypad_keys_enable_flag = STATE_YES_IN_CHAR, keyboard_input_enable_flag = STATE_YES_IN_CHAR, enter_sw_enable_flag = STATE_NO_IN_CHAR, backspace_sw_enable_flag = STATE_NO_IN_CHAR;
int_8 keypad_col[3] = {KEY_RELEASED, KEY_RELEASED, KEY_RELEASED};

uint_8 KeyBoard_Col_Scan(const uint_8 select_row );

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : switch debounce, long key press and no key press timeout is not implemented.                 

Func ID        : 02.01  

BUGS           :     
-*------------------------------------------------------------*/
uint_8 Keyboard_Proc(void)
{
		uint_8 ret_status;
	
	   if(cur_data_conf_parameter.cur_data_input_dev_id == INPUT_DEV_ID_KEYBOARD && keyboard_input_enable_flag == STATE_YES_IN_CHAR) 
    {  
        switch( cur_data_conf_parameter.cur_data_rcv_mode) 
	    {
			//enter data till enter key is pressed
		    case CUR_DATA_RCV_MODE_TILL_TERMINATOR:
	           if(cur_data_status.cur_data_num_chars_rcvd + 1 > KEYPAD_CONF_MAX_NUM_CHARS_ENTERED)
	           {
		           cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_YES_IN_CHAR;
                   cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR; 
			       return SUCCESS;
		       }
		    break;
			//enter data till max nums of chars is reached
            case CUR_DATA_RCV_MODE_TILL_ALLOCATED:	
         		if(cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv <= KEYPAD_CONF_MAX_NUM_CHARS_ENTERED ) 
		        {
			       if(cur_data_status.cur_data_num_chars_rcvd >= cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv)
			       {
				       cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = NULL_CHAR;	
                       cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR;
                       cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_YES_IN_CHAR; 
                return SUCCESS; 							 
			       }	
                }
						#ifdef UNUSED
		        else
		        {
				    #ifdef TRACE_ERROR
			           UART_Transmit_Str("ERR: keyboard set max chars to enter > configured \r");
			 	    #endif
				    return FAILURE;
		        }
            #endif						
		    break;
		}			
				
	      IO1CLR = 1 << KEYPAD_PHONE_ROWA;
        IO1SET = 1 << KEYPAD_PHONE_ROWB ;
        IO1SET = 1 << KEYPAD_PHONE_ROWC;
        IO1SET = 1 << KEYPAD_PHONE_ROWD ; 
		
		    if((ret_status = KeyBoard_Col_Scan(KEYPAD_ROWA_SELECT)) != SUCCESS)
			  {
				   	return FAILURE;
			  }
		
		    IO1SET = 1 << KEYPAD_PHONE_ROWA;
        IO1CLR = 1 << KEYPAD_PHONE_ROWB ;
        IO1SET = 1 << KEYPAD_PHONE_ROWC;
        IO1SET = 1 << KEYPAD_PHONE_ROWD ; 
        if((ret_status = KeyBoard_Col_Scan(KEYPAD_ROWB_SELECT)) != SUCCESS)
			  {
				   	return FAILURE;
			  }
        IO1SET = 1 <<  KEYPAD_PHONE_ROWA;
        IO1SET = 1 << KEYPAD_PHONE_ROWB ;
        IO1CLR = 1 << KEYPAD_PHONE_ROWC;
        IO1SET = 1 << KEYPAD_PHONE_ROWD ; 
				
	     	if((ret_status = KeyBoard_Col_Scan(KEYPAD_ROWC_SELECT)) != SUCCESS)
			  {
				   	return FAILURE;
			  }
          
        IO1SET = 1 << KEYPAD_PHONE_ROWA;
        IO1SET = 1 << KEYPAD_PHONE_ROWB ;
        IO1SET = 1 << KEYPAD_PHONE_ROWC;
        IO1CLR = 1 << KEYPAD_PHONE_ROWD ; 
		    if((ret_status = KeyBoard_Col_Scan(KEYPAD_ROWD_SELECT)) != SUCCESS)
			  {
				   	return FAILURE;
			  }
				return SUCCESS;
			}
	  	return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used
                 as required by proteus simulation

Func ID        : 02.02  

BUGS           :     
-*------------------------------------------------------------*/
 uint_8 KeyBoard_Col_Scan(const uint_8 select_row )
{
   	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};		
		
    if(keypad_keys_enable_flag == STATE_YES_IN_CHAR && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO_IN_CHAR) 
		{
			 if(keypad_col[0] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL0)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL0 ))
			     {
		       	   keypad_col[0] = KEY_PRESSED;
               while(!(IO1PIN & 1 << KEYPAD_PHONE_COL0 ));						 
			       	 SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			         if(IO1PIN & 1 << KEYPAD_PHONE_COL0)
		           {
		              keypad_col[0] = KEY_RELEASED;
							    switch(select_row)
								  {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT:
                        if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{													
											     cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch
												   break;
												}
												return SUCCESS;	
										default:	
                                          return FAILURE;
                   									
								}	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			       }				 
			    }	   
		   }
			 if(keypad_col[1] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL1)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL1 ))
			     {
						   keypad_col[1] = KEY_PRESSED;
               while(!(IO1PIN & 1 << KEYPAD_PHONE_COL1 ));						 
			       	 SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			         if(IO1PIN & 1 << KEYPAD_PHONE_COL1)
		           {
			            keypad_col[1] = KEY_RELEASED;
	                switch(select_row)
								  {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch
										 break;	
									     default:	
                                            return FAILURE;	 
								}						 
				        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 if(keypad_col[2] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL2)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL2 ))
			     {
		       	   keypad_col[2] = KEY_PRESSED;
               while(!(IO1PIN & 1 << KEYPAD_PHONE_COL2 ));						 
			       	 SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			         if(IO1PIN & 1 << KEYPAD_PHONE_COL2)
		           {
			            keypad_col[2] = KEY_RELEASED; 	           
		              switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{
											       cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch
													   break;
												}
												return SUCCESS; 
                                          default:	
                                          return FAILURE; 				   
								}							       	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 return SUCCESS;
	 	}
		return FAILURE;		
	}	

#ifdef UNUSED
/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 	halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used                  

Func ID        : 02.02  

BUGS           :     
-*------------------------------------------------------------*/
 uint_8 KeyBoard_Col_Scan(const uint_8 select_row )
{
   	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};		
		
    if(keypad_keys_enable_flag == STATE_YES_IN_CHAR && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO_IN_CHAR) 
		{
			 if(keypad_col[0] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL0)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL0 ))
			     {
		       	   keypad_col[0] = KEY_PRESSED; 
			     }      			
		   }
       else
		   {
		    	if( keypad_col[0] == KEY_PRESSED && (IO1PIN & 1 << KEYPAD_PHONE_COL0 ))
		    	{
			       SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			       if(IO1PIN & 1 << KEYPAD_PHONE_COL0)
		         {
		             keypad_col[0] = KEY_RELEASED;
							   switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT:
                        if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{													
											     cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch
												   break;
												}
												return SUCCESS;
                                      	default:	
                                          return FAILURE;											
								}	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 if(keypad_col[1] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL1)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL1 ))
			     {
		       	   keypad_col[1] = KEY_PRESSED; 
			     }      			
		   }
       else
		   {
		    	if( keypad_col[1] == KEY_PRESSED && (IO1PIN & 1 << KEYPAD_PHONE_COL1 ))
		    	{
			       SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			       if(IO1PIN & 1 << KEYPAD_PHONE_COL1)
		         {
		            keypad_col[1] = KEY_RELEASED;
	               switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch
										 break;	
                                         default:	
                                          return FAILURE;										 
								}						 
				        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 if(keypad_col[2] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL2)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL2 ))
			     {
		       	   keypad_col[2] = KEY_PRESSED; 
			     }      			
		   }
       else
		   {
		    	if( keypad_col[2] == KEY_PRESSED && (IO1PIN & 1 << KEYPAD_PHONE_COL2 ))
		    	{
			       SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			       if(IO1PIN & 1 << KEYPAD_PHONE_COL2)
		         {
		            keypad_col[2] = KEY_RELEASED;
                 switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{
											       cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch
													   break;
												}
												return SUCCESS;  
										 break;
                                         default:	
                                          return FAILURE;										 
								}							       	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 return SUCCESS;
	 	}
		return FAILURE;		
	}	
#endif
/*------------------------------------------------------------*
FUNCTION NAME  : Entered_Key_No_Long_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : make sure that entered key is within max available lcd loc and line, currently cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv 
	 sures that entered key is within max available lcd loc and within max line 

Func ID        : 02.03

BUGS           :   
-*------------------------------------------------------------*/
uint_8 Entered_Key_No_Long_Press_Proc(const char cur_key_char)
{	 
   if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR) 
	 {
		    IO0CLR = 1 << UNIT_DIGIT_PORT0_PIN;
        IO0CLR = 1 << TENS_DIGIT_PORT0_PIN ;
	 } 	 
   cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = cur_key_char;   
   ++cur_data_status.cur_data_num_chars_rcvd;
   	
	 return SUCCESS; 
	  
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Keyboard_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.04  

Bugs           :  
-*------------------------------------------------------------*/
void Reset_Keyboard_Parameters()
{
	keyboard_input_enable_flag = STATE_NO_IN_CHAR;
	backspace_sw_enable_flag = STATE_NO_IN_CHAR; 
	enter_sw_enable_flag = STATE_NO_IN_CHAR;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :              
-*------------------------------------------------------------*/
void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count)
{
	 uint_32 i, j;
	 for(i = 0; i < max_i_count; ++i)
	 { 
         for(j = 0;j < max_j_count; ++j);
	 } 
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
