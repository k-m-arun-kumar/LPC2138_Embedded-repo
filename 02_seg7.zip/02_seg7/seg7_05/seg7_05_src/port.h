
/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran  
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

#define SEG7_PORT0_LSB_PIN       (0)
#define UNIT_DIGIT_PORT0_PIN     (8)
#define TENS_DIGIT_PORT0_PIN     (9)

#define KEYPAD_PHONE_ROWA        (16)
#define KEYPAD_PHONE_ROWB        (17)
#define KEYPAD_PHONE_ROWC        (18)
#define KEYPAD_PHONE_ROWD        (19)
#define KEYPAD_PHONE_COL0        (20)
#define KEYPAD_PHONE_COL1        (21)
#define KEYPAD_PHONE_COL2        (22)

#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
