/**************************************************************************
   FILE          :    main.h
 
   PURPOSE       :    project header.  
 
   AUTHOR        :  K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   PROJECT header- groups the key information about the mcrocontroller device you have used, along with other key
parameters � such as the oscillator frequency and commonly used information such as common data types in the project
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _MAIN_H
#define _MAIN_H

/* Must include the appropriate microcontroller header file here eg for eg if we use LPC 2138 uC device.
 In most case, microcontroller header is also a device header.in our case, lpc213x.h
 device header will include the addresses of the special function registers (SFRs) used for port access, plus similar
 details for other on-chip components such as analog-to-digital converters*/
 /* lpc213x.h is a system header and for <> enclosed one, preprocessor will search the lpc213x.h in predetermined directory path to locate the header file. */
 // Must include the appropriate microcontroller header file here
#include <lpc213x.h>

//#define NULL                                      ((void *)0)

#define LED_OFF                                  (0)
#define LED_ON                                   (1) 
 
#define KEY_TRANSITION_TO_PRESSED                (2)
#define KEY_PRESSED                              (3)
#define KEY_TRANSITION_TO_RELEASED               (4)
#define KEY_RELEASED                             (5)

#define STATE_YES_IN_CHAR                       ('Y')
#define STATE_NO_IN_CHAR                        ('N')
#define STATE_INVALID_IN_CHAR                   ('X')
#define STATE_VALID_IN_CHAR                     ('V')
#define STATE_UNKNOWN_IN_CHAR                   ('U')

#define STATE_YES_IN_INT                          (0U) 
#define STATE_NO_IN_INT                           (1U)
#define STATE_UNKNOWN_IN_INT                      (2U)
#define STATE_INVALID_IN_INT                      (3U)
#define STATE_VALID_IN_INT                        (4U)

#define STATE_OFF                                (0)
#define STATE_ON                                 (1)

#define SUCCESS                                 (0)
#define FAILURE                                 (1)
 
#define DATA_STATE_UNKNOWN                      (0U)
#define DATA_STATE_INVALID                      (1U)
#define DATA_STATE_VALID                        (2U)

 /* Bit Operation macros */
     /* Set bit pos  in byte data   */
#define Set_Bit_in_Data(data , bit_pos)                         ((*data) |=   (1<<(bit_pos)))     
      /* Clear bit pos in byte data */ 
#define Clear_Bit_in_Data(data ,bit_pos)                         ((*data) &= (~(1<<(bit_pos))))      
    /* flip bit pos in byte data  */ 
#define Toggle_Bit_in_Data(data , bit_pos)                       ((*data) ^=   (1<<(bit_pos)))        
    /* Test if bit pos in byte data  is set   */
#define Test_Bit_Is_Set_in_Data(data ,bit_pos)                    ((*data) & (1<<bit_pos))       
   /* Test if bit pos in byte data is clear */  
#define Test_Bit_Is_Clear_in_Data(data ,bit_pos)                  (!((*data) & (1<<bit_pos)))  
 
#define BACKSPACE_CHAR                        ('\b')
#define ENTER_CHAR                            ('\r')
#define NULL_CHAR                             ('\0')   
#define ZERO_CHAR                              ('0')
#define NINE_CHAR                              ('9')
#define CHARS_RCV_TILL_TERMINATOR_CHAR_MODE        (0U)

// for most instruction, number of oscillations required to execute per instruction
// 1 � ARM
#define OSC_PER_INST                            (1)

#define TIME_UNIT_1_SEC_IN_MILLI_SEC                   (1000)

typedef unsigned char uint_8;
typedef unsigned short int uint_16;
typedef unsigned int uint_32;
typedef unsigned long uint_64;

typedef char int_8;
typedef short int int_16;
typedef int int_32;
typedef long int_64;

typedef union 
{
	uint_64 val_uint_64; 
	int_64 val_int_64; 
	uint_32 val_uint_32[2];
	int_32 val_int_32[2];
	uint_16 val_uint_16[4];
	int_16 val_int_16[4];
	uint_8 val_uint_8[8];
	int_8 val_int_8[8];
	struct 
	{
	      	uint_32 bit_00: 1;
	    	uint_32 bit_01: 1;
		    uint_32 bit_02: 1;
		    uint_32 bit_03: 1;
	    	uint_32 bit_04: 1;
		    uint_32 bit_05: 1;
		    uint_32 bit_06: 1;
	    	uint_32 bit_07: 1;
		    uint_32 bit_08: 1;
		    uint_32 bit_09: 1;
	    	uint_32 bit_10: 1;
		    uint_32 bit_11: 1;
			uint_32 bit_12: 1;
	    	uint_32 bit_13: 1;
		    uint_32 bit_14: 1;
		    uint_32 bit_15: 1;
	    	uint_32 bit_16: 1;
		    uint_32 bit_17: 1;
		    uint_32 bit_18: 1;
	    	uint_32 bit_19: 1;
		    uint_32 bit_20: 1;
		    uint_32 bit_21: 1;
	    	uint_32 bit_22: 1;
		    uint_32 bit_23: 1;
			uint_32 bit_24: 1;
		    uint_32 bit_25: 1;
		    uint_32 bit_26: 1;
	    	uint_32 bit_27: 1;
		    uint_32 bit_28: 1;
		    uint_32 bit_29: 1;
	    	uint_32 bit_30: 1;
		    uint_32 bit_31: 1;
	} val_in_bits;
} value_types;

typedef enum 
{  
   DISP_UNSIGN_NUM_DIGIT1 = 0x01, DISP_UNSIGN_NUM_DIGIT2, DISP_UNSIGN_NUM_DIGIT3, DISP_UNSIGN_NUM_DIGIT4, DISP_UNSIGN_NUM_DIGIT5, \
   DISP_SIGN_NUM_DIGIT1 = 0x11, DISP_SIGN_NUM_DIGIT2, DISP_SIGN_NUM_DIGIT3, DISP_SIGN_NUM_DIGIT4, DISP_SIGN_NUM_DIGIT5,\
   DISP_HEX_DIGIT1 = 0x21, DISP_HEX_DIGIT2, DISP_HEX_DIGIT3, DISP_HEX_DIGIT4 
} disp_num_types;


typedef enum {
  INPUT_DEV_ID_INVALID, INPUT_DEV_ID_KEYBOARD, INPUT_DEV_ID_UART  	
} input_dev_id_types; 

typedef enum {
	OUTPUT_DEV_ID_INVALID, OUTPUT_DEV_ID_LCD, OUTPUT_DEV_ID_UART, OUTPUT_DEV_ID_SEG7
} output_dev_id_types;

 typedef enum {
	DATA_IN_INVALID_FORMAT, DATA_IN_STR_FORMAT, DATA_IN_BINARY_FORMAT, DATA_IN_HEXA_FORMAT, DATA_IN_DECIMAL_FORMAT, DATA_IN_CHAR_FORMAT, DATA_IN_APPL_DEFINED_FORMAT
} data_format_types;

extern value_types to_disp;

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
