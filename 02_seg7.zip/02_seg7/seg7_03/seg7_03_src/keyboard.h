/**************************************************************************
   FILE          :    keyboard.h
 
   PURPOSE       :    keyboard Header
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _KEYBOARD_H
 #define _KEYBOARD_H
 
 /* ---------------------- macro defination ------------------------------------------------ */
 
#define ENTER_SW_CODE                           ('E')
#define BACKSPACE_SW_CODE                       ('B')

#define RCVD_CHAR_PLAIN_DISP_FORMAT              (1)
#define RCVD_CHAR_HIDDEN_DISP_FORMAT             (2)  

#define KEYPAD_ROWA_SELECT                       (1)
#define KEYPAD_ROWB_SELECT                       (2)
#define KEYPAD_ROWC_SELECT                       (3)
#define KEYPAD_ROWD_SELECT                       (4)

/* ---------------------- data type defination --------------------------------------------- */


/* -------------------- public variable declaration --------------------------------------- */
 
extern char cur_pressed_key_or_sw;
extern char keypad_keys_enable_flag, keyboard_input_enable_flag, enter_sw_enable_flag, backspace_sw_enable_flag;

 /* -------------------- public prototype declaration --------------------------------------- */

uint_8 Keyboard_Proc(void);
uint_8 Entered_Key_No_Long_Press_Proc(const char key_data);
void Entered_Backspace_Sw_No_Long_Press_Proc(void);
void Reset_Keyboard_Parameters(void);
void After_Switch_Stoke_Proc(const char pressed_sw);
void SW_Time_Delay(uint_32 max_i_count, uint_32 max_j_count);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
