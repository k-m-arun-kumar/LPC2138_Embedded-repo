/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : In a keypad, when a numeric key is pressed, then display that key in a 7 segment Common Anode 1 digit  
                                                  
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 

CAUTION               :  
                                    
CHANGE LOGS           : 

FILE ID               : 01

*****************************************************************************/
#include <string.h> 
#include "main.h"
#include "port.h"
#include "keyboard.h"
#include "io_conf.h"
#include "appl_conf.h"
#include "appl.h"

#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

typedef struct 
{
	uint_32 consucc_val;
	uint_8 start_bit_pos;
	uint_8 bits_len;
} consucc_bit_type;

value_types to_disp;
cur_data_conf_parameter_types cur_data_conf_parameter;
cur_data_status_parameter_types cur_data_status;

uint_8 inc_sw_enable_flag = STATE_YES_IN_CHAR, dcr_sw_enable_flag = STATE_YES_IN_CHAR;

static void Seg7_Disp_1Digit_Num(uint_32 seg7_disp_num);
static uint_8 System_Init(void);
static uint_8 Appl_Init(const void *const data_ptr);
static uint_8 HW_Init(const void *const get_init_ptr);
static uint_8 PLL_Init(void);
static uint_8 GPIO_Init(void );
uint_8 Config_Consucc_Bits(void *const data_ptr, const uint_8 consucc_bit_flag);
uint_8 Test_Consucc_Bits(const void *const data_ptr, const uint_8 flag_consucc_bit);
uint_8 Config_Port0_Pins(const void *const data_ptr);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	uint_32 seg7_disp_num = 0;
	uint_8 ret_status;
	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return FAILURE;
	}	
  if((ret_status = Appl_Init(NULL)) != SUCCESS)
	{
		  return FAILURE;
  }		
	while(1)
	{	
		    Keyboard_Proc();
		  
      if( cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_YES_IN_CHAR)
			{
				  if((ret_status = Str_to_Num_Conv(cur_data_status.cur_data_rcvd_str, &seg7_disp_num)) == SUCCESS)
					{
					   	Reset_Parameters();
						  Seg7_Disp_1Digit_Num(seg7_disp_num);	
              keyboard_input_enable_flag = STATE_YES_IN_CHAR;					  
					}
					else
						break;
			}				
	}
	return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 System_Init(void)
{
	return HW_Init(NULL);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 Appl_Init(const void *const data_ptr)
{
	   set_next_data_config_types  set_next_data_config;
	
     Reset_Parameters();
	   set_next_data_config.set_next_data_id = CUR_DATA_ID_SEG7;
	   set_next_data_config.set_next_data_input_can_also_nonnum_key = STATE_NO_IN_CHAR;
	   set_next_data_config.set_next_data_input_dev_id = INPUT_DEV_ID_KEYBOARD;
    	set_next_data_config.set_next_data_input_max_num_try = DATA_SEG7_MAX_RETRY;
    	set_next_data_config.set_next_data_max_num_chars_to_rcv = DATA_SEG7_REQ_CHARS ;
    	set_next_data_config.set_next_data_output_dev_id = OUTPUT_DEV_ID_SEG7;
	    set_next_data_config.set_next_data_rcvd_char_disp_format = RCVD_CHAR_PLAIN_DISP_FORMAT;
     keyboard_input_enable_flag = STATE_YES_IN_CHAR;
	   keypad_keys_enable_flag = STATE_YES_IN_CHAR;
	   Next_Data_Conf_Parameter(&set_next_data_config);
	  return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 HW_Init(const void *const get_init_ptr)
{
	uint_8 ret_status = SUCCESS;
	PLL_Init();
	if((ret_status = GPIO_Init()) != SUCCESS)
	  return FAILURE;	
  return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.04  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x01; // PCLK is same as CCLK i.e.60 MHz
   	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.05  

BUGS           :              
-*------------------------------------------------------------*/
static uint_8 GPIO_Init(void)
{
	consucc_bit_type consucc_bit_data;
	uint_8 ret_status;
		
	consucc_bit_data.start_bit_pos = SEG7_PORT0_LSB_PIN;
	consucc_bit_data.bits_len = 8;
	consucc_bit_data.consucc_val = 0x0;
	if((ret_status = Config_Consucc_Bits((void *)&consucc_bit_data, FLAG_CONSUCC_BITS_1)) != SUCCESS)
	{
		   return FAILURE;
	}
	PINSEL2 = 0x0;
	PINSEL0 = 0x0;	
	IO0CLR = consucc_bit_data.consucc_val | 1 << UNIT_DIGIT_PORT0_PIN | 1 << TENS_DIGIT_PORT0_PIN ;
	IO0DIR = consucc_bit_data.consucc_val | 1 << UNIT_DIGIT_PORT0_PIN | 1 << TENS_DIGIT_PORT0_PIN ;
	IO1CLR = 1 << KEYPAD_PHONE_ROWA | 1 << KEYPAD_PHONE_ROWB | 1 << KEYPAD_PHONE_ROWC | 1 << KEYPAD_PHONE_ROWD | 0 << KEYPAD_PHONE_COL0 | 0 << KEYPAD_PHONE_COL1 | 0 << KEYPAD_PHONE_COL2;	
  IO1DIR = 1 << KEYPAD_PHONE_ROWA | 1 << KEYPAD_PHONE_ROWB | 1 << KEYPAD_PHONE_ROWC | 1 << KEYPAD_PHONE_ROWD | 0 << KEYPAD_PHONE_COL0 | 0 << KEYPAD_PHONE_COL1 | 0 << KEYPAD_PHONE_COL2;	
  return SUCCESS; 	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.06 

BUGS           :
-*------------------------------------------------------------*/
uint_8 Config_Consucc_Bits(void *const data_ptr, const uint_8 flag_consucc_bit)
{
	uint_32 from_bit0_consucc_bits = 0;	
	consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	uint_8 i, ret_status = SUCCESS;    
	
	if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	{
		return  FAILURE;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    ret_status = FAILURE;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.07 

BUGS           :
-*------------------------------------------------------------*/
uint_8 Test_Consucc_Bits(const void *const data_ptr, const uint_8 flag_consucc_bit)
{
	uint_32 from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	uint_8 i, ret_status = SUCCESS;	
	
	if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	{
		return FAILURE;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == (consucc_bit_ptr->consucc_val & mask_configured_bits))
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == (consucc_bit_ptr->consucc_val | mask_configured_bits))
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
			 default:
		      ret_status = FAILURE;
	}
	return ret_status;
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Seg7_Disp_1Digit_Num

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.08 

BUGS           :
-*------------------------------------------------------------*/
static void Seg7_Disp_1Digit_Num(const uint_32 seg7_rcv_disp_num)
{
	  
	  	uint_32 seg7_num = seg7_rcv_disp_num;		
		uint_8 seg7_digit[10],unit_digit;
		#ifdef SEG7_COMMON_CATHODE
	      uint_8 cc_digit[]   = {0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0x6F};
		  memcpy(seg7_digit, cc_digit, sizeof(cc_digit)/ sizeof(uint_8) );
	   #else
		  uint_8 ca_digit[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
	      memcpy(seg7_digit, ca_digit, sizeof(ca_digit)/ sizeof(uint_8) );   
	  #endif
				
		#ifdef CONFIG_PORTX_PINS
			   	consucc_bit_type consucc_bit_data;	        
       
          consucc_bit_data.start_bit_pos = SEG7_PORT0_LSB_PIN;
        	consucc_bit_data.bits_len = 8;
				#else
			IO0CLR= 0xFF << SEG7_PORT0_LSB_PIN;	
            #endif		
				
				unit_digit = seg7_num;
				
	   	 
       IO0SET = 1 << UNIT_DIGIT_PORT0_PIN;
      
			 #ifdef CONFIG_PORTX_PINS
			  
			 consucc_bit_data.consucc_val = seg7_digit[unit_digit];
			 Config_Port0_Pins((void *)&consucc_bit_data);  
        #else			 
			 	IO0SET = seg7_digit[unit_digit] <<SEG7_PORT0_LSB_PIN; 
				#endif
       SW_Time_Delay(MAX_ICOUNT_7SEG_SW_DELAY, MAX_JCOUNT_7SEG_SW_DELAY); 
}



/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.09  

BUGS           :              
-*------------------------------------------------------------*/
uint_8 Config_Port0_Pins(const void *const data_ptr)
{
	 uint_8 i; 
	 consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	
	 if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	 {
		   return FAILURE;
	 } 
	 for(i = consucc_bit_ptr->start_bit_pos ; i < consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len; ++i)
	 {
		   if(consucc_bit_ptr->consucc_val & 1 << i)
			 {
				   IO0SET = 1 << i;
			 }
			 else
			 {
				   IO0CLR = 1 << i;
			 }
	 }
	 return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Cur_Data_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.10 

BUGS           :
-*------------------------------------------------------------*/
void Reset_Cur_Data_Status(uint_8 set_cur_data_status_reset_type)
{
	switch(set_cur_data_status_reset_type)
	{
		case CUR_DATA_RESET_STATUS_WHOLE:
		  cur_data_status.cur_data_id = CUR_DATA_ID_INVALID;
	      cur_data_conf_parameter.cur_data_id = CUR_DATA_ID_INVALID;
		  cur_data_status.cur_data_input_num_try = 0;
		break;  
	}
	memset(cur_data_status.cur_data_rcvd_str, NULL_CHAR, sizeof(cur_data_status.cur_data_rcvd_str)/sizeof(char));
	cur_data_status.cur_data_num_chars_rcvd = 0;
	cur_data_status.cur_data_valid_end_rcvd_flag = STATE_NO_IN_CHAR;
	cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag = STATE_NO_IN_CHAR;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Next_Data_Conf_Parameter

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.11

Bugs           :   
-*------------------------------------------------------------*/
uint_8 Next_Data_Conf_Parameter(const set_next_data_config_types *const set_next_data_conf_ptr)
{
	if(set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv == CHARS_RCV_TILL_TERMINATOR_CHAR_MODE)
	{
		cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_TERMINATOR;
		cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
		cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = DATA_MAX_NUM_ALLOCATED_CHARS;
	}
	else
	{
		if(set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv <= DATA_MAX_NUM_ALLOCATED_CHARS)
		{
		   cur_data_conf_parameter.cur_data_rcv_mode = CUR_DATA_RCV_MODE_TILL_ALLOCATED;
		   cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv = set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv;
		   cur_data_conf_parameter.cur_data_conf_max_num_chars_to_rcv = set_next_data_conf_ptr->set_next_data_max_num_chars_to_rcv;
		}
	    else
		{
		/*	#ifdef TRACE_ERROR
			    UART_Transmit_Str("ERR: set max chars to enter > configured \r");
			#endif */
			return FAILURE;
		}
	}
    cur_data_status.cur_data_id = set_next_data_conf_ptr->set_next_data_id;
    cur_data_conf_parameter.cur_data_id = set_next_data_conf_ptr->set_next_data_id;
	cur_data_conf_parameter.cur_data_input_dev_id = set_next_data_conf_ptr->set_next_data_input_dev_id;
	cur_data_conf_parameter.cur_data_output_dev_id = set_next_data_conf_ptr->set_next_data_output_dev_id;
	cur_data_conf_parameter.cur_data_input_max_num_try = set_next_data_conf_ptr->set_next_data_input_max_num_try;
	cur_data_conf_parameter.cur_data_input_can_also_nonnum_key = set_next_data_conf_ptr->set_next_data_input_can_also_nonnum_key;
	cur_data_conf_parameter.cur_data_rcvd_char_disp_format = set_next_data_conf_ptr->set_next_data_rcvd_char_disp_format;
    return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.12  

BUGS           :  
-*------------------------------------------------------------*/
uint_8 Str_to_Num_Conv(const char *const num_in_str, uint_32 *num_conv_from_str )
{
	 unsigned long int num = 0, place = 1;
	 int cur_unit;
	 unsigned int num_chars = 0, cur_digit= 0, ten = 10, pos = 0;
	 
	 num_chars = Str_Len(num_in_str);
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - ZERO_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
		/* #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: 1: Non numeric char in str_to_num\r");
		 #endif */
		 *num_conv_from_str = 0; 
		 return FAILURE;
	 }	
     num = place * cur_unit;
     for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
     {
         place =  place * ten;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - ZERO_CHAR;
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			/* #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: 2: Non numeric char in str_to_num \r");
		     #endif */
			  *num_conv_from_str = 0;
			 return FAILURE;
		 }			 
         num += (cur_unit * place);     
     }
	 *num_conv_from_str = num; 
     return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.13  

BUGS           :  
-*------------------------------------------------------------*/
uint_8 Str_Len(const char *const str)
{
    unsigned int num_chars = 0;
	
    while(*(str + num_chars++));
    return num_chars - 1;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.14

BUGS           :    
-*------------------------------------------------------------*/
void Reset_Parameters(void)
{
	Reset_Cur_Data_Status(CUR_DATA_RESET_STATUS_WHOLE);
    Reset_Keyboard_Parameters();
	//Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
