
/**************************************************************************
   FILE          :    port.h
 
   PURPOSE       :    port header - define port and its pin assignment.
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    port header - user interface to external device, such as LED, Switch,
 	connection to other microcontroller via RS232, USB, etc. 
 To avoid this header file to be included more than once, conditional directive is used  
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_H
#define _PORT_H

/* ---------------------- macro defination ------------------------------------------------ */
typedef enum 
{
 	IO_CH_SEG7_CH_00_A_LED = (IO_CH_03), IO_CH_SEG7_CH_00_UNIT_DIGIT =  (IO_CH_11), IO_CH_SEG7_CH_00_TENS_DIGIT = (IO_CH_12), 
	IO_CH_KEYPAD_CH_00_ROWA = (IO_CH_48), IO_CH_KEYPAD_CH_00_ROWB , IO_CH_KEYPAD_CH_00_ROWC ,IO_CH_KEYPAD_CH_00_ROWD
} io_ch_map_op_ch_t;
    
typedef enum 
{ 
   IO_CH_KEYPAD_CH_00_COL1 = (IO_CH_52), IO_CH_KEYPAD_CH_00_COL2, IO_CH_KEYPAD_CH_00_COL3 
} io_ch_map_ip_ch_t ;

/* ---------------------- data type defination -------------------------------------------- */

/* -------------------- public variable declaration --------------------------------------- */
 
/* -------------------- public function declaration --------------------------------------- */

 
#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
