/**************************************************************************
   FILE          :    error.h
 
   PURPOSE       :     
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _ERROR_H
#define _ERROR_H

/* ---------------------- macro defination ------------------------------------------------ */

/* ---------------------- data type defination -------------------------------------------- */
typedef enum 
{
	NO_ERROR, ERR_IO_CONFIG_NULL_PTR, ERR_PORT_WRITE_VAL, ERR_PORT_WRITE_INIT_VAL, ERR_IO_CH_WRITE_DATA,
	ERR_IO_CONFIG_INDEX_INVALID, ERR_IO_CH_INVALID, ERR_CONFIG_IO_CH_MATCH_INVALID, ERR_GPIO_FUNC_SET,  ERR_IO_CH_00_FUNC_SET, 
	ERR_TRACE_FUNC_SET, ERR_IO_CH_48_FUNC_SET, ERR_IO_CH_58_FUNC_SET, ERR_PORT1_PIN_FUNC_SET, ERR_PORT_INVALID,
    ERR_CONFIG_PORT_INIT_VAL, ERR_IO_CH_GPIO_FUNC_SET, ERR_SW_CH_GPIO_FUNC_SET, ERR_GPIO_INPUT_FUNC_STATE, ERR_PIN_SIGNAL,
	ERR_PORT0_IO_PIN, ERR_PORT1_IO_PIN,  ERR_GPIO_CH_SET_PORT, ERR_IO_PIN_RANGE,  ERR_IO_CH_24_PIN, ERR_IO_CH_32_TO_47,
	ERR_CONF_INDEX_IO_CH_NULL_PTR, ERR_PORT_TO_IO_CONF_NULL_PTR, ERR_MAX_SW_CH_EXCEEDS, ERR_CONSUCC_PARA, ERR_STR_TO_NUM_PARA,
	ERR_STR_PTR_NULL, ERR_GPIO_OUTPUT_DATA, ERR_INVALID_PORT, ERR_IO_CH_READ_DATA, ERR_IO_CH_TO_SW_CH,
	ERR_IO_CH_RESERVE_PIN_FUNC_SET, ERR_GPIO_OUTPUT_FUNC_STATE, ERR_SW_CH_NOT_MATCH_IO_CH, ERR_CONFIG_PIN_RANGE, 
	ERR_CONFIG_DEBUG_FUNC_SET, ERR_CONFIG_TRACE_FUNC_SET, ERR_IO_CONFIG_TABLE_LARGE, ERR_TEST_FAIL_1_CONSUCC_BITS, ERR_TEST_FAIL_0_CONSUCC_BITS,
	ERR_KEYPAD_DISABLED, ERR_KEYPAD_ROW_WRITE, ERR_KEYPAD_INVALID_ROW, ERR_KEYPAD_COL_READ, ERR_KEYPAD_NO_ACCESS_COL,
	ERR_KEYPAD_EXCEEDS_CHARS, ERR_SW_NO_READ, ERR_SW_NO_ACCESS, ERR_READ_PORT_VAL, ERR_SEG7_NO_WRITE,
	ERR_SW_NOT_PRESSED, KEYPAD_DATA_READY, KEYPAD_REACH_MAX_CHARS_WAIT_TERMINATOR_KEY, KEYPAD_PRESSED_KEY_DETECT, ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED, 
	ERR_KEYBOARD_PROC, ERR_WRITE_NON_OUTPUT, ERR_PORT_WRITE_BIT_VAL, ERR_EXCEED_DATA_ID, ERR_NULL_PTR,
	ERR_INVALID_FORMAT, ERR_EXCEEDS_DATA_NUM_CHARS, ERR_DEV_SRC_ID_INVALID, ERR_ALREADY_MEM_ALLOC ,ERR_DATA_ID_CONF,
	ERR_DEV_CH_ID_EXCEEDS, ERR_DEV_CH_ID_OR_DATA_ID_INVALID, ERR_DEV_CH_ID_NO_ACCESS, ERR_PREV_AND_CUR_DATA_MATCH, 
	ERR_SEG7_DISABLED, NUM_SYS_ERR 
} system_error_flags_t;

/* -------------------- public variable declaration --------------------------------------- */

extern uint32_t error_flag;

/* -------------------- public function declaration --------------------------------------- */

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
