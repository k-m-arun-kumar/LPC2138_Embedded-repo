/**************************************************************************
   FILE          :    data_ids_map.h
 
   PURPOSE       :   
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
   
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _DATA_IDS_MAP_H
 #define _DATA_IDS_MAP_H 
 //                                           DATA_ID ,  TERMINATOR, RETRY, NONNUM, DISP_FORMAT,      REQ_MAX_CHARS     
 const data_id_ctrl_para_t data_ids_ctrl_para[]  = {  
	                                         { DATA_ID_SEG7, NULL_CHAR, 1, STATE_NO, RCVD_CHAR_PLAIN_DISP_FORMAT, 2 }
                                           };
 const data_id_dev_src_t  data_ids_dev_srcs[] = {
	                                             {DATA_ID_SEG7, {INPUT_DEV_ID_KEYBOARD, CH_ID_00, INPUT_DEV_ID_INVALID }, {OUTPUT_DEV_ID_SEG7, CH_ID_00, OUTPUT_DEV_ID_INVALID}}
                                             };	
											 
  											 

#endif
																						 
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
																						 
