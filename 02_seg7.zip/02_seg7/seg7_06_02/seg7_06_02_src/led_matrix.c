/**************************************************************************
   FILE          :    led_matrix.c
 
   PURPOSE       :     
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 05  
	   
 **************************************************************************/
 
 #ifdef LED_MATRIX_MOD_ENABLE
 
 #include "main.h"
 #include "led_matrix.h" 
 #include "io_conf.h"
 #include "appl_conf.h"
 
/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */


/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */

/*------------------------------------------------------------*
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :               

Func ID        : 03.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t LED_Matrix_5_7_Disp(const uint8_t led_matrix_data_code)
{
	
     // Define row values for each of the five columns corresponding to Alphabets A through Z and some symbols
      const uint8_t led_dot_disp[][5]={ 
	                                   {0x7e, 0x09, 0x09, 0x09, 0x7E}, // A
		                               {0x7f, 0x49, 0x49, 0x49, 0x36},  // B
									   {0x3e, 0x41, 0x41, 0x41, 0x22},
									   {0x7f, 0x41, 0x41,0x22, 0x1c},
									   {0x7f, 0x49, 0x49, 0x49, 0x63},
									   {0x7f, 0x09, 0x09, 0x09, 0x01},
									   {0x3e, 0x41, 0x41, 0x49, 0x7a},
									   {0x7f, 0x08, 0x08, 0x08, 0x7f},
									   {0x00, 0x41, 0x7f, 0x41, 0x00},  // I
									   {0x20, 0x40, 0x41, 0x3f, 0x01},
									   {0x7f, 0x08, 0x14, 0x22, 0x41},
									   {0x7f, 0x40, 0x40, 0x40, 0x60},
									   {0x7f, 0x02, 0x04, 0x02, 0x7f},
									   {0x7f, 0x04, 0x08, 0x10, 0x7f},
									   {0x3e, 0x41, 0x41, 0x41, 0x3e},
									   {0x7f, 0x09, 0x09, 0x09, 0x06},
									   {0x3e, 0x41, 0x51, 0x21, 0x5e},
									   {0x7f, 0x09, 0x19, 0x29, 0x46},
									   {0x46, 0x49, 0x49, 0x49, 0x31},  // S
									   {0x01, 0x01, 0x7f, 0x01, 0x01},
									   { 0x3f, 0x40, 0x40, 0x40, 0x3f},
									   {0x1f, 0x20, 0x40, 0x20, 0x1f},
									   { 0x3f, 0x40, 0x30, 0x40, 0x3f},
									   { 0x63, 0x14, 0x08, 0x14, 0x63},
									   {0x07, 0x08, 0x70, 0x08, 0x07},
									   { 0x61, 0x51, 0x49, 0x45, 0x43}, // Z
									   {0x24, 0x2A, 0x7f, 0x2A, 0x12}, // $
									   {0x08, 0x14, 0x22, 0x41, 0x00}, // <
								 	   {0x41, 0x22, 0x14, 0x08, 0x00}, // >
									   {0x14, 0x14, 0x14, 0x14, 0x14}, // =
									   {0x36, 0x49, 0x55, 0x22, 0x50}, // &
									   {0x44, 0x3c, 0x04, 0x7c, 0x44} // PI
                               };
							   
		uint8_t col_scan, i;
		
		for(col_scan = 0; col_scan < 5; ++col_scan)
		{
			led_dot_disp[led_matrix_data_code][col_scan];
		}
          	
}

/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used
                 as required by proteus simulation

Func ID        : 02.02  

BUGS           :     
-*------------------------------------------------------------*/
 uint8_t KeyBoard_Col_Scan(const uint8_t select_row )
{
   	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};		
		
    if(keypad_keys_enable_flag == STATE_YES_IN_CHAR && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO_IN_CHAR) 
		{
			 if(keypad_col[0] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL0)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL0 ))
			     {
		       	   keypad_col[0] = KEY_PRESSED;
               while(!(IO1PIN & 1 << KEYPAD_PHONE_COL0 ));						 
			       	 SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			         if(IO1PIN & 1 << KEYPAD_PHONE_COL0)
		           {
		              keypad_col[0] = KEY_RELEASED;
							    switch(select_row)
								  {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT:
                        if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{													
											     cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch
												   break;
												}
												return SUCCESS;	
										default:	
                                          return FAILURE;
                   									
								}	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			       }				 
			    }	   
		   }
			 if(keypad_col[1] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL1)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL1 ))
			     {
						   keypad_col[1] = KEY_PRESSED;
               while(!(IO1PIN & 1 << KEYPAD_PHONE_COL1 ));						 
			       	 SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			         if(IO1PIN & 1 << KEYPAD_PHONE_COL1)
		           {
			            keypad_col[1] = KEY_RELEASED;
	                switch(select_row)
								  {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch
										 break;	
									     default:	
                                            return FAILURE;	 
								}						 
				        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 if(keypad_col[2] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL2)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL2 ))
			     {
		       	   keypad_col[2] = KEY_PRESSED;
               while(!(IO1PIN & 1 << KEYPAD_PHONE_COL2 ));						 
			       	 SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			         if(IO1PIN & 1 << KEYPAD_PHONE_COL2)
		           {
			            keypad_col[2] = KEY_RELEASED; 	           
		              switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{
											       cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch
													   break;
												}
												return SUCCESS; 
                                          default:	
                                          return FAILURE; 				   
								}							       	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 return SUCCESS;
	 	}
		return FAILURE;		
	}	

#ifdef UNUSED
/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 	halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used                  

Func ID        : 02.02  

BUGS           :     
-*------------------------------------------------------------*/
 uint8_t KeyBoard_Col_Scan(const uint8_t select_row )
{
   	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};		
		
    if(keypad_keys_enable_flag == STATE_YES_IN_CHAR && cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR && cur_data_status.cur_data_valid_end_rcvd_flag == STATE_NO_IN_CHAR) 
		{
			 if(keypad_col[0] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL0)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL0 ))
			     {
		       	   keypad_col[0] = KEY_PRESSED; 
			     }      			
		   }
       else
		   {
		    	if( keypad_col[0] == KEY_PRESSED && (IO1PIN & 1 << KEYPAD_PHONE_COL0 ))
		    	{
			       SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			       if(IO1PIN & 1 << KEYPAD_PHONE_COL0)
		         {
		             keypad_col[0] = KEY_RELEASED;
							   switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT:
                        if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{													
											     cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch
												   break;
												}
												return SUCCESS;
                                      	default:	
                                          return FAILURE;											
								}	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 if(keypad_col[1] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL1)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL1 ))
			     {
		       	   keypad_col[1] = KEY_PRESSED; 
			     }      			
		   }
       else
		   {
		    	if( keypad_col[1] == KEY_PRESSED && (IO1PIN & 1 << KEYPAD_PHONE_COL1 ))
		    	{
			       SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			       if(IO1PIN & 1 << KEYPAD_PHONE_COL1)
		         {
		            keypad_col[1] = KEY_RELEASED;
	               switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch
										 break;	
                                         default:	
                                          return FAILURE;										 
								}						 
				        Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 if(keypad_col[2] == KEY_RELEASED && (!(IO1PIN & 1 << KEYPAD_PHONE_COL2)))
			 {
			     SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			     if( !(IO1PIN & 1 << KEYPAD_PHONE_COL2 ))
			     {
		       	   keypad_col[2] = KEY_PRESSED; 
			     }      			
		   }
       else
		   {
		    	if( keypad_col[2] == KEY_PRESSED && (IO1PIN & 1 << KEYPAD_PHONE_COL2 ))
		    	{
			       SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
			       if(IO1PIN & 1 << KEYPAD_PHONE_COL2)
		         {
		            keypad_col[2] = KEY_RELEASED;
                 switch(select_row)
								 {
									   case KEYPAD_ROWA_SELECT:
											   cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWB_SELECT: 
											  cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWC_SELECT:
											   cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch
										 break;
										 case KEYPAD_ROWD_SELECT: 
											  if(cur_data_conf_parameter.cur_data_input_can_also_nonnum_key ==  STATE_YES_IN_CHAR )		
												{
											       cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch
													   break;
												}
												return SUCCESS;  
										 break;
                                         default:	
                                          return FAILURE;										 
								}							       	
                Entered_Key_No_Long_Press_Proc(cur_pressed_key_or_sw);
			      }				 
			    }	   
		   }
			 return SUCCESS;
	 	}
		return FAILURE;		
	}	
#endif
/*------------------------------------------------------------*
FUNCTION NAME  : Entered_Key_No_Long_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : make sure that entered key is within max available lcd loc and line, currently cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv 
	 sures that entered key is within max available lcd loc and within max line 

Func ID        : 02.03

BUGS           :   
-*------------------------------------------------------------*/
uint8_t Entered_Key_No_Long_Press_Proc(const char cur_key_char)
{	 
   if(cur_data_status.cur_data_max_allocated_num_chars_rcvd_flag == STATE_NO_IN_CHAR) 
	 {
		    IO0CLR = 1 << UNIT_DIGIT_PORT0_PIN;
        IO0CLR = 1 << TENS_DIGIT_PORT0_PIN ;
	 } 	 
   cur_data_status.cur_data_rcvd_str[cur_data_status.cur_data_num_chars_rcvd] = cur_key_char;   
   ++cur_data_status.cur_data_num_chars_rcvd;
   	
	 return SUCCESS; 
	  
} 

#endif


/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
