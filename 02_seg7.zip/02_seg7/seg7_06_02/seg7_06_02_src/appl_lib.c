/* ********************************************************************
FILE                   : appl_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 02 

*****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include "main.h"
#include "data_ids_map.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t Data_ID_Input_Src_Set(const uint8_t data_id, const data_id_dev_src_t *const cur_data_id_dev_src_conf_ptr);
static uint8_t Data_ID_Output_Src_Set(const uint8_t data_id, const data_id_dev_src_t * const cur_data_id_dev_src_conf_ptr);

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.01  

BUGS           :              
-*------------------------------------------------------------*/
void SW_Time_Delay(const uint32_t max_i_count, const uint32_t max_j_count)
{
	 uint32_t i, j;
	 for(i = 0; i < max_i_count; ++i)
	 { 
         for(j = 0;j < max_j_count; ++j);
	 } 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.02 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0;	
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;     
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return  error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    error_flag = ERR_CONSUCC_PARA;
		    ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.03 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;	
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == (consucc_bit_ptr->consucc_val & mask_configured_bits))
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					   error_flag = ERR_TEST_FAIL_1_CONSUCC_BITS;
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == (consucc_bit_ptr->consucc_val | mask_configured_bits))
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    error_flag = ERR_TEST_FAIL_0_CONSUCC_BITS;
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
			 default:
			 error_flag = ERR_CONSUCC_PARA;
		      ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.04  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_to_Num_Conv(uint32_t *const num_conv_from_str, const char *const num_in_str  )
{
	
	 uint32_t num = 0, place = 1;
	 int32_t cur_unit;
	 uint8_t num_chars = 0, cur_digit= 0, ten = 10, pos = 0;
	
	 if(num_conv_from_str == NULL_PTR || num_in_str == NULL_PTR )
	 {
		 error_flag = ERR_STR_TO_NUM_PARA;
		 return error_flag;
	 }
	 num_chars = Str_Len(num_in_str);
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - ZERO_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
		/* #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: 1: Non numeric char in str_to_num\r");
		 #endif */
		 *num_conv_from_str = 0;
         error_flag = ERR_STR_TO_NUM_PARA;		 
		 return error_flag;
	 }	
     num = place * cur_unit;
     for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
     {
         place =  place * ten;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - ZERO_CHAR;
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			/* #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: 2: Non numeric char in str_to_num \r");
		     #endif */
			  *num_conv_from_str = 0;
			 error_flag = ERR_STR_TO_NUM_PARA; 
			 return error_flag;
		 }			 
         num += (cur_unit * place);     
     }
	 *num_conv_from_str = num; 
     return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_Len(const char *const str)
{
    uint8_t num_chars = 0;
	
	  if(str == NULL_PTR)
		{
			 error_flag = ERR_STR_PTR_NULL;	
			 return 0;
		}
    while(*(str + num_chars++));
    return num_chars - 1;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Data_ID_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.06

BUGS           :
-*------------------------------------------------------------*/
uint8_t Reset_Data_ID_Status(const uint8_t data_id, const uint8_t set_cur_data_status_reset_type)
{
	data_id_status_para_t *data_id_status_para_ptr = NULL_PTR;
	uint8_t i = 0, ret_status = SUCCESS;
	
	if(data_id >= NUM_DATA_IDS)
	{
		 error_flag = ERR_EXCEED_DATA_ID;
		 return error_flag;
	}
	data_id_status_para_ptr = data_id_status_para + data_id;
	switch(set_cur_data_status_reset_type)
	{
		case DATA_ID_RESET_INIT_STATUS:
			 for(i = 0; i < REQ_DATA_INPUT_DEVS_CONF; ++i)
	         {		
	            data_id_status_para_ptr->data_input_devs_conf[i] = 0;
	         }
	         for(i = 0; i < REQ_DATA_OUTPUT_DEVS_CONF; ++i)
	         {
		       data_id_status_para_ptr->data_output_devs_conf[i] = 0;
	         }
	    #ifdef DMA_DATA_ID_STR
	   if(data_id_status_para_ptr->data_str != NULL_PTR)
	    {
	    	free(data_id_status_para_ptr->data_str);
		    data_id_status_para_ptr->data_str = NULL_PTR;
	    } 
		#endif
		data_id_status_para_ptr->max_allocated_data_len = 0;
		case DATA_ID_RESET_WHOLE_STATUS:		 
	    data_id_status_para_ptr->data_input_num_try = 0;		  
		case DATA_ID_RESET_RETRY_STATUS:
        data_id_status_para_ptr->data_str_len = 0;
	    data_id_status_para_ptr->valid_input_terminator_flag = STATE_NO;
	    data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_NO;
	
	#ifdef DMA_DATA_ID_STR
      if(data_id_status_para_ptr->data_str != NULL_PTR)
    #endif		
	  {
          memset(data_id_status_para_ptr->data_str, NULL_CHAR, data_id_status_para_ptr->max_allocated_data_len * sizeof(char) );	
	  } 
	    
     break;
	 default:
    	error_flag = ERR_INVALID_FORMAT;
      return error_flag;	 
	}
	 return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Data_IDs_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.07

BUGS           :
-*------------------------------------------------------------*/
void Reset_Data_IDs_Status(void)
{
	 uint8_t cur_data_id;
	
	 for(cur_data_id = 0; cur_data_id < NUM_DATA_IDS; ++cur_data_id)
	 {
		  Reset_Data_ID_Status(cur_data_id, DATA_ID_RESET_INIT_STATUS);
	 }
	 cur_data_id = DATA_ID_INVALID;
}

#ifdef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Devs_Src_Set

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.08 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_ID_Devs_Src_Set(const data_id_dev_src_t * const data_id_dev_src_conf_ptr, const uint8_t num_conf_size)
{
	const data_id_dev_src_t *cur_data_id_dev_src_conf_ptr = NULL_PTR;
	uint8_t data_id, ret_status = SUCCESS;
	
	if(data_id_dev_src_conf_ptr == NULL_PTR || num_conf_size <= 0)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
	for(data_id = 0; data_id < num_conf_size; ++data_id)
	{
		cur_data_id_dev_src_conf_ptr =  data_id_dev_src_conf_ptr + data_id;
		if((ret_status = Data_ID_Input_Src_Set(data_id, cur_data_id_dev_src_conf_ptr)) != SUCCESS)
		{
			break;
		}
		if((ret_status = Data_ID_Output_Src_Set(data_id, cur_data_id_dev_src_conf_ptr)) != SUCCESS)
		{
			break;
		}
	}
	if(ret_status != SUCCESS)
	{
		Reset_Data_IDs_Status();
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Input_Src_Set

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.09 

Bugs           :   
-*------------------------------------------------------------*/
static uint8_t Data_ID_Input_Src_Set(const uint8_t data_id, const data_id_dev_src_t *const cur_data_id_dev_src_conf_ptr)
{
      uint8_t ret_status = SUCCESS, dev_src_index, dev_src_arr_index, dev_src_arr_bit, cur_dev_id, dev_ch_id;

      if(cur_data_id_dev_src_conf_ptr == NULL_PTR || data_id >= NUM_DATA_IDS)
	  {
		  error_flag = ERR_NULL_PTR;
		  return error_flag;
	  }	  
      dev_src_index = 0; 
		
		cur_dev_id = cur_data_id_dev_src_conf_ptr->data_input_dev_ids[dev_src_index].dev_id;
		while(cur_dev_id < NUM_INPUT_DEVS )
		{
			dev_src_arr_index = cur_dev_id / (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
			dev_src_arr_bit = ((((cur_dev_id * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
			dev_ch_id = cur_data_id_dev_src_conf_ptr->data_input_dev_ids[dev_src_index].dev_ch_id;
			switch(cur_dev_id)
			{
				case INPUT_DEV_ID_UART:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_UART_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;  
				case INPUT_DEV_ID_I2C:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_I2C_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_SPI:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_SPI_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_MISC:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_MISC_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_ADC:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_KEYBOARD:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_SW:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_SW_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				default:
				  error_flag = ERR_DATA_ID_CONF;
				  return error_flag;
			}
			dev_ch_id = (dev_ch_id << 1) | 0x01;			
			data_id_status_para[data_id].data_input_devs_conf[dev_src_arr_index] |= (dev_ch_id << dev_src_arr_bit);
		   	++dev_src_index;
		    cur_dev_id = cur_data_id_dev_src_conf_ptr->data_input_dev_ids[dev_src_index].dev_id;
		}
		return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Output_Src_Set

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
static uint8_t Data_ID_Output_Src_Set(const uint8_t data_id, const data_id_dev_src_t * const cur_data_id_dev_src_conf_ptr)
{
      uint8_t ret_status = SUCCESS, dev_src_index, dev_src_arr_index, dev_src_arr_bit, cur_dev_id, dev_ch_id;

      if(cur_data_id_dev_src_conf_ptr == NULL_PTR || data_id >= NUM_DATA_IDS)
	  {
		  error_flag = ERR_NULL_PTR;
		  return error_flag;
	  }	  
       dev_src_index = 0; 
		cur_dev_id = cur_data_id_dev_src_conf_ptr->data_output_dev_ids[dev_src_index].dev_id;
		while(cur_dev_id < NUM_OUTPUT_DEVS )
		{
			dev_src_arr_index = cur_dev_id / (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
			dev_src_arr_bit = ((((cur_dev_id * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
			dev_ch_id = cur_data_id_dev_src_conf_ptr->data_output_dev_ids[dev_src_index].dev_ch_id;
			switch(cur_dev_id)
			{
				case OUTPUT_DEV_ID_UART:
				   if(dev_ch_id >= NUM_OUTPUT_DEV_ID_UART_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break; 
				case OUTPUT_DEV_ID_I2C:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_I2C_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break; 
				case OUTPUT_DEV_ID_SPI:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_SPI_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_MISC:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_MISC_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_DAC:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_DAC_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_PWM:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_PWM_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_LCD:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_SEG7:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				default:
				  error_flag = ERR_DATA_ID_CONF;
				  return error_flag;
			}
			dev_ch_id = (dev_ch_id << 1) | 0x01;			
			data_id_status_para[data_id].data_output_devs_conf[dev_src_arr_index] |= (dev_ch_id << dev_src_arr_bit);
		   	++dev_src_index;
		    cur_dev_id = cur_data_id_dev_src_conf_ptr->data_output_dev_ids[dev_src_index].dev_id;
		}
       return ret_status;
}
#endif
/*------------------------------------------------------------*
FUNCTION NAME  : Data_IDs_Set_Para

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.11 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_IDs_Set_Para(void)
{
	uint8_t data_id = 0, ret_status = SUCCESS;
	
	#ifdef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
	if((ret_status =  Data_ID_Devs_Src_Set(data_ids_dev_srcs, sizeof(data_ids_dev_srcs)/sizeof(data_id_dev_src_t))) != SUCCESS)
	{
		error_flag = ERR_DEV_SRC_ID_INVALID;
		return ret_status;
	} 
	#endif
	for(data_id = 0; data_id < NUM_DATA_IDS; ++data_id)
	{
		 if((ret_status = Data_ID_Set_Para(data_id)) != SUCCESS)
		 {
			 error_flag = ERR_DATA_ID_CONF;
			 break;
		 }
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Set_Para

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.12 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_ID_Set_Para(const uint8_t data_id)
{
	data_id_status_para_t *data_id_status_para_ptr = NULL_PTR;
		
	if(data_id >= NUM_DATA_IDS)
	{
		 error_flag = ERR_EXCEED_DATA_ID;
		 return error_flag;
	}
	data_id_status_para_ptr = data_id_status_para + data_id;
	if(data_ids_ctrl_para[data_id].max_req_data_len + 1 > DATA_MAX_NUM_ALLOCATED_CHARS)
		 	{
				  data_id_status_para_ptr->max_allocated_data_len = 0;
				  error_flag = ERR_EXCEEDS_DATA_NUM_CHARS;
		      return error_flag;
		 	}
			data_id_status_para_ptr->data_id = data_id;
	        
		    data_id_status_para_ptr->max_allocated_data_len = data_ids_ctrl_para[data_id].max_req_data_len + 1;	
			if(data_ids_ctrl_para[data_id].data_input_terminator == NULL_CHAR)
	    {
		      data_id_status_para_ptr->data_input_mode = DATA_ID_INPUT_MODE_TILL_ALLOC;				 
	    }
	    else
    	{
		     data_id_status_para_ptr->data_input_mode = DATA_ID_INPUT_MODE_TILL_TERMINATOR;
	    }
		
		#ifdef DMA_DATA_ID_STR
		if(data_id_status_para_ptr->data_str != NULL_PTR)
	    {
           error_flag = ERR_ALREADY_MEM_ALLOC;
		   return error_flag;
	    }
        data_id_status_para_ptr->data_str = (char *) malloc(data_id_status_para_ptr->max_allocated_data_len * sizeof(char));	*/
        #endif	
		
		data_id_status_para_ptr->data_input_num_try = 0;		
        data_id_status_para_ptr->data_str_len = 0;
	    data_id_status_para_ptr->valid_input_terminator_flag = STATE_NO;
	    data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_NO;
      
	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
