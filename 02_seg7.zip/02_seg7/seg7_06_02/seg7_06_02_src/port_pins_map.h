/**************************************************************************
   FILE          :    port_pins_map.h
 
   PURPOSE       :   
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE   Prerequisite :  Make sure that details of io_config are correct as per data sheet for pins and our semantic.                         
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _PORT_PINS_MAP_H
#define _PORT_PINS_MAP_H

/* ---------------------- macro defination ------------------------------------------------ */

/* ---------------------- data type defination -------------------------------------------- */

/* -------------------- public variable declaration --------------------------------------- */
 
/* -------------------- public function declaration --------------------------------------- */

 //                                        IO_CH,             IO_CH_SIGNAL,     IO_FUNC,        IO_DIR,    INITIAL_STATE,  FUNC_TYPE,         LEN
 const io_config_t io_config[] = {
	                                     { IO_CH_KEYPAD_CH_00_COL1, PIN_SIG_DIGITAL, IO_FUNC_GPIO, IO_DIR_INPUT, STATE_LOW, IO_FUNC_TYPE_GPIO_SW,      3},
										 { IO_CH_KEYPAD_CH_00_ROWA, PIN_SIG_DIGITAL, IO_FUNC_GPIO, IO_DIR_OUTPUT, STATE_LOW, IO_FUNC_TYPE_GPIO_NON_SW, 4},
										 { IO_CH_SEG7_CH_00_A_LED, PIN_SIG_DIGITAL, IO_FUNC_GPIO, IO_DIR_OUTPUT, STATE_LOW, IO_FUNC_TYPE_GPIO_NON_SW,  10}
													                                         
							     };
  
									 
#endif                         

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
