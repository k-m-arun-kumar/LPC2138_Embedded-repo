/* ********************************************************************
FILE                   : io_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 03 

*****************************************************************************/
#include "main.h"


/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
static uint32_t volatile *const io_port_func_ptr[NUM_PORT_CHS + 1] = {(uint32_t *) &PINSEL0,(uint32_t *) &PINSEL1, (uint32_t *) &PINSEL2 };
static uint32_t volatile *const io_port_dir_ptr[NUM_PORT_CHS] = { (uint32_t *) &IO0DIR, (uint32_t *) &IO1DIR };
static uint32_t volatile *const io_port_set_ptr[NUM_PORT_CHS] = {(uint32_t *)&IO0SET, (uint32_t *) &IO1SET};
static uint32_t volatile *const io_port_clr_ptr[NUM_PORT_CHS] = {(uint32_t *) &IO0CLR, (uint32_t *) &IO1CLR};
static uint32_t volatile *const io_port_ptr [NUM_PORT_CHS] = {(uint32_t *) &IO0PIN, (uint32_t *) &IO1PIN};
static uint8_t sw_ch_index = 0;
static uint32_t config_port_pin[NUM_PORT_CHS];
uint32_t default_port_mask[NUM_PORT_CHS] = { 0xFEFFFFFF, 0xFFFF0000};

/* ----------------------------- global variable declaration -------------------- */
extern sw_para_t sw_para[ ];
extern const io_config_t io_config[];
/* ----------------------------- global function declaration -------------------- */
static uint8_t GPIO_Func_Set(const io_config_t *const cur_io_config_ptr);
static uint8_t Debug_IO_Func_Set_Validate(const io_config_t *const cur_io_config_ptr);
static uint8_t Trace_IO_Func_Set_Validate(const io_config_t *const cur_io_config_ptr);
static uint8_t IO_Conf_Index_To_IO_Ch(uint8_t *const io_ch, const uint8_t io_config_index);
static uint8_t Port_To_IO_Config_Index( uint8_t *const io_config_index, const io_port_t *const io_port_ptr);
/*------------------------------------------------------------*
FUNCTION NAME  : IO_Channels_Func_Set

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.01  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Channels_Func_Set(const io_config_t * const io_config_ptr, uint8_t num_io_config_elements)
{
	 const io_config_t *cur_io_config_ptr = NULL_PTR;
	 uint8_t io_config_index, port, port_pin, io_ch, ret_status = SUCCESS ;
		
	 if(io_config_ptr == NULL_PTR || num_io_config_elements <= 0)
	 {
		 error_flag =  ERR_IO_CONFIG_NULL_PTR;
		  return error_flag; 
	 }
	 Reset_IO_Chs();	 
	 for(io_config_index = 0; io_config_index	< num_io_config_elements; ++io_config_index)
	 {
		  cur_io_config_ptr = io_config_ptr + io_config_index; 
		  if((ret_status = Config_Port_Pin_Range_Validate(cur_io_config_ptr )) != SUCCESS)
			{
				   error_flag = ret_status;
					 goto IO_INIT_FAILURE;	
					 //break;
			}
			     		
	   // common to all IO pin's function process 
	  	switch(cur_io_config_ptr->func)
	  	{
		     case IO_FUNC_GPIO:
		        if((ret_status = GPIO_Func_Set(cur_io_config_ptr)) != SUCCESS)
		        {
						  	error_flag = ERR_GPIO_FUNC_SET;
							  goto IO_INIT_FAILURE;	
							  //break;
		        }
						continue;			  
				 //break;
			    case IO_FUNC_UNUSED:
			    case IO_FUNC_RESERVE:
			       continue;	
          //break;					
		  }
		 	 port  = io_ch / NUM_PINS_PER_PORT;
		   port_pin = io_ch % NUM_PINS_PER_PORT;
	    switch(port)
		  {			 
		     case	PORT_CH_00:
				     switch(port_pin)
				     {
				    	 case PIN_00:
					 	     switch(cur_io_config_ptr->func)
		             {
                    case IO_FUNC_UART:
			              break;
			              case IO_FUNC_PWM:
			              break;
							    	default:
									    error_flag = ERR_IO_CH_00_FUNC_SET;
							    		ret_status = error_flag;
							      	goto IO_INIT_FAILURE;	
                    //break; 										
						     }
					     break;
				   }
       break;
       case PORT_CH_01:
				 switch(port_pin)
				 {
					   case PIN_16:
							  switch(cur_io_config_ptr->func)
	  	          {
		               case IO_FUNC_TRACE:
										 if((ret_status = Trace_IO_Func_Set_Validate(cur_io_config_ptr)) != SUCCESS)
										 {
											 error_flag = ERR_TRACE_FUNC_SET;											 
											 goto IO_INIT_FAILURE;	
                       //break;											 
										 }
										 *io_port_func_ptr[2] |= (IO_FUNC_MODE_01 << 3);
                   break;
									 default:
									    error_flag = ERR_IO_CH_48_FUNC_SET;
										 ret_status = error_flag;
							       goto IO_INIT_FAILURE;	
                   // break;									 
						    }
							    							
						 break;
             case PIN_26:
							  switch(cur_io_config_ptr->func)
	  	          {
		               case IO_FUNC_DEBUG:
										 if((ret_status = Debug_IO_Func_Set_Validate(cur_io_config_ptr)) != SUCCESS)
										 {
										   error_flag = ERR_TRACE_FUNC_SET;											
											  goto IO_INIT_FAILURE;	
                       //break;											 
										 }
										 *io_port_func_ptr[2] |= (IO_FUNC_MODE_01 << 2);
                   break;
									 default:
									   error_flag = ERR_IO_CH_58_FUNC_SET;
										 ret_status = error_flag;
							       goto IO_INIT_FAILURE;
									 //break;
						 	    	
						    }         							
						 break;	
             default:
			           error_flag = ERR_PORT1_PIN_FUNC_SET;
                 ret_status = error_flag;
					       goto IO_INIT_FAILURE;
						 //break;
					  	 
				 }				 
        break;
				default:
				error_flag = ERR_PORT_INVALID;
					ret_status = error_flag; 
				break;
		  }			 
   }	 
IO_INIT_FAILURE:  
   if(ret_status != SUCCESS)
    {				
          Reset_IO_Chs();       		
	  }		
	   return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Port_Write

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.02  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Port_Write(const uint8_t io_channel, const void *const data_ptr)
{
	 consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr, consucc_bits_1;
	 uint8_t port, port_pin, ret_status = SUCCESS, end_port_pin;
 	 
	 end_port_pin = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	 port = io_channel / NUM_PINS_PER_PORT;
	 port_pin = io_channel % NUM_PINS_PER_PORT;	 
	 if(consucc_bit_ptr == NULL_PTR || consucc_bit_ptr->start_bit_pos != port_pin || consucc_bit_ptr->bits_len <= 0 || end_port_pin >= NUM_PINS_PER_PORT )
	 {
		   error_flag = ERR_PORT_WRITE_VAL;
		   return error_flag;
	 } 
	 if((ret_status = IO_Ch_Validate(io_channel, consucc_bit_ptr->bits_len)) != SUCCESS)
	 {
	     error_flag = ERR_PORT_WRITE_VAL;
	     return error_flag;
	 }
	 consucc_bits_1.start_bit_pos = consucc_bit_ptr->start_bit_pos;
	 consucc_bits_1.bits_len = consucc_bit_ptr->bits_len;
	 consucc_bits_1.consucc_val = 0;
     if((ret_status = Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &consucc_bits_1)) != SUCCESS )
	 {
		 error_flag = ERR_PORT_WRITE_INIT_VAL;
		 return error_flag;
	 }
     if(consucc_bits_1.consucc_val != (*io_port_dir_ptr[port] & consucc_bits_1.consucc_val ))
	 {
		 error_flag = ERR_WRITE_NON_OUTPUT;
		 return error_flag;
	 }
	 if(consucc_bits_1.consucc_val != (consucc_bits_1.consucc_val | consucc_bit_ptr->consucc_val << consucc_bit_ptr->start_bit_pos))
	 {
		  error_flag = ERR_PORT_WRITE_BIT_VAL;
		 // to set data in port not within valid range for a bit len  ie for bit len - 3, then valid value range is [0,7] 
		 return error_flag;
	 }
		
	 *io_port_ptr[port] = ( *io_port_ptr[port] & ~consucc_bits_1.consucc_val ) | (consucc_bit_ptr->consucc_val << consucc_bit_ptr->start_bit_pos);
	 return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Channel_Write

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.03  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Channel_Write(const uint8_t io_channel, const uint8_t data)
{
	 uint8_t port, port_pin, ret_status = SUCCESS;
    
	 if((ret_status = IO_Ch_Validate(io_channel, 1)) != SUCCESS)
	 {
		   error_flag = ERR_IO_CH_WRITE_DATA;
		   return error_flag; 
	 }
	 port = io_channel / NUM_PINS_PER_PORT;
	 port_pin = io_channel % NUM_PINS_PER_PORT;
     if(!(*io_port_dir_ptr[port] & (1 << port_pin)))
	 {
		 error_flag = ERR_WRITE_NON_OUTPUT;
		 return error_flag;
	 } 
	switch(data)
	{
		case STATE_HIGH:
	      *io_port_set_ptr[port] = 1 << port_pin;	    
		 break;
		 case STATE_LOW:
  	        *io_port_clr_ptr[port] = 1 << port_pin;	
         break;
         default:
	       error_flag = ERR_IO_CH_WRITE_DATA;
           ret_status = error_flag;			 
	 }
	 return ret_status;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Ports

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.04  

BUGS           :              
-*------------------------------------------------------------*/
void Reset_Ports(void)
{
	uint32_t io_port_dir;
	uint8_t i;
	
    for(i = 0; i < NUM_PORT_CHS + 1; ++i)
	 {
	    *io_port_func_ptr[i] = IO_FUNC_GPIO;
	 }
	 for(i = 0; i < NUM_PORT_CHS; ++i)
	 {
		   *io_port_dir_ptr[i] = 0;
		 	 *io_port_ptr[i] =  0 & default_port_mask[i];
		   config_port_pin[i] = 0;		  
	 }
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Channel_Read

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.05  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Channel_Read(const uint8_t io_ch, uint8_t *const read_data_ptr)
{
	 uint8_t port, port_pin, ret_status  ;
	
	 if((ret_status = IO_Ch_Validate(io_ch, 1)) != SUCCESS)
	 {
		   error_flag = ERR_IO_CH_READ_DATA;
		   return error_flag; 
	 }
   
   port = io_ch / NUM_PINS_PER_PORT;
	 port_pin = io_ch % NUM_PINS_PER_PORT;
	 if(*io_port_ptr[port] & (1 << port_pin))
	 {
		   *read_data_ptr = STATE_HIGH;
	 }
	 else
	 {
	     *read_data_ptr =  STATE_LOW;	 
	 }
	 return ret_status; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : GPIO_Func_Set

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 

Func ID        : 03.06  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t GPIO_Func_Set(const io_config_t *const cur_io_config_ptr)
{
	  uint8_t port, start_port_pin, end_port_pin, ret_status = SUCCESS, i, cur_port_pin, cur_pin_sel, cur_pin_sel_bit ;
	 	
	  port = cur_io_config_ptr->io_ch / NUM_PINS_PER_PORT;
	  start_port_pin = cur_io_config_ptr->io_ch % NUM_PINS_PER_PORT;
	
	 switch(cur_io_config_ptr->signal)
	 {
		   case PIN_SIG_DIGITAL:
		  	 switch(cur_io_config_ptr->dir)
		     {
			  	  case IO_DIR_INPUT:
							  switch(cur_io_config_ptr->state)
			  				{
								   case STATE_LOW:
									 case STATE_HIGH: 
				  	  			 if(cur_io_config_ptr->func_type == IO_FUNC_TYPE_GPIO_SW && ((ret_status = SW_Ch_Config(cur_io_config_ptr->io_ch, cur_io_config_ptr->port_pin_len, cur_io_config_ptr->state)) != SUCCESS))
					  				 {
										     error_flag = ERR_SW_CH_GPIO_FUNC_SET;
											   ret_status = error_flag;
											   goto GPIO_INIT_EXIT;											   
							  		 } 
								   break;
									 default:
									 if(cur_io_config_ptr->func_type == IO_FUNC_TYPE_GPIO_SW)
									 {
									     error_flag = ERR_GPIO_INPUT_FUNC_STATE;
                                         ret_status = error_flag;
							             goto GPIO_INIT_EXIT;
								  	 }
							     break;																	
								 }
                 for(i = 0; i < cur_io_config_ptr->port_pin_len ; ++i)
							   {
								    *io_port_dir_ptr[port] |= (IO_DIR_INPUT << (start_port_pin + i));
							   }
              break;		
							case IO_DIR_OUTPUT:
								if(cur_io_config_ptr->func_type == IO_FUNC_TYPE_GPIO_SW)
								{
									  error_flag = ERR_GPIO_OUTPUT_FUNC_STATE;
                    ret_status = error_flag;
							      goto GPIO_INIT_EXIT; 
								}
								switch(cur_io_config_ptr->state)
								{
									  case STATE_LOW:
											for(i = 0; i < cur_io_config_ptr->port_pin_len; ++i)
									  	{
												*io_port_clr_ptr[port] = 1 << (start_port_pin + i);
											}
										break;
							  		case STATE_HIGH:
											for(i = 0; i < cur_io_config_ptr->port_pin_len; ++i)
									  	{
								  			*io_port_set_ptr[port] = 1 << (start_port_pin + i);
											}
										break;
                    default:
					              error_flag = ERR_GPIO_OUTPUT_DATA;
                        ret_status = error_flag;
							          goto GPIO_INIT_EXIT;							     																	
								}
								for(i = 0; i < cur_io_config_ptr->port_pin_len ; ++i)
							  {
								    *io_port_dir_ptr[port] |= (IO_DIR_OUTPUT << (start_port_pin + i));
							  }
				        break;													
					 }
					 break;
					 default: 
					   error_flag = ERR_PIN_SIGNAL;
               ret_status = error_flag;
					     goto GPIO_INIT_EXIT;
					  	// break;										 
		 }		
	  switch(port)
		{			 
		        case	PORT_CH_00:
					    for(i = 0; i < cur_io_config_ptr->port_pin_len; ++i)
						  {
							    	cur_port_pin = start_port_pin + i;
								    cur_pin_sel = cur_port_pin / PIN_16;
							    	cur_pin_sel_bit = cur_port_pin % PIN_16;
						    	 *io_port_func_ptr[cur_pin_sel] |= (IO_FUNC_MODE_00 << ( cur_pin_sel_bit * 2));
						  }
						break;
					  case PORT_CH_01:
							end_port_pin = start_port_pin + cur_io_config_ptr->port_pin_len - 1;						  
						  if(start_port_pin >= PIN_16 && start_port_pin <= PIN_25)
							{								
						     if(end_port_pin >= PIN_16 && end_port_pin <= PIN_25)
							   {
  						      *io_port_func_ptr[2] |= (IO_FUNC_MODE_00 << 3);
									  break; 
							   }
								 else
								 {
								   if(end_port_pin >= PIN_26 && end_port_pin <= PIN_31)
						       {
									    *io_port_func_ptr[2] |= (IO_FUNC_MODE_00 << 3);
									    *io_port_func_ptr[2] |= (IO_FUNC_MODE_00 << 2); 
                      break;									 
						       }
							   }
							}
							else
							{
								 if(start_port_pin >= PIN_26 && start_port_pin <= PIN_31)
							   {								
						         if(end_port_pin <= PIN_31)
						         {
								     	  *io_port_func_ptr[2] |= (IO_FUNC_MODE_00 << 2);	
                        break;											 
						         }
						      }
							}
						  // invalid port 1 pin [0,15] or [32, +infinity ] 
						  error_flag = ERR_PORT1_IO_PIN;
						  ret_status = error_flag;
						  goto GPIO_INIT_EXIT;
			      //  break;
            default:
			   error_flag = ERR_GPIO_CH_SET_PORT;
              ret_status = error_flag;
						break;
			}	
            
	 GPIO_INIT_EXIT: 
      return ret_status; 								 
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Ch_Validate 

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.07  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Ch_Validate(const uint8_t io_ch, const uint8_t bit_len)
{
	  uint8_t port, port_pin, ret_status = SUCCESS, end_port_pin ;
	
	  if(bit_len <= 0 || bit_len > NUM_PINS_PER_PORT)
		{
			 error_flag = ERR_IO_PIN_RANGE;
			 return error_flag;
		}			
	  port  = io_ch / NUM_PINS_PER_PORT;
	  port_pin = io_ch % NUM_PINS_PER_PORT; 
	  end_port_pin = port_pin + bit_len - 1;
	  if(port_pin >= NUM_PINS_PER_PORT || end_port_pin >= NUM_PINS_PER_PORT)
	  {
		  error_flag = ERR_IO_PIN_RANGE;
			return error_flag;
	  }
	  switch(port)
	  {
			  case PORT_CH_00:
					if( (port_pin <= PIN_24 && end_port_pin >= PIN_24))
					{
					  	// PORT0's pin 24 is reserved
						  error_flag = ERR_IO_CH_24_PIN;
						  ret_status = error_flag;
					}
					
        break;
				case PORT_CH_01:
					if(port_pin <= PIN_15 || end_port_pin <= PIN_15)
					{
						// port1's pin [0,15] are reserved
						 error_flag = ERR_IO_CH_32_TO_47;
						 ret_status = error_flag;
					}
					
        break;
        default:
		    error_flag = ERR_INVALID_PORT;
					ret_status = error_flag;
				break;
		}					
		return ret_status; 
}


/*------------------------------------------------------------*
FUNCTION NAME  : Debug_IO_Func_Set_Validate

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.08  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Debug_IO_Func_Set_Validate(const io_config_t *const cur_io_config_ptr)
{	   	 	
	  if(cur_io_config_ptr->port_pin_len != (PIN_31 - PIN_26 + 1))
		{
			 error_flag = ERR_CONFIG_DEBUG_FUNC_SET;
			 return error_flag;			  
		}
		return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Trace_IO_Func_Set_Validate

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.09  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Trace_IO_Func_Set_Validate(const io_config_t *const cur_io_config_ptr)
{
	  if(cur_io_config_ptr->port_pin_len != (PIN_25 - PIN_16 + 1))
		{
			 error_flag = ERR_CONFIG_TRACE_FUNC_SET;
			 return error_flag;			  
		}
		return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : IO_Conf_Index_To_IO_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.10  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t IO_Conf_Index_To_IO_Ch(uint8_t *const io_ch, const uint8_t io_config_index)
{
	    uint8_t ret_status = SUCCESS;
	
	    if(io_ch == NULL_PTR)
			{
				error_flag = ERR_CONF_INDEX_IO_CH_NULL_PTR;
				  return error_flag;
			}
	    if(io_config_index <= IO_CH_31)
		  {
			   *io_ch = io_config_index;
		  }
		  else
		  {
			 //io_config_index  = [32, 47] map io_ch = [48, 63] as in lpc2138 port 1 pin[0,15] are reserved
	   	  if(io_config_index < IO_CH_48)
		    {
		        *io_ch = io_config_index + 16;
		    }
				else
				{
					 ret_status = ERR_IO_CONFIG_TABLE_LARGE;					
				}
		  }
			return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Port_To_IO_Config_Index

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.11  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Port_To_IO_Config_Index( uint8_t *const io_config_index, const io_port_t *const io_port_ptr)
{
	    uint8_t ret_status = SUCCESS;
	
	    if(io_config_index == NULL_PTR || io_port_ptr == NULL_PTR)
			{
				error_flag = ERR_PORT_TO_IO_CONF_NULL_PTR;
				  return error_flag;
			}
			switch(io_port_ptr->port)
			{
				  case PORT_CH_00:
						 *io_config_index = NUM_PINS_PER_PORT * io_port_ptr->port +  io_port_ptr->port_pin;
					break;
					case PORT_CH_01:
						 *io_config_index = NUM_PINS_PER_PORT * io_port_ptr->port +  io_port_ptr->port_pin - 16;
					break;
          default:
		     error_flag = ERR_PORT_INVALID;
             ret_status = error_flag;						
			}
	   	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Ch_To_SW_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.12  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Ch_To_SW_Ch(const uint8_t io_ch, uint8_t *const sw_ch_ptr )
{
	    uint8_t ret_status = FAILURE, i;
	
	    if(sw_ch_ptr == NULL_PTR || ((ret_status = IO_Ch_Validate(io_ch, 1)) != SUCCESS))
      {
		    error_flag = ERR_IO_CH_TO_SW_CH;
		    return error_flag; 
	    }
	    for(i = 0; i < NUM_INPUT_DEV_ID_SW_CHS; ++i)
	    {
				  if(sw_para[i].io_ch == io_ch)
					{
						 ret_status = SUCCESS;
						 *sw_ch_ptr = i;
						 break;
					}
			}
			if(i >= NUM_INPUT_DEV_ID_SW_CHS)
			{
		    	error_flag = ERR_SW_CH_NOT_MATCH_IO_CH ;
				ret_status = error_flag;
			}
			return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_Config

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.13  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_Config(const uint8_t io_ch, const uint8_t port_pin_len, const uint8_t sw_pressed_data)
{
	uint8_t i ;
	
	if(sw_ch_index + port_pin_len > NUM_INPUT_DEV_ID_SW_CHS)
	{
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	}
  for(i = 0 ; i < port_pin_len; ++i, ++sw_ch_index )	
	{
   	sw_para[sw_ch_index].io_ch = io_ch + i;
  	sw_para[sw_ch_index].sw_enable = STATE_NO;
  	sw_para[sw_ch_index].sw_cur_state = STATE_KEY_RELEASED;
  	sw_para[sw_ch_index].sw_pressed_state = sw_pressed_data & 0x01;
	}	
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_SW_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.14  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Reset_SW_Ch(const uint8_t sw_ch_index)
{
	 if(sw_ch_index >= NUM_INPUT_DEV_ID_SW_CHS) 
	 {
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	 }		 
   sw_para[sw_ch_index].io_ch = IO_CH_INVALID;
   sw_para[sw_ch_index].sw_enable = STATE_NO;
	 sw_para[sw_ch_index].sw_cur_state = STATE_KEY_RELEASED;
	 sw_para[sw_ch_index].sw_pressed_state = STATE_LOW;
   
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_SW_Chs

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.15  

BUGS           :              
-*------------------------------------------------------------*/
void Reset_SW_Chs(void)
{
	uint8_t i;
	
	for (i = 0 ; i < NUM_INPUT_DEV_ID_SW_CHS; ++i)
	{
	  	Reset_SW_Ch(i);
	}
	sw_ch_index = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_Read

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.16  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_Read(const uint8_t io_ch, uint8_t *const sw_ch_index_ptr )
{
	 uint8_t ret_status = SUCCESS, read_data;
	
	 if((ret_status = IO_Channel_Read(io_ch, &read_data )) != SUCCESS)
	 {
		   return ret_status;
	 }
	 if((ret_status = IO_Ch_To_SW_Ch(io_ch, sw_ch_index_ptr )) != SUCCESS)
	 {
		   return ret_status;
	 }
	 sw_para[*sw_ch_index_ptr].sw_read_data = read_data & 0x01;
	 return ret_status; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : Reset_IO_Chs

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.17  

BUGS           :              
-*------------------------------------------------------------*/
void Reset_IO_Chs(void)
{
     Reset_Ports();
	 Reset_SW_Chs();
}

/*------------------------------------------------------------*
FUNCTION NAME  : Config_Port_Pin_Range_Validate

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.18  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Config_Port_Pin_Range_Validate(const io_config_t *const cur_io_config_ptr )
{
	 consucc_bit_t set_port_pins;
	 uint8_t ret_status = SUCCESS, port, port_pin;
	 
	if((ret_status = IO_Ch_Validate(cur_io_config_ptr->io_ch, cur_io_config_ptr->port_pin_len )) != SUCCESS)
	{
		error_flag = ERR_IO_PIN_RANGE;
		return error_flag;
	}
	port = cur_io_config_ptr->io_ch / NUM_PINS_PER_PORT;
	port_pin = cur_io_config_ptr->io_ch % NUM_PINS_PER_PORT;
	set_port_pins. start_bit_pos = port_pin;
	set_port_pins.bits_len = cur_io_config_ptr->port_pin_len;
	set_port_pins.consucc_val = 0;
	if((ret_status = Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &set_port_pins)) != SUCCESS)
	{
		return ret_status;
	}
	if((config_port_pin[port] & set_port_pins.consucc_val) != 0)
	{
		error_flag = ERR_CONFIG_PIN_RANGE;
		return error_flag;
	}
	config_port_pin[port] |= set_port_pins.consucc_val;
	return ret_status; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Sw_Pressed_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.19  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Pressed_Proc(const uint8_t io_ch_sw)
{
	 sw_para_t *sw_para_ptr;	
     uint8_t ret_status = ERR_SW_NOT_PRESSED, sw_ch_index;
	 
	if((ret_status = IO_Ch_To_SW_Ch(io_ch_sw, &sw_ch_index)) != SUCCESS)
	{
		   return ret_status;
	}
	sw_para_ptr = sw_para + sw_ch_index;
	
	if(sw_para_ptr->sw_enable != STATE_YES)
	{
		 error_flag = ERR_SW_NO_ACCESS;
		 return error_flag;				  
	}
	   
			  if((ret_status = SW_Ch_Read_By_SW_Index(sw_ch_index )) != SUCCESS)
			   {
				     ret_status = ERR_SW_NO_READ; 				     
					 return ret_status;
			   }
		     if(sw_para_ptr->sw_cur_state == STATE_KEY_RELEASED  && (sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state))
			  {
				      SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY); 
			          if(((ret_status = SW_Ch_Read_By_SW_Index(sw_ch_index )) != SUCCESS))
					  {
						    ret_status = ERR_SW_NO_READ; 	
							return ret_status;		  
					  }
					  if( sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state)
		              { 
			               sw_para_ptr->sw_cur_state = STATE_KEY_PRESSED;
						   do
					       {
							  if((ret_status = SW_Ch_Read_By_SW_Index(sw_ch_index )) != SUCCESS)
							  {
								    ret_status = ERR_SW_NO_READ; 	
									return ret_status;    
							  }												 
												 
						  } while( sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state);
					  }  
					  SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
					  if((ret_status = SW_Ch_Read_By_SW_Index(sw_ch_index )) != SUCCESS)
					  {
					    	ret_status = ERR_SW_NO_READ; 	
							return ret_status; 
					  }
					  if(sw_para_ptr->sw_read_data != sw_para_ptr->sw_pressed_state)
					  {
						  sw_para_ptr->sw_cur_state = STATE_KEY_RELEASED;		
						  return SUCCESS;
			          }				 
			     } 	
		return ERR_SW_NOT_PRESSED;   
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_Read_By_SW_Index

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.20  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_Read_By_SW_Index(const uint8_t sw_ch_index)
{
	uint8_t read_data, ret_status = SUCCESS;
	
	if(sw_ch_index >= NUM_INPUT_DEV_ID_SW_CHS)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}
	if((ret_status = IO_Channel_Read(sw_para[sw_ch_index].io_ch, &read_data )) != SUCCESS)
	{
		   return ret_status;
	}
	sw_para[sw_ch_index].sw_read_data = read_data & 0x01;
	return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Port_Read

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.02  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Port_Read(const uint8_t io_channel, void *const data_ptr)
{
	 consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr, consucc_bits_1;
	 uint8_t port, port_pin, ret_status = SUCCESS, end_port_pin;
 	 
	 end_port_pin = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	 port = io_channel / NUM_PINS_PER_PORT;
	 port_pin = io_channel % NUM_PINS_PER_PORT;	
	 if(consucc_bit_ptr == NULL_PTR || consucc_bit_ptr->start_bit_pos != port_pin || consucc_bit_ptr->bits_len <= 0 || end_port_pin >= NUM_PINS_PER_PORT )
	 {
		 error_flag = ERR_READ_PORT_VAL;
		   return error_flag;
	 } 
	 if((ret_status = IO_Ch_Validate(io_channel, consucc_bit_ptr->bits_len)) != SUCCESS)
	 {
	     error_flag = ERR_READ_PORT_VAL;
	     return error_flag;
	 }
	 consucc_bits_1.start_bit_pos = consucc_bit_ptr->start_bit_pos;
	 consucc_bits_1.bits_len = consucc_bit_ptr->bits_len;
	 consucc_bits_1.consucc_val = 0;
     if((ret_status = Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &consucc_bits_1)) != SUCCESS )
	 {
		 error_flag = ERR_CONFIG_PORT_INIT_VAL;
		 return error_flag;
	 }
	 consucc_bit_ptr->consucc_val = ( *io_port_ptr[port] & consucc_bits_1.consucc_val ) >> consucc_bit_ptr->start_bit_pos;
	 return ret_status;
}	
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
