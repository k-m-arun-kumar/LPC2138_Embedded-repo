/**************************************************************************
   FILE          :    keyboard.c
 
   PURPOSE       :     
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 04  
	   
 **************************************************************************/
  
 #include "main.h" 
 
 #ifdef KEYPAD_MOD_ENABLE
 #include "keyboard.h" 
 #include "appl_conf.h"
 #include <string.h>

 
/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
keyboard_data_t keyboard_status[NUM_INPUT_DEV_ID_KEYBOARD_CHS];
static char cur_pressed_key_or_sw;	
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t KeyBoard_Col_Scan(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr, const uint8_t data_id, const uint8_t select_row );

/* ----------------------------- function pointer defination -------------------- */

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.                 

Func ID        : 04.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t Keyboard_Proc(const uint8_t keyboard_ch_id, const uint8_t data_id)
{
	   data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	   keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
     consucc_bit_t mask_dev_ch_id;
	   
	   uint8_t ret_status = SUCCESS, error_status_flag = STATE_NO, dev_src_arr_index, dev_src_arr_bit, dev_ch_id;
	 
	   if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS || data_id >= NUM_DATA_IDS)
		 {
			   error_flag = ERR_DEV_CH_ID_OR_DATA_ID_INVALID;
			   return error_flag;
		 }
		#ifdef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
		 dev_src_arr_index =  INPUT_DEV_ID_KEYBOARD/ (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
		 dev_src_arr_bit = ((((INPUT_DEV_ID_KEYBOARD * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
		 mask_dev_ch_id.bits_len = DEV_CH_ID_BIT_SIZE;
		 mask_dev_ch_id.consucc_val = 0;
		 mask_dev_ch_id.start_bit_pos = 0;
		 Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &mask_dev_ch_id);
		 cur_data_id_status_para_ptr = data_id_status_para + data_id;
		 dev_ch_id = cur_data_id_status_para_ptr->data_input_devs_conf[dev_src_arr_index] >> (dev_src_arr_bit + 1) & mask_dev_ch_id.consucc_val;
		 if( Test_Bit_Is_Clear_in_Data(&cur_data_id_status_para_ptr->data_input_devs_conf[dev_src_arr_index], dev_src_arr_bit) || dev_ch_id != keyboard_ch_id) 
	   {  
          error_flag = ERR_DEV_CH_ID_NO_ACCESS;	
          return  error_flag;
	   } 
	   #endif
     cur_data_id_status_para_ptr = data_id_status_para + data_id;
     cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
	 #ifndef DATA_MANY_DEVS_ONLY_ONE_TYPE_DEV_SRC
       if(  cur_keyboard_ctrl_ptr->access_flag != STATE_YES) 
	   {  
          error_flag = ERR_DEV_CH_ID_NO_ACCESS;	
          return  error_flag;
	   }
	   #endif
	   if( cur_keyboard_ctrl_ptr->enable_flag != STATE_YES) 
	   {  
          error_flag = ERR_KEYPAD_DISABLED;	
          return  error_flag;
	   }		  
          switch( cur_data_id_status_para_ptr->data_input_mode) 
	      {
			 //enter data till enter key is pressed
		     case DATA_ID_INPUT_MODE_TILL_TERMINATOR:
	           if(cur_data_id_status_para_ptr->data_str_len >= KEYPAD_CONF_MAX_NUM_CHARS_ENTERED)
	           {
		           cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_YES;
               cur_data_id_status_para_ptr->valid_input_terminator_flag = STATE_NO; 
			       return KEYPAD_REACH_MAX_CHARS_WAIT_TERMINATOR_KEY;
		       }
		     break;
			 //enter data till max nums of chars is reached
             case DATA_ID_INPUT_MODE_TILL_ALLOC:	
         		if(cur_data_id_status_para_ptr->max_allocated_data_len > KEYPAD_CONF_MAX_NUM_CHARS_ENTERED ) 
		        {
						  	error_flag = ERR_KEYPAD_EXCEEDS_CHARS;
				        return error_flag;
						}
			       if(cur_data_id_status_para_ptr->data_str_len + 1 >= cur_data_id_status_para_ptr->max_allocated_data_len)
			       {
				               cur_data_id_status_para_ptr->data_str[cur_data_id_status_para_ptr->data_str_len]= NULL_CHAR;	
                       cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_YES;
                       cur_data_id_status_para_ptr->valid_input_terminator_flag = STATE_NO; 
                       return KEYPAD_DATA_READY; 							 
			       }				
		     break;
		  }
	   		  
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  STATE_LOW)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	         
             goto KEYPAD_ROW_INVALID_WRITE;
		}		
	    if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  STATE_HIGH)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	
             goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  STATE_HIGH)) != SUCCESS)
		{	
	         error_status_flag = ERR_KEYPAD_ROW_WRITE;	
             goto KEYPAD_ROW_INVALID_WRITE; 
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  STATE_HIGH)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;
		}
        ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, data_id, KEYPAD_ROWA_SELECT);
		switch(ret_status)
		{
		  case KEYPAD_DATA_READY:
			case KEYPAD_PRESSED_KEY_DETECT:
				return ret_status;
			//break;	
			case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			case ERR_SW_NOT_PRESSED:
			break;	
			default:
			  return ERR_KEYBOARD_PROC;
		} 
		
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  STATE_HIGH)) != SUCCESS)
		{	
              error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  STATE_LOW)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;     			
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  STATE_HIGH)) != SUCCESS)
		{		
              error_status_flag = ERR_KEYPAD_ROW_WRITE;	     	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, data_id, KEYPAD_ROWB_SELECT);
		switch(ret_status)
		{
		  	case KEYPAD_DATA_READY:
			  case KEYPAD_PRESSED_KEY_DETECT:
			   	return ret_status;
			    //break;	
		  	case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			  case ERR_SW_NOT_PRESSED:
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		} 
		
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  STATE_HIGH)) != SUCCESS)
		{		
             error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			 goto KEYPAD_ROW_INVALID_WRITE; 
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  STATE_LOW)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  STATE_HIGH)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr,data_id, KEYPAD_ROWC_SELECT);
		switch(ret_status)
		{
		    case KEYPAD_DATA_READY:
			  case KEYPAD_PRESSED_KEY_DETECT:
			   	return ret_status;
			    //break;	
		  	case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			  case ERR_SW_NOT_PRESSED:
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		} 
		          
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa,  STATE_HIGH)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 1,  STATE_HIGH)) != SUCCESS)
		{						 
			 error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
        if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 2,  STATE_HIGH)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
		if((ret_status = IO_Channel_Write(cur_keyboard_ctrl_ptr->io_ch_rowa + 3,  STATE_LOW)) != SUCCESS)
		{						 
			  error_status_flag = ERR_KEYPAD_ROW_WRITE;	
			  goto KEYPAD_ROW_INVALID_WRITE;
		}
		ret_status = KeyBoard_Col_Scan(cur_keyboard_ctrl_ptr, data_id, KEYPAD_ROWD_SELECT); 
		switch(ret_status)
		{
		    case KEYPAD_DATA_READY:
			  case KEYPAD_PRESSED_KEY_DETECT:			   
		  	case ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED:			
			  case ERR_SW_NOT_PRESSED:
		  	break;	
		  	default:
			    return ERR_KEYBOARD_PROC;
		}
KEYPAD_ROW_INVALID_WRITE: 
   switch(error_status_flag)
   {
	   case ERR_KEYPAD_ROW_WRITE:
         error_flag = ERR_KEYBOARD_PROC;	
         ret_status = error_flag;
		     Disable_Keyboard(keyboard_ch_id);
	   break;	 
   }
   return ret_status;	 
}

/*------------------------------------------------------------*
FUNCTION NAME  : KeyBoard_Col_Scan

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : long key press and no key press timeout is not implemented.
                 halt CPU process by using while(KEY == KEY_PRESSED); ie till key is released is not used
                 
Func ID        : 04.02  

BUGS           :     
-*------------------------------------------------------------*/
static uint8_t KeyBoard_Col_Scan(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr, const uint8_t data_id, const uint8_t select_row )
{
	data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	uint8_t ret_status = SUCCESS, key_pressed_flag = STATE_NO;
	char keypad_char[]   = {'1','2', '3', '4', '5', '6','7','8','9','*', '0', '#'};
	
	if(cur_keyboard_ctrl_ptr->keypad_keys_enable_flag != STATE_YES)
	{
		  error_flag = ERR_KEYPAD_DISABLED;	
      return  error_flag;
	}
	cur_data_id_status_para_ptr = data_id_status_para + data_id;
	if(cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag == STATE_YES ||cur_data_id_status_para_ptr->valid_input_terminator_flag  == STATE_YES)
	{
		  return KEYPAD_DATA_READY;
	}
	if((ret_status = SW_Pressed_Proc(cur_keyboard_ctrl_ptr->io_ch_col1)) == SUCCESS)
	{
		switch(select_row)
	   {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[0]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[3]; //latest pressed key/switch
			     key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[6]; //latest pressed key/switch
			     key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWD_SELECT:
             if(data_ids_ctrl_para[data_id].data_input_can_also_nonnum_key ==  STATE_YES )		
		         {													
		           cur_pressed_key_or_sw = keypad_char[9]; //latest pressed key/switch
				       key_pressed_flag = STATE_YES;
			       break;
		        }
                return ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED;   			 	
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		}
    goto KEY_PRESSED_PROC;		 
	}
    if((ret_status = SW_Pressed_Proc(cur_keyboard_ctrl_ptr->io_ch_col1 + 1)) == SUCCESS)
  	{
		switch(select_row)
	    {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[1]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[4]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[7]; //latest pressed key/switch
			     key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWD_SELECT:
               cur_pressed_key_or_sw = keypad_char[10]; //latest pressed key/switch
			       key_pressed_flag = STATE_YES;
          break;					
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
		} 
    goto KEY_PRESSED_PROC;				
	}
   if((ret_status = SW_Pressed_Proc(cur_keyboard_ctrl_ptr->io_ch_col1 + 2)) == SUCCESS)
	{
		switch(select_row)
	    {
	        case KEYPAD_ROWA_SELECT:
		       cur_pressed_key_or_sw = keypad_char[2]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWB_SELECT: 
		       cur_pressed_key_or_sw = keypad_char[5]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWC_SELECT:
		       cur_pressed_key_or_sw = keypad_char[8]; //latest pressed key/switch
			   key_pressed_flag = STATE_YES;
	        break;
	        case KEYPAD_ROWD_SELECT:
            if(data_ids_ctrl_para[data_id].data_input_can_also_nonnum_key  ==  STATE_YES )		
		        {													
		           cur_pressed_key_or_sw = keypad_char[11]; //latest pressed key/switch
				       key_pressed_flag = STATE_YES;
			       break;
		        }
                return ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED;   			 	
	        default:
               error_flag = ERR_KEYPAD_INVALID_ROW;										
            return error_flag;
			} 
	}
	KEY_PRESSED_PROC:
   if(key_pressed_flag == STATE_YES)
   {
		  if(( ret_status = Entered_Key_No_Long_Press_Proc(cur_keyboard_ctrl_ptr, data_id, cur_pressed_key_or_sw)) != SUCCESS)
	    {
	        return ret_status;
	    } 		
	   return KEYPAD_PRESSED_KEY_DETECT;
   }
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Entered_Key_No_Long_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : make sure that entered key is within max available lcd loc and line, currently cur_data_conf_parameter.cur_data_allocated_max_num_chars_to_rcv 
	 sures that entered key is within max available lcd loc and within max line 

Func ID        : 04.03

BUGS           :   
-*------------------------------------------------------------*/
uint8_t Entered_Key_No_Long_Press_Proc(keyboard_ctrl_t *const cur_keyboard_ctrl_ptr, const uint8_t data_id, const char cur_key_char)
{	
	 data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
   uint8_t ret_status = SUCCESS;   
   cur_data_id_status_para_ptr = data_id_status_para + data_id;
	
   cur_data_id_status_para_ptr->data_str[cur_data_id_status_para_ptr->data_str_len] = cur_key_char;   
   ++cur_data_id_status_para_ptr->data_str_len;   	
   return ret_status; 	  
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_Keyboard

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.04  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_Keyboard(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
	
	 if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;  
   cur_keyboard_ctrl_ptr->enable_flag = STATE_NO;
	 cur_keyboard_ctrl_ptr->keypad_keys_enable_flag = STATE_NO;	
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Enable_Keyboard

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.05  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Enable_Keyboard(const uint8_t keyboard_ch_id)
{
	 sw_para_t *sw_para_ptr = NULL_PTR;
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
	 uint8_t sw_ch_index, ret_status = SUCCESS;	
   
	if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	{
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	}
	cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
  if((ret_status = IO_Ch_To_SW_Ch(cur_keyboard_ctrl_ptr->io_ch_col1, &sw_ch_index )) != SUCCESS)
	{
		   return ret_status;
	}
	sw_para_ptr = sw_para + sw_ch_index;
  sw_para_ptr->sw_enable = STATE_YES;	
	if((ret_status = IO_Ch_To_SW_Ch(cur_keyboard_ctrl_ptr->io_ch_col1 + 1, &sw_ch_index )) != SUCCESS)
	{
		   return ret_status;
	}
	sw_para_ptr = sw_para + sw_ch_index; 
 	sw_para_ptr->sw_enable = STATE_YES;	
	if((ret_status = IO_Ch_To_SW_Ch(cur_keyboard_ctrl_ptr->io_ch_col1 + 2, &sw_ch_index )) != SUCCESS)
	{
		   return ret_status;
	}
	 sw_para_ptr = sw_para + sw_ch_index;   
   sw_para_ptr->sw_enable = STATE_YES;	
	 cur_keyboard_ctrl_ptr->keypad_keys_enable_flag = STATE_YES;	
   cur_keyboard_ctrl_ptr->enable_flag = STATE_YES;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_Keyboards

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.06  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_Keyboards(void)
{
	 uint8_t keyboard_ch_id =0;
	
	 for(keyboard_ch_id = 0; keyboard_ch_id < NUM_INPUT_DEV_ID_KEYBOARD_CHS; ++keyboard_ch_id)
	 {
		   Disable_Keyboard(keyboard_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.07  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_Allow_Access(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
  
   if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	  cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
    cur_keyboard_ctrl_ptr->access_flag = STATE_YES;
	 return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.07  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Keyboard_No_Access(const uint8_t keyboard_ch_id)
{
	 keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
  
   if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	  cur_keyboard_ctrl_ptr = keyboard_ctrl + keyboard_ch_id;
    cur_keyboard_ctrl_ptr->access_flag = STATE_NO;
    Disable_Keyboard(keyboard_ch_id);
	 return SUCCESS;
}
 
#endif
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
