/* ********************************************************************
FILE                   : appl.c

PURPOSE                :  Application 
	 
AUTHOR                : K.M.Arun Kumar
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 11

*****************************************************************************/
#include "main.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */ 
uint32_t appl_status_flag = NO_ERROR;
			
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.02

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Appl_Proc(void)
{	
     uint16_t ret_status;
    	
	switch(cur_data_id) 
	{	
	    case DATA_ID_ADC: 
         		
		break;
        default:
		   appl_status_flag = ERR_CUR_DATA_ID_INVALID;
		   Error_or_Warning_Proc("11.02.02", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;
	 } 
     return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_Init(const void *const data_ptr)
{	
    uint16_t ret_status;	
		
	if((ret_status =  Next_Data_Conf_Parameter(DATA_ID_ADC)) != SUCCESS)
	{
		 appl_status_flag = ERR_NEXT_DATA_CONF;
		 Error_or_Warning_Proc("11.03.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
    if((ret_status = LCD_Enable(CH_ID_00)) != SUCCESS)
	{
		appl_status_flag = ERR_DEV_ENABLE_PROC;
		Error_or_Warning_Proc("11.03.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}		
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW in order from SW_CH_ID from 0 if any, then initialize Keyboard, if any.

Func ID        : 11.04  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_HW_Init(void)
{
    uint16_t ret_status ;
		
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_TRANSMIT_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, COMM_RECEIVE_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = UART_Init(TRACE_UART_CH_ID, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = Output_Dev_Init(INTERNAL_ERROR_LED_IO_CH, 1)) != SUCCESS)
	{
		return FAILURE;
	}
	if((ret_status = LCD_Init(CH_ID_00, DATA_NA)) != SUCCESS)
	{
		return FAILURE;
	}
	#ifdef TRACE_FLOW
	   Print("TRA: HW Init over\r");
	#endif
	return SUCCESS; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	uint16_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:	
           appl_status_flag = NO_ERROR;	
		   Appl_Reset_Proc(DATA_NA);
		break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.04", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;
	}
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.11

BUGS           :    
-*------------------------------------------------------------*/ 
uint16_t Appl_Reset_Proc(const uint8_t reset_data)
{
	uint16_t ret_status;	
	
	return SUCCESS;
}	

#ifdef TIMER_MOD_ENABLE 
/*------------------------------------------------------------*
FUNCTION NAME  : Timer_0_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.05  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_0_Timeout_Proc(const uint16_t timeout_type, volatile const timer_or_counter_data_t *const timer_0_or_counter_data_ptr)
{
	uint16_t ret_status;
	
	if(timer_0_or_counter_data_ptr == NULL_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("11.05.01", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	if(timer_0_or_counter_data_ptr->timer_or_counter_run_id != TMR_OR_COUNTER_SYSTEM_TICK_STATE)
	{
		appl_status_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.05.02", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
    /* --------------------------------------- User Code: Begin ------------------------------------------ */ 
	
	/* --------------------------------------- User Code: End   ------------------------------------------ */ 
	switch(timeout_type)
	{
		 case TMR_NO_MAX_NUM_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_NO_MAX_NUM_TIMEOUT_PROC;
	     break;		
		 case TMR_AT_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_AT_LAST_TIMEOUT_PROC;
		 break;  
		 case TMR_BEFORE_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_BEFORE_LAST_TIMEOUT_PROC;
		 break;
         case TMR_MAX_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_MAX_NUM_TIMEOUT_PROC; 
         break;		
         default:
             appl_status_flag = ERR_TMR_TIMEOUT_TYPE_INVALID;
		     Error_or_Warning_Proc("11.05.03", ERROR_OCCURED, appl_status_flag);
		     return appl_status_flag;
	}
    return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Timer_1_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.06  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_1_Timeout_Proc(const uint16_t timeout_type, volatile const timer_or_counter_data_t *const timer_1_or_counter_data_ptr)
{
	 elevator_ctrl_and_status_t *cur_elevator_ptr;
     uint16_t ret_status;
    
    if(timer_1_or_counter_data_ptr == NULL_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("11.06.01", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	if(timer_1_or_counter_data_ptr->timer_or_counter_run_id >= NUM_TIMER_AND_COUNTER_IDS)
	{
		appl_status_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.06.02", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	/* --------------------------------------- User Code: Begin ------------------------------------------ */ 
	
		
	/* --------------------------------------- User Code: End   ------------------------------------------ */ 
	
	 switch(timeout_type)
	 {
		 case TMR_NO_MAX_NUM_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_NO_MAX_NUM_TIMEOUT_PROC;
	     break;		
		 case TMR_AT_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_AT_LAST_TIMEOUT_PROC;
		 break;  
		 case TMR_BEFORE_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_BEFORE_LAST_TIMEOUT_PROC;
		 break;
         case TMR_MAX_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_MAX_NUM_TIMEOUT_PROC; 
         break;		 
         default:
		     appl_status_flag = ERR_TMR_TIMEOUT_TYPE_INVALID;
		     Error_or_Warning_Proc("11.06.05", ERROR_OCCURED, appl_status_flag);
		     return appl_status_flag;
	 }
    return ret_status;	
}

#endif

#ifdef EXT_INTERRUPT_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_0_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.07  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_0_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_1_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.08  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_1_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_2_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.09  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_2_Proc(void)
{
	uint16_t ret_status;   
	
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_3_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.10  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_3_Proc(void)
{
	uint16_t ret_status;	 
	
	return SUCCESS;
}

#endif

		    
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
