/**************************************************************************
   FILE          :    adc.h
 
   PURPOSE       :    ADC header.  
 
   AUTHOR        :    K.M. Arun Kumar
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _ADC_H
#define _ADC_H
 
/* ---------------------- macro defination ------------------------------------------------ */
#define ADC_MAX_ENCODED_VALUE            (1023UL)
#define ADC_MAX_LIMIT_VALUE              (1024UL)
#define ADC_ENCODED_VALUE_NA             (1025UL)
#define MAX_ADC_SUB_CHS                 (CH_ID_08)
#define ADC_SUB_CH_ID_NA                (MAX_ADC_SUB_CHS + 1) 

/* ---------------------- data type defination -------------------------------------------- */
typedef struct 
{ 
   uint8_t sel_sub_chs;
   uint8_t sel_sub_chs_interrupt;
   uint8_t adc_sel_interrupt_flag       : 1;  
   uint8_t num_result_bits_mode         : 3;
    uint8_t start_mode                  : 3;
   uint8_t start_conv_falling_edge      : 1;   
   uint8_t burst_mode                   : 1;
   uint8_t                              : 7;  
} adc_ctrl_t;

typedef struct
{
  uint16_t conv_result           : 11;
  uint16_t adc_sub_ch_id         : 4;
  uint16_t over_run_flag         : 1;
  uint16_t done_flag             : 1;
  uint8_t sel_sub_chs_polling;
  uint8_t done_interrupt_flag    : 1;
  uint8_t init_proc_flag         : 1;
  uint8_t first_for_conv_flag    : 1;
  uint8_t adc_run_status         : 3;
  uint8_t                        : 2;
  
} adc_status_t;
  
typedef enum
{
	RESET_ADC_WHOLE_STATUS, RESET_ADC_CONV_STATUS
} adc_status_reset_t;	

typedef enum
{
	ADC_START_CONV, ADC_NO_START_CONV, ADC_POWER_DOWN, ADC_EDGE_CAPTURE_START_CONV, ADC_EDGE_TIMER_MATCH_START_CONV
} adc_run_status_t;

/* -------------------- public variable declaration --------------------------------------- */
extern adc_ctrl_t adc_ctrl[NUM_INPUT_DEV_ID_ADC_CHS];
extern adc_status_t adc_status[NUM_INPUT_DEV_ID_ADC_CHS];

/* -------------------- public function declaration --------------------------------------- */
uint16_t ADC_Status(const uint8_t adc_master_ch_id, const uint8_t adc_sub_ch_id);
uint16_t ADC_Init(const uint8_t adc_master_ch_id);
uint16_t Start_ADC_Conv(const uint8_t adc_master_ch_id);
uint16_t Enable_ADC_Interrupt(const uint8_t adc_master_ch_id);   
uint16_t Disable_ADC_Interrupt(const uint8_t adc_master_ch_id);
uint16_t Reset_ADC_Status(const uint8_t adc_master_ch_id, const uint8_t reset_type);
uint16_t ADC_Stop_Conv(const uint8_t adc_master_ch_id);

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
