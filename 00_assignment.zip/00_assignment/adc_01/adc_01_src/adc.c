/* ********************************************************************
FILE                  : adc.c

PURPOSE               : ADC library.  
	 
AUTHOR                : K.M.Arun Kumar
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 14

*****************************************************************************/
#include "main.h"

#ifdef ADC_MOD_ENABLE

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
adc_status_t adc_status[NUM_INPUT_DEV_ID_ADC_CHS];
 
static uint32_t volatile *const adc_cr_ptr[NUM_INPUT_DEV_ID_ADC_CHS] = {(uint32_t *) &AD0CR, (uint32_t *) &AD1CR };
static uint32_t volatile *const adc_gdr_ptr[NUM_INPUT_DEV_ID_ADC_CHS] = {(uint32_t *) &AD0GDR,(uint32_t *) &AD1GDR  };
static uint32_t volatile *const adc_stat_ptr[NUM_INPUT_DEV_ID_ADC_CHS] = {(uint32_t *) &AD0STAT, (uint32_t *) &AD1STAT };
static uint32_t volatile *const adc_inten_ptr[NUM_INPUT_DEV_ID_ADC_CHS] = {(uint32_t *) &AD0INTEN, (uint32_t *) &AD1INTEN };

/* ----------------------------- global variable declaration -------------------- */

/* ----------------------------- global function declaration -------------------- */

 

/*------------------------------------------------------------*
FUNCTION NAME  : ADC_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.01

BUGS           :    
-*------------------------------------------------------------*/
uint16_t ADC_Status(const uint8_t adc_master_ch_id, const uint8_t adc_sub_ch_id)
{
	adc_status_t *cur_adc_status_ptr;
  adc_ctrl_t *cur_adc_ctrl_ptr; 
	
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.01.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	if(adc_sub_ch_id > MAX_ADC_SUB_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.01.02", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	cur_adc_status_ptr = adc_status + adc_master_ch_id;
  cur_adc_ctrl_ptr = adc_ctrl + adc_master_ch_id; 
	if(adc_sub_ch_id == MAX_ADC_SUB_CHS)
	{
		if(*adc_gdr_ptr[adc_master_ch_id] & (1 << 31))
		{
			//conv completed
			cur_adc_status_ptr->first_for_conv_flag = STATE_NO;
			cur_adc_status_ptr->done_flag = STATE_YES;
			cur_adc_status_ptr->adc_sub_ch_id = (*adc_gdr_ptr[adc_master_ch_id] >> 24) & 0x07;
			cur_adc_status_ptr->conv_result = (*adc_gdr_ptr[adc_master_ch_id] >> 6) & 0x03FF;
		}
		else
		{
			cur_adc_status_ptr->done_flag = STATE_NO;
		}
		if(*adc_gdr_ptr[adc_master_ch_id] & (1 << 30))
		{
			cur_adc_status_ptr->over_run_flag = STATE_YES;
		}
		else
		{
			cur_adc_status_ptr->over_run_flag = STATE_NO;
		}
	}
	else
	{
		cur_adc_status_ptr->adc_sub_ch_id = adc_sub_ch_id;
		if(*adc_stat_ptr[adc_master_ch_id] & (1 << adc_sub_ch_id ))
		{
			cur_adc_status_ptr->first_for_conv_flag = STATE_NO;
			cur_adc_status_ptr->done_flag = STATE_YES;
		}
        else
		{
			cur_adc_status_ptr->done_flag = STATE_NO;
		}
        if(*adc_stat_ptr[adc_master_ch_id] & ((1 << adc_sub_ch_id ) + 8))
		{
			cur_adc_status_ptr->over_run_flag = STATE_YES;
		}
        else
		{
			cur_adc_status_ptr->over_run_flag = STATE_NO;
		}
        if(*adc_stat_ptr[adc_master_ch_id] & (1 << 16))
		{
			cur_adc_status_ptr->first_for_conv_flag = STATE_NO;
			cur_adc_status_ptr->done_interrupt_flag = STATE_YES;
		}
        else
		{
			cur_adc_status_ptr->done_interrupt_flag = STATE_NO;
		}			
	}
	return SUCCESS;    	
}

/*------------------------------------------------------------*
FUNCTION NAME  : ADC_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : PCLK(APB clock) = 15MHz.

Func ID        : 14.02

BUGS           :    
-*------------------------------------------------------------*/
uint16_t ADC_Init(const uint8_t adc_master_ch_id)
{
	adc_ctrl_t *cur_adc_ctrl_ptr; 
	adc_status_t *cur_adc_status_ptr; 
	uint16_t ret_status;
	uint8_t cur_adc_sub_ch_id, adc_io_ch, adc_func_mode, num_adc_sel_sub_chs = 0, get_func_mode;
	
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.02.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	cur_adc_ctrl_ptr = adc_ctrl + adc_master_ch_id;
	cur_adc_status_ptr = adc_status + adc_master_ch_id;
	*adc_cr_ptr[adc_master_ch_id] |= (1 << 21); // adc operational
	if((ret_status = ADC_Stop_Conv(adc_master_ch_id)) != SUCCESS)
	{
		 system_status_flag = ERR_ADC_STOP_CONV_PROC;
		 Error_or_Warning_Proc("14.02.02", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}	
	if(cur_adc_ctrl_ptr->burst_mode == STATE_YES)
	{
		if(cur_adc_ctrl_ptr->start_mode != 0)
		{
			system_status_flag = ERR_ADC_BURST_MODE_BUT_START_MODE_INVALID;
		    Error_or_Warning_Proc("14.02.03", ERROR_OCCURED, system_status_flag);
		    return system_status_flag;
		}	
	}
	else
	{
		//software controlled mode
		if(cur_adc_ctrl_ptr->num_result_bits_mode != 0)
		{
			system_status_flag = ERR_ADC_SW_CTRL_BUT_RESULT_BITS_INVALID;
		    Error_or_Warning_Proc("14.02.04", ERROR_OCCURED, system_status_flag);
		    return system_status_flag;
		}
	    for(cur_adc_sub_ch_id = 0; cur_adc_sub_ch_id < MAX_ADC_SUB_CHS; ++cur_adc_sub_ch_id)
	    {
	     	if(cur_adc_ctrl_ptr->sel_sub_chs & (1 << cur_adc_sub_ch_id))
	        {
		    	++num_adc_sel_sub_chs;
			    if(num_adc_sel_sub_chs > 1)
			    {
			    	system_status_flag = ERR_ADC_SW_CTRL_MODE_SEL_CHS_MORE_THAN_ONE;
		            Error_or_Warning_Proc("14.02.05", ERROR_OCCURED, system_status_flag);
		            return system_status_flag;
				
		        }
		    }
	    }
	}
	if(cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_NO)
	{
		//global adc done to interrupt  
	   if(cur_adc_ctrl_ptr->sel_sub_chs_interrupt != 0)
	   {
		   system_status_flag = ERR_ADC_GLOBAL_INTP_BUT_SEL_ENABLED;
		   Error_or_Warning_Proc("14.02.06", ERROR_OCCURED, system_status_flag);
		   return system_status_flag;
	   }		   
	}
	else
	{
	   if((cur_adc_ctrl_ptr->sel_sub_chs | cur_adc_ctrl_ptr->sel_sub_chs_interrupt) != cur_adc_ctrl_ptr->sel_sub_chs)
	   {
		   system_status_flag = ERR_ADC_NON_SEL_CH_BUT_TO_INTP;
		   Error_or_Warning_Proc("14.02.07", ERROR_OCCURED, system_status_flag);
		   return system_status_flag;
	   }
	   cur_adc_status_ptr->sel_sub_chs_polling = cur_adc_ctrl_ptr->sel_sub_chs & ~(cur_adc_ctrl_ptr->sel_sub_chs_interrupt);
	}
	switch(cur_adc_ctrl_ptr->start_mode)
	{
		case 2:
		    //Start conversion when the edge selected by  bit 27 of ad_cr_ptr occurs on P0.16/EINT0/MAT0.2/CAP0.2 pin
		    Get_IO_Func_Mode(IO_CH_16, &get_func_mode);				
			switch(get_func_mode)
			{
				case IO_FUNC_MODE_INVALID:
				    system_status_flag = ERR_IO_CH_INVALID;
		            Error_or_Warning_Proc("14.02.08", ERROR_OCCURED, system_status_flag);
		            return system_status_flag;
				//break;
				case IO_FUNC_MODE_NA:
				  //io not configure in pin sel, match 0.2 need not conf in pin sel for adc start conv for edge 
				   cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;
				break;
				case IO_FUNC_MODE_03:
				   //pin sel conf for capture 0.2 
				   cur_adc_status_ptr->adc_run_status = ADC_EDGE_CAPTURE_START_CONV;
				break;
				case IO_FUNC_MODE_02:
				  //pin sel conf for match 0.2
				   cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;
				break;
				case IO_FUNC_MODE_01:
			      //match 0.2 need not conf in pin sel for adc start conv for edge 
			       cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;			   
				break;
			}
		break;
		case 3:
		   //Start conversion when the edge selected by bit 27 of ad_cr_ptr occurs on P0.22/AD1.7/CAP0.0/MAT0.0 pin
		    Get_IO_Func_Mode(IO_CH_22, &get_func_mode);
			switch(get_func_mode)
			{
				case IO_FUNC_MODE_INVALID:
				    system_status_flag = ERR_IO_CH_INVALID;
		            Error_or_Warning_Proc("14.02.09", ERROR_OCCURED, system_status_flag);
		            return system_status_flag;					
				//break;
				case IO_FUNC_MODE_NA:
				    //io not configure in pin sel,  match 0.0 need not conf in pin sel for adc start conv for edge 
					 cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;
				break;
				case IO_FUNC_MODE_03:
				   //pin sel conf for match 0.0
                  	 cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;			   
				break;
				case IO_FUNC_MODE_02:
				  //pin sel conf for capture 0.0
				  cur_adc_status_ptr->adc_run_status = ADC_EDGE_CAPTURE_START_CONV; 
				break;
				case IO_FUNC_MODE_01:
			      //match 0.0 need not conf in pin sel for adc start conv for edge 
			       cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;			   
				break;
			}
		break;
		case 4: //Start conversion when the edge selected by bit 27 of ad_cr_ptr occurs on MAT0.1[1].
		case 5: //Start conversion when the edge selected by bit 27 of ad_cr_ptr occurs on MAT0.3[1].
        case 6: //Start conversion when the edge selected by bit 27 of ad_cr_ptr occurs on MAT1.0[1].
        case 7: //Start conversion when the edge selected by bit 27 of ad_cr_ptr occurs on MAT1.1[1].
		   cur_adc_status_ptr->adc_run_status = ADC_EDGE_TIMER_MATCH_START_CONV;
		break;   
	}
	for(cur_adc_sub_ch_id = 0; cur_adc_sub_ch_id < MAX_ADC_SUB_CHS; ++cur_adc_sub_ch_id)
	{
		if(cur_adc_ctrl_ptr->sel_sub_chs & (1 << cur_adc_sub_ch_id))
		{
			switch(adc_master_ch_id)
			{
				case CH_ID_00:
				  switch(cur_adc_sub_ch_id)
				  {
					  case CH_ID_00:
					      adc_io_ch = IO_CH_27;
						  adc_func_mode = IO_FUNC_MODE_01;
					  break;
                      case CH_ID_01:
					      adc_io_ch = IO_CH_28;
						  adc_func_mode = IO_FUNC_MODE_01;
                      break;	
                      case CH_ID_02:
					      adc_io_ch = IO_CH_29;
						  adc_func_mode = IO_FUNC_MODE_01;
                      break;
					  case CH_ID_03:
					      adc_io_ch = IO_CH_30;
						  adc_func_mode = IO_FUNC_MODE_01;
                      break;
                      case CH_ID_04:
					      adc_io_ch = IO_CH_25;
						  adc_func_mode = IO_FUNC_MODE_01;
                      break;
                      case CH_ID_05:
					      adc_io_ch = IO_CH_26;
						  adc_func_mode = IO_FUNC_MODE_03;
                      break;
                      case CH_ID_06:
					      adc_io_ch = IO_CH_04;
						  adc_func_mode = IO_FUNC_MODE_03;
                      break;
                      case CH_ID_07:
					      adc_io_ch = IO_CH_05;
						  adc_func_mode = IO_FUNC_MODE_03;
                      break;						  
				  }
				break;
				case CH_ID_01:
				   switch(cur_adc_sub_ch_id)
				   {
					   case CH_ID_00:
					      adc_io_ch = IO_CH_06;
						  adc_func_mode = IO_FUNC_MODE_03;
					   break;
					   case CH_ID_01:
					      adc_io_ch = IO_CH_08;
						  adc_func_mode = IO_FUNC_MODE_03;
					   break;
					   case CH_ID_02:
					      adc_io_ch = IO_CH_10;
						  adc_func_mode = IO_FUNC_MODE_03;
					   break;
					   case CH_ID_03:
					      adc_io_ch = IO_CH_12;
						  adc_func_mode = IO_FUNC_MODE_03;
					   break;
					   case CH_ID_04:
					      adc_io_ch = IO_CH_13;
						  adc_func_mode = IO_FUNC_MODE_03;
					   break;
					   case CH_ID_05:
					      adc_io_ch = IO_CH_15;
						  adc_func_mode = IO_FUNC_MODE_03;
					   break;
					   case CH_ID_06:
					      adc_io_ch = IO_CH_21;
						  adc_func_mode = IO_FUNC_MODE_02;
					   break;
					   case CH_ID_07:
					      adc_io_ch = IO_CH_22;
						  adc_func_mode = IO_FUNC_MODE_01;
					   break;
				   }
				break;
		    }
			if((ret_status = Non_GPIO_Func_Set(adc_io_ch, adc_func_mode)) != SUCCESS)
			{
				system_status_flag = ERR_ADC_FUNC_SET_PROC;
	            Error_or_Warning_Proc("14.02.10", ERROR_OCCURED, system_status_flag);
		        return system_status_flag;
			}
		}
	}
	*adc_cr_ptr[adc_master_ch_id] &= ~(0xFF);
	//adc channel to conv  
	*adc_cr_ptr[adc_master_ch_id] |= cur_adc_ctrl_ptr->sel_sub_chs;
	*adc_cr_ptr[adc_master_ch_id] &= ~(0xFF << 8);
	//for PCLK(APB clock) = 15MHz and ADC clock = 3.0MHz( < 4.5MHz)
	*adc_cr_ptr[adc_master_ch_id] |= 0x04;
	*adc_cr_ptr[adc_master_ch_id] &= ~(1 << 16);
	//adc burst or sw controlled mode
	*adc_cr_ptr[adc_master_ch_id] |= (cur_adc_ctrl_ptr->burst_mode << 16);
	if(cur_adc_ctrl_ptr->burst_mode == STATE_YES)
	{
		//number of clocks used for each conversion in Burst mode, and the number of bits of accuracy of the result in the RESULT
	   *adc_cr_ptr[adc_master_ch_id] &= (0x07 << 17);
	   *adc_cr_ptr[adc_master_ch_id] |= (cur_adc_ctrl_ptr->num_result_bits_mode << 17);
	}
	else
	{
	   if(cur_adc_ctrl_ptr->start_mode >= 2 && cur_adc_ctrl_ptr->start_mode <= 7)
	   {
		   //Start conversion on a rising/falling edge on the selected CAP/MAT signal.
		   *adc_cr_ptr[adc_master_ch_id] &= (1 << 27);
	       *adc_cr_ptr[adc_master_ch_id] |= (cur_adc_ctrl_ptr->start_conv_falling_edge << 27);
	   }
	}
	if(cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_NO || (cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_YES && cur_adc_ctrl_ptr->sel_sub_chs_interrupt != 0))
	{
		if((ret_status = Enable_ADC_Interrupt(adc_master_ch_id)) != SUCCESS)
		{
			system_status_flag = ERR_ENABLE_INTERRUPT;
	        Error_or_Warning_Proc("14.02.11", ERROR_OCCURED, system_status_flag);
		    return system_status_flag;
		}
	}
	cur_adc_status_ptr->init_proc_flag = STATE_YES;
	if(cur_adc_ctrl_ptr->start_mode == 1)
	{
		//start adc conv
		if((ret_status = Start_ADC_Conv(adc_master_ch_id)) != SUCCESS)
		{
			system_status_flag = ERR_ADC_START_CONV_PROC;
	        Error_or_Warning_Proc("14.02.12", ERROR_OCCURED, system_status_flag);
		    return system_status_flag;
		}
	}
	return SUCCESS;    	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Start_ADC_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :  after ADC is initialized, then only this function should be called.

Func ID        : 14.03

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Start_ADC_Conv(const uint8_t adc_master_ch_id)
{
	adc_status_t *cur_adc_status_ptr; 
	adc_ctrl_t *cur_adc_ctrl_ptr;
	uint16_t ret_status;
	
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.03.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	cur_adc_status_ptr = adc_status + adc_master_ch_id;
	cur_adc_ctrl_ptr = adc_ctrl + adc_master_ch_id;
	if(cur_adc_status_ptr->init_proc_flag != STATE_YES)
	{
		 system_status_flag = ERR_ADC_NOT_INIT_FOR_START_CONV;
		 Error_or_Warning_Proc("14.03.02", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	if((ret_status = ADC_Stop_Conv(adc_master_ch_id)) != SUCCESS)
	{
		 system_status_flag = ERR_ADC_STOP_CONV_PROC;
		 Error_or_Warning_Proc("14.03.03", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}	
	if(cur_adc_status_ptr->first_for_conv_flag == STATE_NO)
	{
	   if((ret_status = ADC_Status(adc_master_ch_id, MAX_ADC_SUB_CHS)) != SUCCESS)
	   {
		  system_status_flag = ERR_ADC_STATUS_PROC;
	      Error_or_Warning_Proc("14.03.04", ERROR_OCCURED, system_status_flag);
		  return system_status_flag;
	   }	
	   if(cur_adc_status_ptr->done_flag == STATE_NO)
	   {
		  system_status_flag = WARN_ADC_IS_CONVERTING;
	      Error_or_Warning_Proc("14.03.05", WARNING_OCCURED, system_status_flag);
		  return system_status_flag;
	   }
	   if(cur_adc_status_ptr->over_run_flag == STATE_YES)
	   {
	    	system_status_flag = WARN_ADC_IS_OVER_RUN;
	        Error_or_Warning_Proc("14.03.06", WARNING_OCCURED, system_status_flag);
		    return system_status_flag;
	   }
	}
	if(cur_adc_ctrl_ptr->start_mode == 0)
	{
		//no start adc
		cur_adc_status_ptr->adc_run_status = ADC_START_CONV;		
		*adc_cr_ptr[adc_master_ch_id] |= (1 << 24); // adc start conv
	}
	return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Enable_ADC_Interrupt

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.04

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Enable_ADC_Interrupt(const uint8_t adc_master_ch_id)
{
	adc_ctrl_t *cur_adc_ctrl_ptr;
  adc_status_t *cur_adc_status_ptr; 
   uint16_t ret_status;
	
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.04.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
  cur_adc_status_ptr = adc_status + adc_master_ch_id;
	cur_adc_ctrl_ptr = adc_ctrl + adc_master_ch_id;
	if(!(cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_NO || (cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_YES && cur_adc_ctrl_ptr->sel_sub_chs_interrupt != 0)))
	{
		system_status_flag = ERR_ADC_ENABLE_INTERRUPT_BUT_NOT_CONF;
	    Error_or_Warning_Proc("14.04.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if((ret_status = ADC_Stop_Conv(adc_master_ch_id)) != SUCCESS)
	{
		 system_status_flag = ERR_ADC_STOP_CONV_PROC;
		 Error_or_Warning_Proc("14.04.03", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}	
	if(cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_NO)
	{
		//glabal adc done to interrupt 
		*adc_inten_ptr[adc_master_ch_id] = (1 << 8); 
		return SUCCESS;
	}
	if(cur_adc_ctrl_ptr->adc_sel_interrupt_flag == STATE_YES && cur_adc_ctrl_ptr->sel_sub_chs_interrupt != 0)
	{
		if((cur_adc_ctrl_ptr->sel_sub_chs | cur_adc_ctrl_ptr->sel_sub_chs_interrupt) != cur_adc_ctrl_ptr->sel_sub_chs)
	    {
	    	system_status_flag = ERR_ADC_NON_SEL_CH_BUT_TO_INTP;
		    Error_or_Warning_Proc("14.04.04", ERROR_OCCURED, system_status_flag);
		    return system_status_flag;
	    }
	    cur_adc_status_ptr->sel_sub_chs_polling = cur_adc_ctrl_ptr->sel_sub_chs & ~(cur_adc_ctrl_ptr->sel_sub_chs_interrupt);
		//Only the individual ADC channels enabled by cur_adc_ctrl_ptr->sel_sub_chs_interrupt will generate interrupts
		*adc_inten_ptr[adc_master_ch_id] = cur_adc_ctrl_ptr->sel_sub_chs_interrupt;        		
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_ADC_Interrupt

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.05

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Disable_ADC_Interrupt(const uint8_t adc_master_ch_id)
{
	adc_ctrl_t *cur_adc_ctrl_ptr; 
	adc_status_t *cur_adc_status_ptr; 
	uint16_t ret_status;
	uint8_t adc_intp_src_id ;
	
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.05.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	cur_adc_status_ptr = adc_status + adc_master_ch_id;
	cur_adc_ctrl_ptr = adc_ctrl + adc_master_ch_id;
	*adc_inten_ptr[adc_master_ch_id] = 0; //no adc done interrupt
	cur_adc_status_ptr->sel_sub_chs_polling = cur_adc_ctrl_ptr->sel_sub_chs;
    switch(adc_master_ch_id)
	{
		case CH_ID_00:
		  adc_intp_src_id = INTP_REQ_AD0;
		break;
       	case CH_ID_01:
		  adc_intp_src_id = INTP_REQ_AD1; 
        break;
	}		
    if((ret_status = Disable_Interrupt_Src(adc_intp_src_id)) != SUCCESS)
    {
       system_status_flag = ERR_DISABLE_INTERRUPT;
	   Error_or_Warning_Proc("14.05.02", ERROR_OCCURED, system_status_flag);
	   return system_status_flag; 
    }
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_ADC_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.06

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Reset_ADC_Status(const uint8_t adc_master_ch_id, const uint8_t reset_type)
{
	adc_status_t *cur_adc_status_ptr; 
		
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.06.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	cur_adc_status_ptr = adc_status + adc_master_ch_id;
	switch(reset_type)
	{
		case RESET_ADC_WHOLE_STATUS:
		   cur_adc_status_ptr->init_proc_flag = STATE_NO;
		   cur_adc_status_ptr->first_for_conv_flag = STATE_YES;
		case RESET_ADC_CONV_STATUS:
	      cur_adc_status_ptr->done_flag = STATE_NO;
	      cur_adc_status_ptr->over_run_flag = STATE_NO;
		  cur_adc_status_ptr->done_interrupt_flag = STATE_NO;
	      cur_adc_status_ptr->conv_result = ADC_ENCODED_VALUE_NA;	      
	      cur_adc_status_ptr->adc_sub_ch_id = ADC_SUB_CH_ID_NA;
	  break;
	  default:
	     system_status_flag = ERR_FORMAT_INVALID;
		 Error_or_Warning_Proc("14.06.02", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ADC_Stop_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.07

BUGS           :    
-*------------------------------------------------------------*/
uint16_t ADC_Stop_Conv(const uint8_t adc_master_ch_id)
{
	adc_status_t *cur_adc_status_ptr; 
	if(adc_master_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
	{
		 system_status_flag = ERR_DEV_CH_ID_EXCEEDS;
		 Error_or_Warning_Proc("14.02.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
	cur_adc_status_ptr = adc_status + adc_master_ch_id;
	if(cur_adc_status_ptr->adc_run_status == ADC_NO_START_CONV)
	{
		return SUCCESS;
	}
    *adc_cr_ptr[adc_master_ch_id] &= ~(7 << 24); // no start conv
	cur_adc_status_ptr->adc_run_status = ADC_NO_START_CONV;
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_ADC_0

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.08

BUGS           :    
-*------------------------------------------------------------*/
void ISR_ADC_0(void) __irq
{
	VICVectAddr = 0x0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : ISR_ADC_1

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.09

BUGS           :    
-*------------------------------------------------------------*/
void ISR_ADC_1(void) __irq
{
	VICVectAddr = 0x0;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
