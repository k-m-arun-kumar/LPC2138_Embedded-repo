/**************************************************************************
   FILE          :    conf_appl.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _CONF_APPL_H
 #define _CONF_APPL_H 
 
/* -------------------------------- Debug Conf -----------------------------------------*/
//#define TRACE                                 (1U)
#define TRACE_ERROR                             (2U)
#define TRACE_REQ                               (3U)
#define TRACE_INFO                              (4U)
//#define TRACE_DATA                            (5U)
//#define TRACE_FLOW                            (6U)

#define TRACE_LCD_CH_ID                             (CH_ID_00)
#define TRACE_UART_CH_ID                            (CH_ID_00) 

/* -------------------------------  Macro Conf ------------------------------------------*/
//#define SHOULD_REMOVE                 (7)
#define SHOULD_CALL                     (8)
//#define TEST                          (9)                                                  
//#define SW_PRESS_HOLD_CPU             (10)
//#define DMA_DATA_ID_STR               (11)
//#define STR_TO_NUM_FROM_RIGHT_TO_LEFT (12)
 
//#define BUG_PRINT                       (13)

/* ------------------------------ Appl Data Types --------------------------------------- */

#define MAX_DATA_INPUT_DEVS                 (2)
#define MAX_DATA_OUTPUT_DEVS                (2)
#define MAX_DATA_RECEIVE_DEVS               (1) 
#define MAX_DATA_TRANSMIT_DEVS              (1)

typedef enum 
{
   DATA_ID_ADC, NUM_DATA_IDS    	
} appl_data_id_t;

/*------------------------------- LCD Disp Conf ------------------------------------------*/
#ifdef LCD_MOD_ENABLE
   #define ERROR_LINE_NUM           (LINE_NUM_04)   
#endif

/* -------------------------------Timer State Conf ---------------------------------------*/
#ifdef TIMER_MOD_ENABLE

#endif

/*------------------------------- Ext Interrupt Conf ------------------------------------------*/
#ifdef EXT_INTERRUPT_MOD_ENABLE

#endif

/* ------------------------------ ADC input signal val Conf ------------------------------*/
#ifdef ADC_MOD_ENABLE

#define ADC_VREF_IN_MV                     (3300)

#endif

/* ------------------------------- Application Conf --------------------------------------*/

#define HIDDEN_KEY_DISP_CHAR                      ('X') 
#define DATA_MAX_NUM_ALLOCATED_CHARS              (11) 
#define HIDDEN_CHAR_LCD_DISP_TIME_IN_MS          (1000)
#define MAX_ICOUNT_HIDDEN_CHAR_DISP_1500MS       (1500)
#define MAX_JCOUNT_HIDDEN_CHAR_DISP_1500MS       (1500)

#define  NUM_CHARS_INPUTDATA        GIVEN_CHARS_MAX_CONFIG_LINES_AND_COLS

#define MAX_COUNT_LONG_PRESSKEY_TIMEOUT   (3U)  

#define MAX_TIMEOUT_NO_KEY_PRESS         (10)  
#define MAX_TIMEOUT_LONG_PRESS_KEY       (5)

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
