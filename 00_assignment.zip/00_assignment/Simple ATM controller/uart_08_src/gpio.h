/**************************************************************************
   FILE          :    gpio.h
 
   PURPOSE       :    GPIO Library header 
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :    
	
  CHANGE LOGS     :  
	   
 **************************************************************************/
#ifndef _GPIO_H
#define _GPIO_H

 /* ---------------------- macro defination ------------------------------------------------ */
 /** The base address of the GPIO peripheral (ARM Physical Address) */
#define ARM_GPIO_BASE       ( PERIPHERAL_BASE + 0x28000UL )

/* ---------------------- data type defination -------------------------------------------- */

/* -------------------- public variable declaration --------------------------------------- */

   
/* -------------------- public function declaration --------------------------------------- */

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
