/* ********************************************************************
FILE                   : appl.c

PURPOSE                :  Application 
	 
AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 11

*****************************************************************************/
#include "main.h"
#include "appl.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */ 
uint32_t appl_status_flag = NO_ERROR;
			
/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Appl_Proc(void)
{	
     static uint8_t loop_flag = 0; 
  
	   switch(cur_data_id) 
	   {	
	     case DATA_ID_LCD: 
		   if((loop_flag & (1 << 0)) == 0)
		   {
			   loop_flag |= (1 << 0);			   
               if((LCD_Disp_Goto_XY(TRACE_LCD_CH_ID, LINE_NUM_01, COL_NUM_01)) != SUCCESS)
			   {
				   appl_status_flag = ERR_LCD_GOTO_XY_PROC;
		           Error_or_Warning_Proc("11.01.10", ERROR_OCCURED, appl_status_flag);
		           return appl_status_flag;
			   }
			   LCD_Disp_Str(TRACE_LCD_CH_ID, "Hello");                 
		   }
		 break;	
		 default:
		   appl_status_flag = ERR_CUR_DATA_ID_INVALID;
		   Error_or_Warning_Proc("11.01.11", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;
	 } 
     return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.02  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_Init(const void *const data_ptr)
{	
  if((Next_Data_Conf_Parameter(DATA_ID_LCD)) != SUCCESS)
	{
		 appl_status_flag = ERR_NEXT_DATA_CONF;
		 Error_or_Warning_Proc("11.02.01", ERROR_OCCURED, system_status_flag);
		 return system_status_flag;
	}
  if((LCD_Enable(CH_ID_00)) != SUCCESS)
	{
		appl_status_flag = ERR_DEV_ENABLE_PROC;
		Error_or_Warning_Proc("11.02.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if((UART_Transmit_Enable_Ctrl(CH_ID_00, STATE_YES)) != SUCCESS)
	{
		appl_status_flag = ERR_DEV_ENABLE_PROC;
		Error_or_Warning_Proc("11.02.03", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if((UART_Receive_Enable_Ctrl(CH_ID_00, STATE_YES)) != SUCCESS)
	{
		appl_status_flag = ERR_DEV_ENABLE_PROC;
		Error_or_Warning_Proc("11.02.04", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if((UART_Enable(CH_ID_00)) != SUCCESS)
	{
		appl_status_flag = ERR_DEV_ENABLE_PROC;
		Error_or_Warning_Proc("11.02.05", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}	
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW in order from SW_CH_ID from 0 if any, then initialize Keyboard, if any.

Func ID        : 11.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Appl_HW_Init(void)
{
    if((UART_Init(TRACE_UART_CH_ID, COMM_TRANSMIT_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((UART_Init(TRACE_UART_CH_ID, COMM_RECEIVE_FUNC)) != SUCCESS)
	{
		return FAILURE;
	}
	if((UART_Init(TRACE_UART_CH_ID, DEV_INIT_OPER)) != SUCCESS)
	{
		return FAILURE;
	}
	if(internal_error_led_io_ch < IO_CH_INVALID)
	{
	   if((Output_Dev_Init(internal_error_led_io_ch, 1)) != SUCCESS)
	   {
	      return FAILURE;
	   }
	}
	if((LCD_Init(CH_ID_00, DATA_NA)) != SUCCESS)
	{
		return FAILURE;
	} 
	#ifdef TRACE_FLOW
	   Print("TRA: HW Init over\r");
	#endif
	return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Error_or_Warning_Occured_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.04

BUGS           :    
-*------------------------------------------------------------*/
uint16_t Error_or_Warning_Occured_Proc(const uint8_t warn_or_error_format, const uint32_t warning_or_error_code)
{
	switch(warn_or_error_format)
	{
		case WARNING_OCCURED:			
		  if((error_or_warning_proc_flag & (1 << 0)) == 0)
		  {
			  /* warning occured, process to do  */ 
			  error_or_warning_proc_flag |= (1 << 0);
		  }		 
		break;
		case ERROR_OCCURED:
		   if((error_or_warning_proc_flag & (1 << 1)) == 0)
		   {
		       /*error occured, process to do  */
			   error_or_warning_proc_flag |= (1 << 1);
			   error_or_warning_proc_flag |= (1 << 0); 
		   }		   
		break;
		case FATAL_OCCURED:
		  if((error_or_warning_proc_flag & (1 << 2)) == 0)
		  {
		      /* fatal error occured, process to do */
			  error_or_warning_proc_flag |= (1 << 2);
			  error_or_warning_proc_flag |= (1 << 1);
			  error_or_warning_proc_flag |= (1 << 0); 
		  }		  
        break;
		default:
		   error_or_warning_proc_flag |= (1 << 3);
           system_status_flag = ERR_FORMAT_INVALID;		
		   return system_status_flag;
	}	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.05

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	switch(reset_type)
	{
		case RESET_APPL:	
           appl_status_flag = NO_ERROR;	
		   if((Appl_Reset_Proc(DATA_NA)) != SUCCESS)
		   {
			    appl_status_flag = ERR_APPL_RESET_PROC;
		        Error_or_Warning_Proc("11.05.01", ERROR_OCCURED, appl_status_flag);
		        return appl_status_flag;
		   }
		break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.05.02", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;
	}
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.06
BUGS           :    
-*------------------------------------------------------------*/ 
uint16_t Appl_Reset_Proc(const uint8_t reset_data)
{
	return SUCCESS;
}	

#ifdef TIMER_MOD_ENABLE 
/*------------------------------------------------------------*
FUNCTION NAME  : Timer_0_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.07  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_0_Timeout_Proc(const uint16_t timeout_type, volatile const timer_or_counter_data_t *const timer_0_or_counter_data_ptr)
{
	uint16_t ret_status;
	
	if(timer_0_or_counter_data_ptr == NULL_DATA_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("11.07.01", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	if(timer_0_or_counter_data_ptr->timer_or_counter_run_id != TMR_OR_COUNTER_SYSTEM_TICK_STATE)
	{
		appl_status_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.07.02", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
    /* --------------------------------------- User Code: Begin ------------------------------------------ */ 
	
	/* --------------------------------------- User Code: End   ------------------------------------------ */ 
	switch(timeout_type)
	{
		 case TMR_NO_MAX_NUM_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_NO_MAX_NUM_TIMEOUT_PROC;
	     break;		
		 case TMR_AT_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_AT_LAST_TIMEOUT_PROC;
		 break;  
		 case TMR_BEFORE_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_BEFORE_LAST_TIMEOUT_PROC;
		 break;
         case TMR_MAX_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_MAX_NUM_TIMEOUT_PROC; 
         break;		
         default:
             appl_status_flag = ERR_TMR_TIMEOUT_TYPE_INVALID;
		     Error_or_Warning_Proc("11.07.03", ERROR_OCCURED, appl_status_flag);
		     return appl_status_flag;
	}
    return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Timer_1_Timeout_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.08 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Timer_1_Timeout_Proc(const uint16_t timeout_type, volatile const timer_or_counter_data_t *const timer_1_or_counter_data_ptr)
{
	    uint16_t ret_status;
    
    if(timer_1_or_counter_data_ptr == NULL_DATA_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("11.08.01", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	if(timer_1_or_counter_data_ptr->timer_or_counter_run_id >= NUM_TIMER_AND_COUNTER_IDS)
	{
		appl_status_flag = ERR_TIMER_ID_EXCEEDS;
		Error_or_Warning_Proc("11.08.02", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	/* --------------------------------------- User Code: Begin ------------------------------------------ */ 
	
		
	/* --------------------------------------- User Code: End   ------------------------------------------ */ 
	
	 switch(timeout_type)
	 {
		 case TMR_NO_MAX_NUM_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_NO_MAX_NUM_TIMEOUT_PROC;
	     break;		
		 case TMR_AT_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_AT_LAST_TIMEOUT_PROC;
		 break;  
		 case TMR_BEFORE_LAST_TIMEOUT_YET_PROCESS:
		   ret_status = TMR_BEFORE_LAST_TIMEOUT_PROC;
		 break;
         case TMR_MAX_TIMEOUT_YET_PROCESS:
		    ret_status = TMR_MAX_NUM_TIMEOUT_PROC; 
         break;		 
         default:
		     appl_status_flag = ERR_TMR_TIMEOUT_TYPE_INVALID;
		     Error_or_Warning_Proc("11.08.05", ERROR_OCCURED, appl_status_flag);
		     return appl_status_flag;
	 }
    return ret_status;	
}

#endif

#ifdef EXT_INTERRUPT_MOD_ENABLE
/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_0_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.09  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_0_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_1_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.10  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_1_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_2_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.11  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_2_Proc(void)
{
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Ext_Interrupt_3_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.12  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Ext_Interrupt_3_Proc(void)
{
	return SUCCESS;
}

#endif

		    
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
