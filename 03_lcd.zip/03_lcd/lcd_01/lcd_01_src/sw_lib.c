/* ********************************************************************
FILE                   : sw_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 07 

*****************************************************************************/
#include "main.h"

#if defined(SW_MOD_ENABLE) || defined(KEYPAD_MOD_ENABLE)

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
uint8_t last_sw_ch_id = 0;
static uint16_t alloc_sw_ch_ids_bit_field = 0;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Ch_To_SW_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.01  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Ch_To_SW_Ch(const uint8_t io_ch, uint8_t *const sw_ch_id_ptr )
{
	    uint8_t ret_status = FAILURE, i;
	
	    if(sw_ch_id_ptr == NULL_PTR || ((ret_status = IO_Ch_Validate(io_ch, 1)) != SUCCESS))
      {
		    error_flag = ERR_IO_CH_TO_SW_CH;
		    return error_flag; 
	    }
	    for(i = 0; i <= last_sw_ch_id; ++i)
	    {
				  if(sw_para[i].io_ch == io_ch)
					{
						 ret_status = SUCCESS;
						 *sw_ch_id_ptr = i;
						 break;
					}
			}
			if(i > last_sw_ch_id)
			{
		    	error_flag = ERR_SW_CH_NOT_MATCH_IO_CH ;
				ret_status = error_flag;
			}
			return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_Config_By_Dynamic

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.02  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_Config_By_Dynamic(const uint8_t io_ch, const uint8_t num_sw_chs, const uint8_t sw_pressed_state)
{
  	uint8_t alloc_start_sw_ch_id, ret_status, i ;
	
	if(last_sw_ch_id + num_sw_chs  > NUM_INPUT_DEV_ID_SW_CHS)
	{
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	}
	if(sw_pressed_state >= 2)
	{
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
    if((ret_status = Check_And_Alloc_SW_Ch_ID(CH_ID_ALLOC_DYNAMIC, num_sw_chs, &alloc_start_sw_ch_id)) != SUCCESS)
	{
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
	
    for(i = 0 ; i < num_sw_chs; ++i, ++alloc_start_sw_ch_id )	
	{
   	sw_para[alloc_start_sw_ch_id].io_ch = io_ch + i;
  	SW_No_Access(alloc_start_sw_ch_id);
  	sw_para[alloc_start_sw_ch_id].sw_cur_state = STATE_KEY_RELEASED;
  	sw_para[alloc_start_sw_ch_id].sw_pressed_state = sw_pressed_state;	
	}
       
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_SW_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.03  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Reset_SW_Ch(const uint8_t sw_ch_id)
{
	 if(sw_ch_id >= last_sw_ch_id) 
	 {
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	 }		 
   sw_para[sw_ch_id].io_ch = IO_CH_INVALID;
   SW_No_Access(sw_ch_id);
   sw_para[sw_ch_id].sw_cur_state = STATE_KEY_RELEASED;
   sw_para[sw_ch_id].sw_pressed_state = STATE_LOW;
   Clear_Bit_in_Data(&alloc_sw_ch_ids_bit_field, sw_ch_id); 
       if(sw_ch_id == last_sw_ch_id - 1)
       {
	      --last_sw_ch_id;
       }
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_SW_Chs

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.04  

BUGS           :              
-*------------------------------------------------------------*/
void Reset_SW_Chs(void)
{
	uint8_t i;
	
	for (i = 0 ; i < last_sw_ch_id; ++i)
	{
	  	Reset_SW_Ch(i);
	}
	last_sw_ch_id = 0;
	alloc_sw_ch_ids_bit_field = 0;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Read_By_IO_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.05  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Read_By_IO_Ch(const uint8_t io_ch, uint8_t *const sw_ch_id_ptr )
{
	 uint8_t ret_status = SUCCESS, read_data;
		 
	 if((ret_status = IO_Channel_Read(io_ch, &read_data )) != SUCCESS)
	 {
		   error_flag = ERR_SW_NO_READ;
		  return error_flag; 
	 }
	 if((ret_status = IO_Ch_To_SW_Ch(io_ch, sw_ch_id_ptr )) != SUCCESS)
	 {
		 error_flag = ERR_SW_NO_READ;
		 return error_flag;
	 }
	 
	 if((ret_status = SW_Read(*sw_ch_id_ptr)) != SUCCESS)
	 {
		 error_flag = ERR_SW_NO_READ;
		 return error_flag;
	 }
	 return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Read_By_IO_Ch_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.06  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Read_By_IO_Ch_Proc(const uint8_t sw_io_ch)
{
	uint8_t ret_status = SW_OR_KEY_NOT_PRESSED, sw_ch_id;
	 
	if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}	
 
	if((ret_status = IO_Ch_To_SW_Ch(sw_io_ch, &sw_ch_id)) != SUCCESS)
	{
		   return ret_status;
	}
	ret_status = SW_Press_Proc(sw_ch_id);
	return ret_status;
}

#ifdef SW_PRESS_HOLD_CPU
/*------------------------------------------------------------*
FUNCTION NAME  : SW_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : When SW is pressed, then hold CPU by using While(read_sw_pressed_state);  

Func ID        : 07.07  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Press_Proc(const uint8_t sw_ch_id)
{
	sw_para_t *sw_para_ptr;
	uint8_t ret_status = SW_OR_KEY_NOT_PRESSED;
	
    if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}		
	sw_para_ptr = sw_para + sw_ch_id;
	if( sw_para_ptr->access_flag != STATE_YES) 
	{  
          error_flag = ERR_CUR_DATA_ID_DEV_NO_ACCESS;	
          return  error_flag;
	}
		 
	if(sw_para_ptr->enable_flag != STATE_YES) 
	{  
         error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
         return  error_flag;
	}
		   
			  if((ret_status = SW_Read(sw_ch_id )) != SUCCESS)
			   {
				     ret_status = ERR_SW_NO_READ; 				     
					 return ret_status;
			   }
		     if(sw_para_ptr->sw_cur_state == STATE_KEY_RELEASED  && (sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state))
			  {
				      SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY); 
			          if(((ret_status = SW_Read(sw_ch_id )) != SUCCESS))
					  {
						    ret_status = ERR_SW_NO_READ; 	
							return ret_status;		  
					  }
					  if( sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state)
		              { 
			               sw_para_ptr->sw_cur_state = STATE_KEY_PRESSED;
						   do
					       {
							  if((ret_status = SW_Read(sw_ch_id )) != SUCCESS)
							  {
								    ret_status = ERR_SW_NO_READ; 	
									return ret_status;    
							  }												 
												 
						  } while( sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state); 
					  }  
					  SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY);
					  if((ret_status = SW_Read(sw_ch_id )) != SUCCESS)
					  {
					    	ret_status = ERR_SW_NO_READ; 	
							return ret_status; 
					  }
					  if(sw_para_ptr->sw_read_data != sw_para_ptr->sw_pressed_state)
					  {
						  sw_para_ptr->sw_cur_state = STATE_KEY_RELEASED;		
						  return SUCCESS;
			          }				 
			     } 	
		return SW_OR_KEY_NOT_PRESSED; 
}	
#else
/*------------------------------------------------------------*
FUNCTION NAME  : SW_Press_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : When SW is pressed, then dont hold CPU by using sw read level transition; 

Func ID        : 07.07  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Press_Proc(const uint8_t sw_ch_id)
{
	sw_para_t *sw_para_ptr;
	uint8_t ret_status = SW_OR_KEY_NOT_PRESSED;
	
    if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}		
	sw_para_ptr = sw_para + sw_ch_id;
	if( sw_para_ptr->access_flag != STATE_YES) 
	{  
          error_flag = ERR_CUR_DATA_ID_DEV_NO_ACCESS;	
          return  error_flag;
	}
		 
	if(sw_para_ptr->enable_flag != STATE_YES) 
	{  
         error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
         return  error_flag;
	}
		   
			  if((ret_status = SW_Read(sw_ch_id )) != SUCCESS)
			   {
				     ret_status = ERR_SW_NO_READ; 				     
					 return ret_status;
			   }
		     if(sw_para_ptr->sw_cur_state == STATE_KEY_RELEASED  && sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state)
			  {
				      SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY); 
			          if(((ret_status = SW_Read(sw_ch_id )) != SUCCESS))
					  {
						    ret_status = ERR_SW_NO_READ; 	
							return ret_status;		  
					  }
					  if( sw_para_ptr->sw_read_data == sw_para_ptr->sw_pressed_state)
		              { 
			              sw_para_ptr->sw_cur_state = STATE_KEY_PRESSED;
					  }
			  }
              else
			  {
                  if(sw_para_ptr->sw_cur_state == STATE_KEY_PRESSED && sw_para_ptr->sw_read_data != sw_para_ptr->sw_pressed_state)
				  {
					  SW_Time_Delay(MAX_ICOUNT_SW_DEBOUNCE_SW_DELAY, MAX_JCOUNT_SW_DEBOUNCE_SW_DELAY); 
			          if(((ret_status = SW_Read(sw_ch_id )) != SUCCESS))
					  {
						    ret_status = ERR_SW_NO_READ; 	
							return ret_status;		  
					  }
					  if( sw_para_ptr->sw_read_data != sw_para_ptr->sw_pressed_state)
		              { 
			              sw_para_ptr->sw_cur_state = STATE_KEY_RELEASED;
					  }
					  return SUCCESS;
				  }
			  }				  
	return SW_OR_KEY_NOT_PRESSED; 					   
 } 		  
#endif		

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Read

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.08  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Read(const uint8_t sw_ch_id)
{
	uint8_t ret_status = SUCCESS, read_data;
	sw_para_t *cur_sw_para_ptr = NULL_PTR;
	
	 if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}
	 
	 cur_sw_para_ptr = sw_para + sw_ch_id;			
	if((ret_status = IO_Channel_Read(cur_sw_para_ptr->io_ch, &read_data )) != SUCCESS)
	{
		   return ret_status;
	}
	cur_sw_para_ptr->sw_read_data = read_data & 0x01;
	return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_UnConfig_By_IO_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.09  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_UnConfig_By_IO_Ch(const uint8_t io_ch, const uint8_t port_pin_len)
{
	int16_t i = 0;
	uint8_t  sw_ch_id, ret_status;	
		
	for(i = port_pin_len - 1; i >=0 ; --i)
	{		
	    if((ret_status = IO_Ch_To_SW_Ch(io_ch + i, &sw_ch_id)) != SUCCESS)
		{
			error_flag = ERR_IO_CH_UNCONFIG;
		    return error_flag; 
		}
		Reset_SW_Ch(sw_ch_id);		
	}  	
	return SUCCESS;
} 


/*------------------------------------------------------------*
FUNCTION NAME  : Check_And_Alloc_SW_Ch_ID

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.10 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Check_And_Alloc_SW_Ch_ID(const uint8_t ch_id_alloc_type, const uint8_t num_sw_chs, uint8_t *const alloc_start_sw_ch_id_ptr )
{
	consucc_bit_t check_free_sw_ch ;
	uint8_t i, ret_status ;
	
	switch(ch_id_alloc_type)
	{
		case CH_ID_ALLOC_DYNAMIC:		
	      *alloc_start_sw_ch_id_ptr = CH_ID_INVALID;
	      check_free_sw_ch.bits_len = num_sw_chs;
	      check_free_sw_ch.consucc_val = alloc_sw_ch_ids_bit_field;
	      for(i = 0; i < sizeof(alloc_sw_ch_ids_bit_field) * 8; ++i)
	      {
	    	if(Test_Bit_Is_Clear_in_Data( &alloc_sw_ch_ids_bit_field, i) )
	    	{
			    check_free_sw_ch.start_bit_pos = i; 
			    ret_status = Test_Consucc_Bits(FLAG_CONSUCC_BITS_0, &check_free_sw_ch);
			    if(ret_status == TEST_OK_0_CONSUCC_BITS)
			    {
			    	*alloc_start_sw_ch_id_ptr = i;
			    	break;				
			    }
			    else
			    {
				   continue;
			    }
		    }
	     }
	     if(*alloc_start_sw_ch_id_ptr == CH_ID_INVALID)
	     {
	    	error_flag = ERR_SW_CONFIG_DYNAMIC_NOT_ALLOC;
		    return error_flag; 
	     }	
	   break;
	   case CH_ID_ALLOC_FIXED:
	     check_free_sw_ch.start_bit_pos = *alloc_start_sw_ch_id_ptr;
         check_free_sw_ch.bits_len = num_sw_chs;
  		 check_free_sw_ch.consucc_val = alloc_sw_ch_ids_bit_field;
		 ret_status = Test_Consucc_Bits(FLAG_CONSUCC_BITS_0, &check_free_sw_ch);
		 if(ret_status == TEST_OK_0_CONSUCC_BITS)
		 {
		     break;			    				
		 }
		 error_flag = ERR_SW_CONFIG_FIXED_NOT_ALLOC;
		 return error_flag; 
	   //break;
	   default:
	     error_flag = ERR_INVALID_FORMAT;
	     return error_flag;
	}
	check_free_sw_ch.start_bit_pos = *alloc_start_sw_ch_id_ptr;
	check_free_sw_ch.bits_len = num_sw_chs;
	check_free_sw_ch.consucc_val = alloc_sw_ch_ids_bit_field;
    if((ret_status = Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &check_free_sw_ch )) != SUCCESS)
	{
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
	alloc_sw_ch_ids_bit_field =  check_free_sw_ch.consucc_val;
	if( *alloc_start_sw_ch_id_ptr == last_sw_ch_id)
	{
		last_sw_ch_id += num_sw_chs;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_Config_By_Fixed

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.12  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_Config_By_Fixed(uint8_t base_sw_ch_id, const uint8_t num_sw_chs)
{
  	uint8_t ret_status;
	
	if(last_sw_ch_id + num_sw_chs  > NUM_INPUT_DEV_ID_SW_CHS)
	{
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	}
	if((ret_status = Check_And_Alloc_SW_Ch_ID(CH_ID_ALLOC_FIXED, num_sw_chs, &base_sw_ch_id)) != SUCCESS)
	{
		/* if sw ch id alloc is fixed, then already SW is configured to make map sw_io_ch to sw_ch_id available, 
		   before SW_Ch_Config_By_Fixed() is called, so it is neccessary to SW Unconfig if Check_And_Alloc_SW_Ch_ID() fails */		
		SW_Ch_UnConfig(base_sw_ch_id, num_sw_chs);
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
       
	return SUCCESS;
}

 /*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_UnConfig

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.13  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_UnConfig(const uint8_t base_sw_ch_id, const uint8_t num_sw_chs)
{
	int16_t i = 0;
	uint8_t ret_status;	
		
	for(i = num_sw_chs - 1; i >=0 ; --i)
	{		
	   	Reset_SW_Ch(base_sw_ch_id + i);		
	}  	
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Disable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.14  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t SW_Disable(const uint8_t sw_ch_id)
{
	 sw_para_t *cur_sw_para_ptr = NULL_PTR;
	
	  if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}
	 cur_sw_para_ptr = sw_para + sw_ch_id ;  
     cur_sw_para_ptr->enable_flag = STATE_NO;
	 
   return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : SW_Enable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.15  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t SW_Enable(const uint8_t sw_ch_id)
{
	  sw_para_t *cur_sw_para_ptr = NULL_PTR;
	
	  if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}
	 cur_sw_para_ptr = sw_para + sw_ch_id ;  
     cur_sw_para_ptr->enable_flag = STATE_YES;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_SWs

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.16  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_SWs(void)
{
	 uint8_t sw_ch_id =0;
	
	 for(sw_ch_id = 0; sw_ch_id < NUM_INPUT_DEV_ID_SW_CHS; ++sw_ch_id)
	 {
		   SW_Disable(sw_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.17 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t SW_Allow_Access(const uint8_t sw_ch_id)
{
	  sw_para_t *cur_sw_para_ptr = NULL_PTR;
	
	 if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}
	 cur_sw_para_ptr = sw_para + sw_ch_id ;  
     cur_sw_para_ptr->access_flag = STATE_YES;
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.18 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t SW_No_Access(const uint8_t sw_ch_id)
{
	 sw_para_t *cur_sw_para_ptr = NULL_PTR;
	
	 if(sw_ch_id >= last_sw_ch_id)
	{
		error_flag = ERR_MAX_SW_CH_EXCEEDS;
		return error_flag;
	}
	 cur_sw_para_ptr = sw_para + sw_ch_id ;  
   cur_sw_para_ptr->access_flag = STATE_NO;
   SW_Disable(sw_ch_id);
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.19 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t SW_Init(const uint8_t sw_ch_id)
{
	 sw_para_t *cur_sw_para_ptr = NULL_PTR;
	 io_config_t sw_config;	 
	 uint8_t ret_status = SUCCESS, alloc_start_sw_ch_id, i ;	
	 
	 if(sw_ch_id >= NUM_INPUT_DEV_ID_SW_CHS )
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_sw_para_ptr = sw_para + sw_ch_id;   
     sw_config.io_ch = cur_sw_para_ptr->io_ch;
	 sw_config.port_pin_len = 1;
	 sw_config.signal = PIN_SIG_DIGITAL;
	 sw_config.dir = IO_DIR_INPUT;
	 sw_config.func = IO_FUNC_GPIO;
	 sw_config.state = cur_sw_para_ptr->sw_pressed_state;
	 sw_config.func_type = IO_FUNC_TYPE_GPIO_SW;
	 sw_config.ch_id_alloc_type = CH_ID_ALLOC_FIXED;
	 alloc_start_sw_ch_id = sw_ch_id;
	 for(i = 0 ; i < sw_config.port_pin_len; ++i, ++alloc_start_sw_ch_id )	
	 {
   	    sw_para[alloc_start_sw_ch_id].io_ch = (sw_para + sw_ch_id)->io_ch + i;
  	    sw_para[alloc_start_sw_ch_id].access_flag = STATE_NO;
		sw_para[alloc_start_sw_ch_id].enable_flag = STATE_NO;
  	    sw_para[alloc_start_sw_ch_id].sw_cur_state = STATE_KEY_RELEASED; 
 		sw_para[alloc_start_sw_ch_id].sw_pressed_state = (sw_para + sw_ch_id)->sw_pressed_state;		
	 }
	 if((ret_status = IO_Channels_Func_Set(&sw_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	 return SUCCESS; 	
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_DeInit

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.20 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t SW_DeInit(const uint8_t sw_ch_id)
{
	 io_config_t sw_unconfig;
	 sw_para_t *cur_sw_para_ptr = NULL_PTR;
	 uint8_t ret_status = SUCCESS ;	
	 
	 if(sw_ch_id >= last_sw_ch_id)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_sw_para_ptr = sw_para + sw_ch_id;
	 
	 SW_No_Access(sw_ch_id);
	 sw_unconfig.io_ch  = cur_sw_para_ptr->io_ch;
	 sw_unconfig.port_pin_len = 1;	 
	 sw_unconfig.func = IO_FUNC_GPIO;
	 sw_unconfig.dir = IO_DIR_INPUT;
	 sw_unconfig.func_type = IO_FUNC_TYPE_GPIO_SW;
	 sw_unconfig.ch_id_alloc_type = CH_ID_ALLOC_FIXED;
	 if((ret_status = IO_Ch_Func_Reset(&sw_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }	 	 
	 return SUCCESS;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
