/**************************************************************************
   FILE          :    dev_chs_map.h
 
   PURPOSE       :   
 
   AUTHOR        :   K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _DEV_CHS_MAP_H
 #define _DEV_CHS_MAP_H
 
 #ifdef KEYPAD_MOD_ENABLE
 //                                                 IO_CH_ROWA,     IO_CH_COL1,   KEYBOARD_ACCESS, KEYBOARD_ENABLE, KEYS_ENABLE, PRESSED_STATE                                           
keyboard_ctrl_t keyboard_ctrl[]  = {  
	                                         { IO_CH_KEYPAD_CH_00_ROWA, IO_CH_KEYPAD_CH_00_COL1, STATE_NO, STATE_NO,  STATE_NO, STATE_LOW }											 
                                   };
#endif

#ifdef SEG7_MOD_ENABLE
//                            IO_CH_A_LED,           IO_CH_UNIT_DIGIT,             ACCESS, ENABLE,       TYPE      ,      NUM_DIGITS            											 
seg7_ctrl_t seg7_ctrl[] = {
                            { IO_CH_SEG7_CH_00_A_LED, IO_CH_SEG7_CH_00_UNIT_DIGIT, STATE_NO, STATE_NO, SEG7_COMMON_ANODE, SEG7_4_DIGIT }
                          };
#endif
						  
#ifdef LED_MATRIX_MOD_ENABLE
//                                         IO_CH_ROWA,                       IO_CH_COL1,   LED_MATRIX_ACCESS, LED_MATRIX_ENABLE,  TYPE         , FONT_TYPE,      SCAN_TYPE
 led_matrix_ctrl_t led_matrix_ctrl[] = {
	                                       {IO_CH_LED_MATRIX_CH_00_ROWA, IO_CH_LED_MATRIX_CH_00_COL1, STATE_NO, STATE_NO,  ROW_CATHODE_TYPE, FONT_SIZE_5_7, ROW_SCAN }
                                       };
#endif
 
#ifdef  SW_MOD_ENABLE
//                                          IO_CH,      SW_ACCESS, SW_ENABLE,  PRESSED_STATE
  sw_para_t sw_para[ NUM_INPUT_DEV_ID_SW_CHS] =                            
                                       {
										   {IO_CH_SW_CH_00, STATE_NO, STATE_NO, STATE_LOW},
										   {IO_CH_SW_CH_01, STATE_NO, STATE_NO, STATE_LOW} 
                                       };	  
#endif

#ifdef LCD_MOD_ENABLE
//                                  IO_CH_CMD,           IO_CH_DATA,      LCD_ACCESS,  LCD_ENABLE,   INTERFACE,               FONT,         BUSY_FLAG
   lcd_ctrl_t lcd_ctrl[] = 
                              { 
                                  {IO_CH_LCD_CH_00_CMD, IO_CH_LCD_CH_00_DATA, STATE_NO, STATE_NO, DATA_INTERFACE_8_BITS, CHAR_FONT_5_8_DOTS, CHECK_BUSY_FLAG,
								  
//                                MAX_AVAIL_LINES,     MAX_CONFIG_LINES,    MAX_AVAIL_COLS,     MAX_CONFIG_COLS  
                                     (4 - 1) ,                 (4 - 1),          (20 - 1),           (20 - 1)                                                                                      
	                              }
                              };    										 
#endif


#endif
																					
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
																		
