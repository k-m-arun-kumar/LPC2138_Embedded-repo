/**************************************************************************
   FILE          :    lcd.c
 
   PURPOSE       :   LCD library 
 
   AUTHOR        :  K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 09  
	   
 **************************************************************************/

#include "main.h"

#ifdef LCD_MOD_ENABLE

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */
lcd_status_t lcd_status[NUM_OUTPUT_DEV_ID_LCD_CHS];

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t Check_LCD_Busy(const uint8_t lcd_ch_id);

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.01

BUGS           :    
-*------------------------------------------------------------*/
uint8_t LCD_Init(const uint8_t lcd_ch_id)
{
	lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	io_config_t lcd_config;
	uint32_t lcd_func_command = 0x20;	
	uint8_t ret_status;
  
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;	
	if(cur_lcd_ctrl_ptr->max_config_lines > cur_lcd_ctrl_ptr->max_avail_lines || cur_lcd_ctrl_ptr->max_config_cols > cur_lcd_ctrl_ptr->max_avail_cols)
	{
		 error_flag = ERR_LCD_CONFIG_INVALID;
		 return error_flag;
	}
     lcd_config.io_ch = cur_lcd_ctrl_ptr->base_io_ch_ctrl;
	 lcd_config.signal = PIN_SIG_DIGITAL;
	 lcd_config.func = IO_FUNC_GPIO;
	 lcd_config.dir = IO_DIR_OUTPUT;
	 lcd_config.state = STATE_LOW;
	 lcd_config.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 lcd_config.port_pin_len = 3;	 
	 if((ret_status = IO_Channels_Func_Set(&lcd_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }
	  lcd_config.io_ch = cur_lcd_ctrl_ptr->base_io_ch_data;
	  if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_8_BITS)
	  {
          lcd_config.port_pin_len = 8;
	  }
      else
	  {		  
	      lcd_config.port_pin_len = 4;
	  }	  
	 if((ret_status = IO_Channels_Func_Set(&lcd_config)) != SUCCESS)
	 {
		error_flag = ERR_GPIO_FUNC_SET;
		return error_flag;
	 }			
	/* wait for more than 15ms after LCD VSS rises to 4.5V, Busy Flag in LCD (BF) cannot be checked */
	SW_Time_Delay(MAX_ICOUNT_LCD_1500MS, MAX_JCOUNT_LCD_1500MS);
    Write_LCD_Command_NO_BF(lcd_ch_id, 0x30);
	/* wait for more than 4.1 ms, Busy Flag in LCD (BF) cannot be checked */
	SW_Time_Delay(MAX_ICOUNT_LCD_10MS, MAX_JCOUNT_LCD_10MS);
    Write_LCD_Command_NO_BF(lcd_ch_id, 0x30);
	/* wait for more than 100 us, Busy Flag in LCD (BF) cannot be checked */
	SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
    Write_LCD_Command_NO_BF(lcd_ch_id, 0x30);
	SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_4_BITS)
	{		
	   Write_LCD_Command_NO_BF(lcd_ch_id, 0x20); 
	}	
    Write_Bit_in_Data(&lcd_func_command , 4, cur_lcd_ctrl_ptr->interface);
	if(cur_lcd_ctrl_ptr->max_config_lines + 1 == NUM_LINE1)
	{
	    Write_Bit_in_Data(&lcd_func_command , 3, MAX_DISP_NUM_LINES_1);
	}
	else
	{
		 Write_Bit_in_Data(&lcd_func_command , 3, MAX_DISP_NUM_LINES_ALL);
	}
	Write_Bit_in_Data(&lcd_func_command , 2, cur_lcd_ctrl_ptr->font);
	Write_LCD_Command(lcd_ch_id, lcd_func_command);   	
    Write_LCD_Command(lcd_ch_id, 0x08);
	LCD_Clear_Screen(lcd_ch_id);
	Write_LCD_Command(lcd_ch_id, 0x06);  
	Write_LCD_Command(lcd_ch_id, 0x0E);
	lcd_status[lcd_ch_id].cur_disp_lcd_loc = BEGIN_LOC_LINE1;
	lcd_status[lcd_ch_id].cur_input_lcd_loc = BEGIN_LOC_LINE2;
	return SUCCESS;
} 
/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Clear_Screen

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.02

BUGS           :  
-*------------------------------------------------------------*/
uint8_t LCD_Clear_Screen(const uint8_t lcd_ch_id)
{
	Write_LCD_Command(lcd_ch_id, 0x01);
	//__delay_us(LCD_CLEAR_EXEC_IN_USEC);	
	SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	return SUCCESS;
}
 
/*------------------------------------------------------------*
FUNCTION NAME  : Write_LCD_Command_NO_BF

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.03

BUGS           :   
-*------------------------------------------------------------*/
uint8_t Write_LCD_Command_NO_BF(const uint8_t lcd_ch_id, const uint8_t lcd_cmd)
{
   lcd_ctrl_t *cur_lcd_ctrl_ptr;
   consucc_bit_t lcd_port_data;
   uint8_t ret_status, io_ch_D4_pin = 0;
  
   cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;   
   //LCD_RW_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 1, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   }	   
   
   //LCD_RS_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   } 
   
   //__delay_us(LCD_ADDR_SETUP_IN_USEC);   
   SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
   //  LCD_EN_PIN = 1;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   } 	
   // __delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
    SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	
	lcd_port_data.bits_len  = 4;
	lcd_port_data.consucc_val = lcd_cmd >> 4;
	if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_8_BITS)
	{
		io_ch_D4_pin = 4;
	}
	 lcd_port_data.start_bit_pos  = (cur_lcd_ctrl_ptr->base_io_ch_data + io_ch_D4_pin) % NUM_PINS_PER_PORT;
     if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data + io_ch_D4_pin, &lcd_port_data)) != SUCCESS) 
	 {
		  error_flag = ERR_LCD_WRITE;
	      return error_flag;
	 }
  
    //__delay_us(LCD_DATA_SETUP_IN_USEC);
	SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
   // LCD_EN_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   }
    //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 
    SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
    return SUCCESS;	     
}
/*------------------------------------------------------------*
FUNCTION NAME  : Write_LCD_Command

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.04

BUGS           :   
-*------------------------------------------------------------*/
uint8_t Write_LCD_Command(const uint8_t lcd_ch_id, const uint8_t lcd_cmd)
{
    lcd_ctrl_t *cur_lcd_ctrl_ptr; 
	consucc_bit_t lcd_port_data;
	uint8_t ret_status;
  
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	
	if(cur_lcd_ctrl_ptr->check_bf == CHECK_BUSY_FLAG)
	{
		Check_LCD_Busy(lcd_ch_id); 
	}
    else
	{
		SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	
	}		
   //LCD_RW_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 1, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   }	   
   //LCD_RS_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   }    
     // __delay_us(LCD_ADDR_SETUP_IN_USEC); 
     SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	 
    //LCD_EN_PIN = 1;
	if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
    {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
    } 	
    //__delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
	 SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	 
	 if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_4_BITS)
	{
	    lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	    lcd_port_data.bits_len  = 4;
	    lcd_port_data.consucc_val = lcd_cmd >> 4;
		if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS) 
	    {
		   error_flag = ERR_LCD_WRITE;
	       return error_flag;
	    }
        //__delay_us(LCD_DATA_SETUP_IN_USEC);
		SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
       // LCD_EN_PIN = 0;
	    if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
        {
	        error_flag = ERR_LCD_WRITE;
	        return error_flag;
        } 	
	    //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 	 
        SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
        //__delay_us(LCD_ADDR_SETUP_IN_USEC);   
		 SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
        //LCD_EN_PIN = 1;
		if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
        {
	        error_flag = ERR_LCD_WRITE;
	        return error_flag;
        } 
		//  __delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
		SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	    lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	    lcd_port_data.bits_len  = 4;
	    lcd_port_data.consucc_val = lcd_cmd & 0x0F;
		if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS) 
	    {
		   error_flag = ERR_LCD_WRITE;
	       return error_flag;
	    }
	}
    else
	{	
        lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	    lcd_port_data.bits_len  = 8;
	    lcd_port_data.consucc_val = lcd_cmd;
		if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS) 
	    {
		   error_flag = ERR_LCD_WRITE;
	       return error_flag;
	    }
	}
	 //__delay_us(LCD_DATA_SETUP_IN_USEC);
	 SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
    // LCD_EN_PIN = 0;
    if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
    {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
    }
    //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 
    SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
    return SUCCESS;	      
}
/*------------------------------------------------------------*
FUNCTION NAME  : Write_LCD_Data

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.05

BUGS           :  
-*------------------------------------------------------------*/
 uint8_t Write_LCD_Data(const uint8_t lcd_ch_id, const char lcd_data)
{
	lcd_ctrl_t *cur_lcd_ctrl_ptr; 
	consucc_bit_t lcd_port_data;
	uint8_t ret_status;
  
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	
	if(cur_lcd_ctrl_ptr->check_bf == CHECK_BUSY_FLAG)
	{
		Check_LCD_Busy(lcd_ch_id); 
	}
	else
	{
		SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	
	}
	//LCD_RW_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 1, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   }	   
   //LCD_RS_PIN = 1;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl, STATE_HIGH)) != SUCCESS)
   {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
   } 	
	// __delay_us(LCD_ADDR_SETUP_IN_USEC); 
     SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	 
    //LCD_EN_PIN = 1;
	if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
    {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
    } 	
    //__delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
	 SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	 
	 if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_4_BITS)
	{
	    lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	    lcd_port_data.bits_len  = 4;
	    lcd_port_data.consucc_val = lcd_data >> 4;
		if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS) 
	    {
		   error_flag = ERR_LCD_WRITE;
	       return error_flag;
	    }
        //__delay_us(LCD_DATA_SETUP_IN_USEC);
		SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
       // LCD_EN_PIN = 0;
	    if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
        {
	        error_flag = ERR_LCD_WRITE;
	        return error_flag;
        } 	
	    //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 	 
        SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
        //__delay_us(LCD_ADDR_SETUP_IN_USEC);   
		 SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
        //LCD_EN_PIN = 1;
		if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
        {
	        error_flag = ERR_LCD_WRITE;
	        return error_flag;
        } 
		//  __delay_us(LCD_ENABLE_PULSE_BEFORE_WRITE_IN_USEC);
		SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	    lcd_port_data.consucc_val = lcd_data & 0x0F;
		if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS) 
	    {
		   error_flag = ERR_LCD_WRITE;
	       return error_flag;
	    }
	}
    else
	{	
        lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	    lcd_port_data.bits_len  = 8;
	    lcd_port_data.consucc_val = lcd_data;
		if((ret_status = Port_Write(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS) 
	    {
		   error_flag = ERR_LCD_WRITE;
	       return error_flag;
	    }
	}
	 //__delay_us(LCD_DATA_SETUP_IN_USEC);
	 SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
    // LCD_EN_PIN = 0;
    if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
    {
	   error_flag = ERR_LCD_WRITE;
	   return error_flag;
    }
    //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 
    SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
    return SUCCESS;	      
}

/*------------------------------------------------------------*
FUNCTION NAME  : Check_LCD_Busy

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.06

BUGS           :   
-*------------------------------------------------------------*/
static uint8_t Check_LCD_Busy(const uint8_t lcd_ch_id)
{
  lcd_ctrl_t *cur_lcd_ctrl_ptr;
  io_config_t lcd_config;
   uint8_t lcd_read_command, ret_status;
	
    //LCD_RW_PIN = 1;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 1, STATE_HIGH)) != SUCCESS)
   {
	   error_flag = ERR_LCD_READ;
	   return error_flag;
   }	   
   //LCD_RS_PIN = 0;
   if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl, STATE_LOW)) != SUCCESS)
   {
	   error_flag = ERR_LCD_READ;
	   return error_flag;
   } 		
    cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	lcd_config.io_ch = cur_lcd_ctrl_ptr->base_io_ch_data;
	lcd_config.signal = PIN_SIG_DIGITAL;
	lcd_config.func = IO_FUNC_GPIO;
	lcd_config.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_8_BITS)
	{
        lcd_config.port_pin_len = 8;
	}
    else
	{		  
	   lcd_config.port_pin_len = 4;
	}	
	 
	if((ret_status = IO_Ch_Func_Reset(&lcd_config)) != SUCCESS)
	{
	   error_flag = ERR_IO_CH_FUNC_RESET;
       return error_flag;		
	}
	lcd_config.dir = IO_DIR_INPUT;
	if((ret_status = IO_Channels_Func_Set(&lcd_config)) != SUCCESS)
	{
	  	error_flag = ERR_GPIO_FUNC_SET;
	    return error_flag;
	}
	
	// send higher nibble first and higher data nibble of LCD PORT must be connected to LCD 	 
     /* busy flag = Bit 7 in LCD PORT, if busy flag == 1, wait till busy flag = 0, then any operation on LCD can be done */
    do
	{
		if((ret_status = Read_LCD_Command(lcd_ch_id, &lcd_read_command)) != SUCCESS)
		{
			error_flag = ERR_LCD_READ;
			return error_flag;
		}
    }
	while(Test_Bit_Is_Set_in_Data(&lcd_read_command, 7 ));	
	if((ret_status = IO_Ch_Func_Reset(&lcd_config)) != SUCCESS)
	{
	   error_flag = ERR_IO_CH_FUNC_RESET;
       return error_flag;		
	}
	lcd_config.dir = IO_DIR_OUTPUT;
	lcd_config.state = STATE_LOW;
	if((ret_status = IO_Channels_Func_Set(&lcd_config)) != SUCCESS)
	{
	  	error_flag = ERR_GPIO_FUNC_SET;
	    return error_flag;
	}
	return SUCCESS;
   	   
}
/*------------------------------------------------------------*
FUNCTION NAME  : Read_LCD_Command

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.07

BUGS           : 
-*------------------------------------------------------------*/
static uint8_t Read_LCD_Command(const uint8_t lcd_ch_id, uint8_t *const lcd_read_command_ptr)
{
	lcd_ctrl_t *cur_lcd_ctrl_ptr;
	consucc_bit_t lcd_port_data;	 
	uint8_t ret_status;
  
	if(lcd_read_command_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
	// __delay_us(LCD_ADDR_SETUP_IN_USEC);  
    SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);	 
    //LCD_EN_PIN = 1;
	if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
    {
	   error_flag = ERR_LCD_READ;
	   return error_flag;
    } 	        
	if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_4_BITS)
	{ 
        lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	    lcd_port_data.bits_len  = 4;
		  lcd_port_data.consucc_val = 0;
	    if((ret_status = Port_Read(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS)
		{
			error_flag = ERR_LCD_READ;
			return error_flag;
		}        
	    //LCD_EN_PIN = 0;		
	    if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
        {
	       error_flag = ERR_LCD_READ;
	       return error_flag;
        } 	
	     *lcd_read_command_ptr = (uint8_t)lcd_port_data.consucc_val << 4;	 
	     //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 
		  SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
		 
	     //__delay_us(LCD_ADDR_SETUP_IN_USEC);
		  SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
        //  LCD_EN_PIN = 1;
		 if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_HIGH)) != SUCCESS)
         {
	        error_flag = ERR_LCD_READ;
	        return error_flag;
         } 	
		 lcd_port_data.consucc_val = 0;
	     // read lower nibble and higher port nibble of LCD PORT is connected to LCD(DB4 - DB7)	
		 if((ret_status = Port_Read(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS)
		{
			error_flag = ERR_LCD_READ;
			return error_flag;
		}
         
	     //LCD_EN_PIN = 0;
		 if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
        {
	       error_flag = ERR_LCD_READ;
	       return error_flag;
        } 
		 
	    //__delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 
		  SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	    *lcd_read_command_ptr = *lcd_read_command_ptr | ( (uint8_t)lcd_port_data.consucc_val & 0x0Fu);
	 }
	 else
	 {
		 lcd_port_data.start_bit_pos  = cur_lcd_ctrl_ptr->base_io_ch_data % NUM_PINS_PER_PORT;
	     lcd_port_data.bits_len  = 8;
		 lcd_port_data.consucc_val = 0;
	     if((ret_status = Port_Read(cur_lcd_ctrl_ptr->base_io_ch_data, &lcd_port_data)) != SUCCESS)
		 {
			error_flag = ERR_LCD_READ;
			return error_flag;
		 }
		  *lcd_read_command_ptr  = (uint8_t) lcd_port_data.consucc_val;
	      //LCD_EN_PIN = 0;
		  if((ret_status = IO_Channel_Write(cur_lcd_ctrl_ptr->base_io_ch_ctrl + 2, STATE_LOW)) != SUCCESS)
          {
	         error_flag = ERR_LCD_READ;
	         return error_flag;
          } 
		  // __delay_us(LCD_OTHER_INST_EXEC_IN_USEC); 
		  SW_Time_Delay(MAX_ICOUNT_LCD_1MS, MAX_JCOUNT_LCD_1MS);
	 }	 
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Disp_Str

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.08

BUGS           :   
-*------------------------------------------------------------*/
uint8_t LCD_Disp_Str(const uint8_t lcd_ch_id, const char *const char_ptr)
{ 
      char cur_char;
	    uint8_t num_char = 0;
  
	   if(char_ptr == NULL_PTR)
	   {
		   error_flag = ERR_NULL_PTR;
		   return error_flag;
	   }
	   
	   if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	   {
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	   }
       while(*(char_ptr + num_char))
       {
		    cur_char = *(char_ptr + num_char);
            Write_LCD_Data(lcd_ch_id, cur_char);
            ++num_char;        
       }
	   
	   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Set_Cur_Loc_LCD

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.10

BUGS           :  
-*------------------------------------------------------------*/
/* make sure that loc are within avail lcd loc limit */
void Set_Cur_Loc_LCD(const uint8_t lcd_ch_id, const char set_input_loc_flag, const uint8_t set_input_loc, const char set_disp_loc_flag, const uint8_t set_disp_loc)
{
    if(set_input_loc_flag == STATE_YES_IN_CHAR)  
       lcd_status[lcd_ch_id].cur_input_lcd_loc = set_input_loc;
   if(set_disp_loc_flag == STATE_YES_IN_CHAR)
      lcd_status[lcd_ch_id].cur_disp_lcd_loc = set_disp_loc; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Goto_XY_LCD_Disp

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : max 4 lines and 20 columns

Func ID        : 09.11

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Goto_XY_LCD_Disp(const uint8_t lcd_ch_id, const uint8_t start_line_num, const uint8_t start_col_num)
{
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
	lcd_ctrl_t *cur_lcd_ctrl_ptr; 
	lcd_status_t *cur_lcd_status_ptr;
	lcd_point_t start_lcd_disp_uC;
	
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	cur_lcd_status_ptr = lcd_status + lcd_ch_id;
	start_lcd_disp_uC.line = start_line_num - 1;
	start_lcd_disp_uC.col = start_col_num - 1; 	
   if(start_lcd_disp_uC.line > cur_lcd_ctrl_ptr->max_config_lines || start_lcd_disp_uC.col > cur_lcd_ctrl_ptr->max_config_cols )
   {
	   /* error due to invalid lcd DISP loc  */
	     error_flag = ERR_LCD_INVALID_LOC;
		 return error_flag;
   }
     switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_lcd_status_ptr->cur_disp_lcd_loc = BEGIN_LOC_LINE1;
		 break;
		 case NUM_LINE2:
		   cur_lcd_status_ptr->cur_disp_lcd_loc = BEGIN_LOC_LINE2;
		 break;
		 case NUM_LINE3:
		   cur_lcd_status_ptr->cur_disp_lcd_loc = BEGIN_LOC_LINE3;
		 break;
		 case NUM_LINE4:
		   cur_lcd_status_ptr->cur_disp_lcd_loc = BEGIN_LOC_LINE4;
		 break;         		 
	 }	
      cur_lcd_status_ptr->cur_disp_lcd_loc += start_lcd_disp_uC.col;
      Write_LCD_Command(lcd_ch_id, cur_lcd_status_ptr->cur_disp_lcd_loc);       
    return SUCCESS;   
} 

 /*------------------------------------------------------------*
FUNCTION NAME  : Goto_XY_LCD_Input

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : max 4 lines and 20 columns

Func ID        : 09.12

BUGS           :    
-*------------------------------------------------------------*/ 
uint8_t Goto_XY_LCD_Input(const uint8_t lcd_ch_id, const uint8_t start_line_num, const uint8_t start_col_num)
{
	lcd_ctrl_t *cur_lcd_ctrl_ptr; 
	lcd_status_t *cur_lcd_status_ptr;
	/* for us, lcd line starts from 1, but for uC, line starts from 0 */
	/* for us, lcd col starts from 1, but for uC, col starts from 0 */
	lcd_point_t start_lcd_input_uC;    
	
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	cur_lcd_status_ptr = lcd_status + lcd_ch_id;
  start_lcd_input_uC.line = start_line_num - 1;
	start_lcd_input_uC.col = start_col_num - 1;
	if(start_lcd_input_uC.line > cur_lcd_ctrl_ptr->max_config_lines || start_lcd_input_uC.col > cur_lcd_ctrl_ptr->max_config_cols )
   {
	   /* error due to invalid lcd DISP loc  */
	     error_flag = ERR_LCD_INVALID_LOC;
		 return error_flag;
   }
	 switch(start_line_num)
	 {
		 case NUM_LINE1:
		   cur_lcd_status_ptr->cur_input_lcd_loc = BEGIN_LOC_LINE1;
		 break;
		 case NUM_LINE2:
		   cur_lcd_status_ptr->cur_input_lcd_loc = BEGIN_LOC_LINE2;
		 break;
		 case NUM_LINE3:
		   cur_lcd_status_ptr->cur_input_lcd_loc = BEGIN_LOC_LINE3;
		 break;
		 case NUM_LINE4:
		    cur_lcd_status_ptr->cur_input_lcd_loc = BEGIN_LOC_LINE4;
		 break; 		  
	 }
	 cur_lcd_status_ptr->cur_input_lcd_loc += start_lcd_input_uC.col;
     Write_LCD_Command(lcd_ch_id, cur_lcd_status_ptr->cur_input_lcd_loc); 	 	   
  
    return SUCCESS;
} 

 /*------------------------------------------------------------*
FUNCTION NAME  : From_XY_To_Loc_LCD

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :  max 4 lines and 20 columns

Func ID        : 09.13

BUGS           :  
-*------------------------------------------------------------*/
uint8_t From_XY_To_Loc_LCD(const uint8_t lcd_ch_id, const lcd_point_t *const start_lcd_point_ptr, uint8_t *const lcd_loc)
{
	lcd_ctrl_t *cur_lcd_ctrl_ptr; 
	lcd_point_t start_lcd_uC;
	
	if(lcd_loc == NULL_PTR || start_lcd_point_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}	
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	start_lcd_uC.line = start_lcd_point_ptr->line - 1;
	start_lcd_uC.col = start_lcd_point_ptr->col - 1;
	if(start_lcd_uC.line > cur_lcd_ctrl_ptr->max_config_lines || start_lcd_uC.col > cur_lcd_ctrl_ptr->max_config_cols )
   {
	     error_flag = ERR_LCD_INVALID_LOC;
		 return error_flag;
   }
     switch(start_lcd_point_ptr->line)
	 {
		 case NUM_LINE1:
		   *lcd_loc = BEGIN_LOC_LINE1;
		   break;
		 case NUM_LINE2:
		   *lcd_loc = BEGIN_LOC_LINE2;
		   break;
		 case NUM_LINE3:
		   *lcd_loc= BEGIN_LOC_LINE3;
		   break;
		  case NUM_LINE4:
		  *lcd_loc = BEGIN_LOC_LINE4;
		   break;		 
	 }	
      *lcd_loc = *lcd_loc + start_lcd_uC.col;           
    return SUCCESS;   
} 

/*------------------------------------------------------------*
FUNCTION NAME  : From_Loc_to_XY_LCD

DESCRIPTION    : loc_lcd's corrosponding line num and col num 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.14

BUGS           :   
-*------------------------------------------------------------*/
uint8_t From_Loc_to_XY_LCD(const uint8_t lcd_ch_id, const uint8_t loc_lcd, lcd_point_t *const lcd_point_ptr)
{
	lcd_ctrl_t *cur_lcd_ctrl_ptr; 
	uint8_t ret_status = SUCCESS;
	
	if(lcd_point_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
	if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		 error_flag = ERR_DEV_CH_ID_EXCEEDS;
		 return error_flag;
	}
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;
	if(loc_lcd >= BEGIN_LOC_LINE1 && loc_lcd <= END_LOC_LINE1)
	{
	    lcd_point_ptr->line = NUM_LINE1;
	    lcd_point_ptr->col = loc_lcd + 1 - BEGIN_LOC_LINE1;	
        goto LOC_TO_XY_EXIT;	    
	}
    if(loc_lcd >= BEGIN_LOC_LINE2 && loc_lcd <= END_LOC_LINE2)
	{
	    lcd_point_ptr->line	= NUM_LINE2;
		lcd_point_ptr->col =  loc_lcd + 1 - BEGIN_LOC_LINE2; 
        goto LOC_TO_XY_EXIT;		
	}     
	if(loc_lcd >= BEGIN_LOC_LINE3 && loc_lcd <= END_LOC_LINE3)
	{
	    lcd_point_ptr->line = NUM_LINE3;
	  	lcd_point_ptr->col = loc_lcd + 1 - BEGIN_LOC_LINE3;
        goto LOC_TO_XY_EXIT; 		
	}
    if(loc_lcd >= BEGIN_LOC_LINE4 && loc_lcd <= END_LOC_LINE4)
	{
		lcd_point_ptr->line = NUM_LINE4;
		lcd_point_ptr->col = loc_lcd + 1 - BEGIN_LOC_LINE4;
		goto LOC_TO_XY_EXIT;
	}
    error_flag = ERR_LCD_INVALID_LOC; 
	ret_status = error_flag;
 	LOC_TO_XY_EXIT: 
	if(ret_status == SUCCESS)
	{
		if((lcd_point_ptr->line - 1) > cur_lcd_ctrl_ptr->max_config_lines || (lcd_point_ptr->col - 1) > cur_lcd_ctrl_ptr->max_config_cols )
		{
			 error_flag = ERR_LCD_INVALID_LOC; 
	         return error_flag;
		}
	}
    return ret_status;   
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Write

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.15

BUGS           :   
-*------------------------------------------------------------*/
uint8_t LCD_Write(const uint8_t lcd_ch_id, const void *const lcd_rcv_disp_num_ptr)
{
	uint32_t base_power_val, lcd_disp_num;
    data_value_ptr_with_type_t *lcd_data_write_ptr;	
    lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	char *lcd_str_ptr;
	output_data_ctrl_para_t *lcd_disp_ctrl_ptr; 
	uint8_t ret_status = SUCCESS, base, place_digit[MAX_LCD_DIGITS];
  int8_t place_val;
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
	
    if(lcd_rcv_disp_num_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
    if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	{
		   error_flag = ERR_DEV_CH_ID_EXCEEDS;
		   return error_flag;
	}	
	
	cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id;    
	if(  cur_lcd_ctrl_ptr->access_flag != STATE_YES) 
	{  
        error_flag = ERR_CUR_DATA_ID_DEV_NO_ACCESS;	
        return  error_flag;
	}		 
	   if( cur_lcd_ctrl_ptr->enable_flag != STATE_YES) 
	   {  
          error_flag = ERR_CUR_DATA_ID_DEV_DISABLED;	
          return  error_flag;
	   }
     
     lcd_data_write_ptr  = (data_value_ptr_with_type_t *)lcd_rcv_disp_num_ptr;
	 switch(lcd_data_write_ptr->data_type)
	 {
		case DATA_TYPE_IN_STR:
		   lcd_str_ptr = lcd_data_write_ptr->data_value_ptr->data_str;
		   LCD_Disp_Str(lcd_ch_id, lcd_str_ptr);
		break;
		case DATA_TYPE_IN_CHAR:
		   lcd_str_ptr = lcd_data_write_ptr->data_value_ptr->data_str + lcd_data_write_ptr->data_value_ptr->data_str_len_or_pos;
		   Write_LCD_Data(lcd_ch_id, *lcd_str_ptr);
		break;
		case DATA_TYPE_IN_BINARY:	
      	base = 2;					
        break;			
		case DATA_TYPE_IN_HEXA:
		    base = 16;		
		case DATA_TYPE_IN_DECIMAL:
		    base = 10;		  	   
		break;  
		case DATA_TYPE_IN_APPL_DEFINED:
		break;
		default:
		   error_flag = ERR_DATA_TYPE_INVALID;
		   return error_flag;
	}
	switch(lcd_data_write_ptr->data_type) 
	{
       case DATA_TYPE_IN_BINARY:
       case DATA_TYPE_IN_HEXA:
       case DATA_TYPE_IN_DECIMAL: 
          lcd_disp_ctrl_ptr = ((output_data_ctrl_para_t *)lcd_data_write_ptr->data_ctrl_para_ptr); 	   
	     if(lcd_disp_ctrl_ptr->disp_num.num_digits <= 0 || lcd_disp_ctrl_ptr->disp_num.num_digits > MAX_LCD_DIGITS)
		 {
		    error_flag = ERR_INVALID_FORMAT;
            return error_flag;
		 }
         if(lcd_disp_ctrl_ptr->disp_num.sign_flag == STATE_YES)
		 {
			 if(lcd_data_write_ptr->data_value_ptr->data_num.val_int_32[0] < 0)
			 {
			  	Write_LCD_Data(lcd_ch_id, '-');
			    lcd_disp_num = -lcd_data_write_ptr->data_value_ptr->data_num.val_int_32[0]; 
			 }
			 else
			 {
			  	Write_LCD_Data(lcd_ch_id, '+');
			    lcd_disp_num = lcd_data_write_ptr->data_value_ptr->data_num.val_int_32[0];  
			 }
		 }
         else
		 {
			 lcd_disp_num = lcd_data_write_ptr->data_value_ptr->data_num.val_int_32[0]; 
		 }			 
	     base_power_val =  Power_Of(base, lcd_disp_ctrl_ptr->disp_num.num_digits);
		 for(place_val =  lcd_disp_ctrl_ptr->disp_num.num_digits; place_val >= 1; --place_val)
		 {
		     lcd_disp_num %= base_power_val;
		     base_power_val /= base; 
		     place_digit[place_val - 1] = lcd_disp_num /base_power_val;
		     Write_LCD_Data(lcd_ch_id, hex_data[place_digit[place_val - 1]]);            
		} 	
      break;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Disable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.16  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LCD_Disable(const uint8_t lcd_ch_id)
{
	 lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	
	 if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id ;  
     cur_lcd_ctrl_ptr->enable_flag = STATE_NO;
	 
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Enable

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.17  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LCD_Enable(const uint8_t lcd_ch_id)
{
      lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	
	 if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id ;  
     cur_lcd_ctrl_ptr->enable_flag = STATE_NO;
   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disable_All_LCDs

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.18  

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Disable_All_LCDs(void)
{
	 uint8_t lcd_ch_id =0;
	
	 for(lcd_ch_id = 0; lcd_ch_id < NUM_OUTPUT_DEV_ID_LCD_CHS; ++lcd_ch_id)
	 {
		   LCD_Disable(lcd_ch_id);
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_Allow_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.19 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LCD_Allow_Access(const uint8_t lcd_ch_id)
{
	 lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	
	 if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id ;   
     cur_lcd_ctrl_ptr->access_flag = STATE_YES;
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_No_Access

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.20 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LCD_No_Access(const uint8_t lcd_ch_id)
{
	 lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	
	 if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id ;   
     cur_lcd_ctrl_ptr->access_flag = STATE_NO;
     LCD_Disable(lcd_ch_id);
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : LCD_DeInit

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 09.21 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t LCD_DeInit(const uint8_t lcd_ch_id)
{
	 io_config_t lcd_unconfig;
	 lcd_ctrl_t *cur_lcd_ctrl_ptr = NULL_PTR;
	 uint8_t ret_status = SUCCESS;
	 
	 if(lcd_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
	 {
		  error_flag = ERR_DEV_CH_ID_EXCEEDS;
		  return error_flag;
	 }
	 LCD_No_Access(lcd_ch_id);
	 cur_lcd_ctrl_ptr = lcd_ctrl + lcd_ch_id ; 
	 lcd_unconfig.io_ch  = cur_lcd_ctrl_ptr->base_io_ch_ctrl;	 
	 lcd_unconfig.port_pin_len = 3;
	 lcd_unconfig.func = IO_FUNC_GPIO;
	 lcd_unconfig.func_type = IO_FUNC_TYPE_GPIO_NON_SW;
	 if((ret_status = IO_Ch_Func_Reset(&lcd_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }	 
	 lcd_unconfig.io_ch  = cur_lcd_ctrl_ptr->base_io_ch_data;
	 if(cur_lcd_ctrl_ptr->interface == DATA_INTERFACE_8_BITS)
	 {
	      lcd_unconfig.port_pin_len = 8;
	 }
	 else
	 {
		  lcd_unconfig.port_pin_len = 4;
	 }
	 if((ret_status = IO_Ch_Func_Reset(&lcd_unconfig)) != SUCCESS)
	 {
		error_flag = ERR_IO_CH_FUNC_RESET;
        return error_flag;		
	 }
	 return SUCCESS;
}

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
