/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    :  In LCD 4 bit interface, periodically display number from -12 to 99 in LCD.
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : FOR reusable firmware development and data can be inputed by multi input source and outputed to multi output source.                        
                        

             LCD      : only display least numeric digits and from left to right display is implemented.  						
						
CAUTION               :  
                                    
CHANGE LOGS           :  

FILE ID               : 01

*****************************************************************************/
#include "main.h"
#include "dev_chs_map.h"
#include "data_ids_map.h"

/* ------------------------------ macro defination ------------------------------ */


/* ----------------------------- global variable defination --------------------- */
num_value_t to_disp_in_num;
uint32_t error_flag = NO_ERROR;
data_id_status_para_t data_id_status_para[NUM_DATA_IDS];
uint8_t cur_data_id = DATA_ID_INVALID;

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t System_Init(void);
static uint8_t Appl_Init(const void *const data_ptr);
static uint8_t HW_Init(const void *const get_init_ptr);
static uint8_t PLL_Init(void);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01  

BUGS           :              
-*------------------------------------------------------------*/
int main(void)
{
	output_data_ctrl_para_t lcd_disp_ctrl;
	uint8_t ret_status, sw_enable_flag = STATE_YES;
	  	
	if((ret_status = System_Init()) != SUCCESS)
	{
       return ret_status;
	}	
    if((ret_status = Appl_Init(NULL_PTR)) != SUCCESS)
	{
		  return ret_status;
    }
	Goto_XY_LCD_Disp(CH_ID_00,NUM_LINE1 , NUM_COL1 );
	LCD_Disp_Str(CH_ID_00, "Number");
	lcd_disp_ctrl.lcd_disp_para.disp_num.sign_flag = STATE_YES;
	lcd_disp_ctrl.lcd_disp_para.disp_num.least_digits_flag = STATE_YES;
	lcd_disp_ctrl.lcd_disp_para.disp_num.left_format_flag = STATE_YES;	
	lcd_disp_ctrl.lcd_disp_para.disp_num.num_digits = 3;
    lcd_disp_ctrl.lcd_disp_para.start_point_num.line_num_or_index = NUM_LINE2;
	lcd_disp_ctrl.lcd_disp_para.start_point_num.col_num_or_index = NUM_COL1; 
	while(1)
	{	
       switch(cur_data_id)
	  {
        case DATA_ID_LCD: 
		  for(data_id_status_para[cur_data_id].data_value.data_num.val_int_32[0] = -12; data_id_status_para[cur_data_id].data_value.data_num.val_int_32[0] < 100; ++data_id_status_para[cur_data_id].data_value.data_num.val_int_32[0] )
          {
			    Cur_Data_ID_Output_Devs_Write_Oper_Func(&lcd_disp_ctrl);
				SW_Time_Delay(MAX_ICOUNT_LCD_1500MS, MAX_JCOUNT_LCD_1500MS);				   
		  }    
        break;  
        default:
           return FAILURE;  		  
	  }
	  
   }
   return FAILURE;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Appl_Init(const void *const data_ptr)
{
	   dev_id_t cur_data_devs_src_allow[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS),MAX_DATA_COMM_DEVS)]; 
	   uint8_t ret_status = SUCCESS, ch_id;	 	       
		
	    Reset_Parameters();
	    if((ret_status = Data_IDs_Set_Para()) != SUCCESS)
		{
           return FAILURE;
		}		   
	    Next_Data_Conf_Parameter();
		Set_Data_Devs_Src_Allow(TYPE_OUTPUT_DEV, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
		if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(OUTPUT_DEV_ENABLE_OPER_FUNC, cur_data_devs_src_allow)) != SUCCESS)
		{
		   return FAILURE;
	    }
		Set_Data_Devs_Src_Allow(TYPE_INPUT_DEV, CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER, cur_data_devs_src_allow);
		if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ENABLE_OPER_FUNC, cur_data_devs_src_allow)) != SUCCESS)
		{
		   return FAILURE;
	    }
	    return SUCCESS; 
}
/*------------------------------------------------------------*
FUNCTION NAME  : Next_Data_Conf_Parameter

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.03

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Next_Data_Conf_Parameter(void)
{
    static uint8_t prev_data_id = DATA_ID_INVALID;
	
	 prev_data_id = cur_data_id;
	 switch(cur_data_id)
	 {
		  case DATA_ID_INVALID:
		  	cur_data_id = DATA_ID_LCD;           
          break;
          default:
		    error_flag = ERR_CUR_DATA_ID_INVALID;
			return error_flag;
	 }	
	Data_Dev_Src_Access_Oper_Func(prev_data_id); 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Parameters

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.04

BUGS           :    
-*------------------------------------------------------------*/
void Reset_Parameters(void)
{
	Reset_Data_IDs_Status();
	#ifdef SW_MOD_ENABLE
	   Disable_All_SWs();
	#endif   
    #ifdef KEYPAD_MOD_ENABLE	
       Disable_All_Keyboards();
	#endif
	#ifdef SEG7_MOD_ENABLE
	    Disable_All_Seg7s();
	#endif
	#ifdef LED_MATRIX_MOD_ENABLE
	   Disable_All_LED_Matrixs();
	#endif
	#ifdef LCD_MOD_ENABLE
	   Disable_All_LCDs();
	#endif
	//Reset_UART_Parameters();
	//memset(lcd_const_disp_flag, STATE_NO_IN_CHAR, sizeof(lcd_const_disp_flag)/ sizeof(char));	
	
}
/*------------------------------------------------------------*
FUNCTION NAME  : System_Init

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.05  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t System_Init(void)
{
	return HW_Init(NULL_PTR);
}

/*------------------------------------------------------------*
FUNCTION NAME  : HW_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : First initialise independent SW if any, then initialize Keyboard, if any.

Func ID        : 01.06  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t HW_Init(const void *const get_init_ptr)
{
	uint8_t ret_status = SUCCESS, ch_id;
	
	PLL_Init();
	Reset_IO_Chs();	
	for( ch_id = 0; ch_id < NUM_OUTPUT_DEV_ID_LCD_CHS; ++ch_id)
	   {
		   if((ret_status = LCD_Init(ch_id)) != SUCCESS)
		   {
			   return FAILURE;
		   }
	   }	   
       
  return SUCCESS;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : PLL_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : calculated for crystal oscillitor of 12MHz  

Func ID        : 01.07  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t PLL_Init(void)
{
    PLLCON = 0x01; //Enable PLL
    PLLCFG = 0x24; //Multiplier and divider setup
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
 
    while(!(PLLSTAT & 0x00000400)); //is locked?
 
    PLLCON = 0x03; //Connect PLL after PLL is locked
    PLLFEED = 0xAA; //Feed sequence
    PLLFEED = 0x55;
    VPBDIV = 0x00; // or APBDIV, PCLK = CCLK / 4 
   	return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
