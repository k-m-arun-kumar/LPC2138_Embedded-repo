/* ********************************************************************
FILE                   : appl_lib.c

PURPOSE                : 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : 
                       
CHANGE LOGS           : 

FILE ID               : 02 

*****************************************************************************/

#include "main.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */


/*------------------------------------------------------------*
FUNCTION NAME  : SW_Time_Delay

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.01  

BUGS           :              
-*------------------------------------------------------------*/
void SW_Time_Delay(const uint32_t max_i_count, const uint32_t max_j_count)
{
	 uint32_t i, j;
  
	 for(i = 0; i < max_i_count; ++i)
	 { 
         for(j = 0;j < max_j_count; ++j);
	 } 
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.02 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0;	
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;     
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return  error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->write_or_config_consucc_val |=  (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->write_or_config_consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->write_or_config_consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    error_flag = ERR_CONSUCC_PARA;
		    ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.03 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;	
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == (consucc_bit_ptr->read_or_test_consucc_val & mask_configured_bits))
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					   error_flag = ERR_TEST_FAIL_1_CONSUCC_BITS;
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == (consucc_bit_ptr->read_or_test_consucc_val | mask_configured_bits))
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    error_flag = ERR_TEST_FAIL_0_CONSUCC_BITS;
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
		 case FLAG_CONSUCC_BITS_VAL:
		     mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
			 if((consucc_bit_ptr->read_or_test_consucc_val & mask_configured_bits) == ((consucc_bit_ptr->write_or_config_consucc_val << consucc_bit_ptr->start_bit_pos) & mask_configured_bits))
			 {
			    ret_status = TEST_OK_VAL_CONSUCC_BITS;
			 }
			 else
			 {
			    error_flag = ERR_TEST_FAIL_VAL_CONSUCC_BITS;
			    ret_status = TEST_FAIL_VAL_CONSUCC_BITS;
			}
		 break;
			 default:
			 error_flag = ERR_CONSUCC_PARA;
		      ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.04  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_to_Num_Conv(uint32_t *const num_conv_from_str, const char *const num_in_str  )
{	
	 uint32_t num = 0, place = 1;
	 int32_t cur_unit;
	 uint8_t num_chars = 0, cur_digit= 0, ten = 10, pos = 0;
	
	 if(num_conv_from_str == NULL_PTR || num_in_str == NULL_PTR )
	 {
		 error_flag = ERR_STR_TO_NUM_PARA;
		 return error_flag;
	 }
	 num_chars = Str_Len(num_in_str);
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - NUM_0_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
		/* #ifdef TRACE_ERROR
		    UART_Transmit_Str("ERR: 1: Non numeric char in str_to_num\r");
		 #endif */
		 *num_conv_from_str = 0;
         error_flag = ERR_STR_TO_NUM_PARA;		 
		 return error_flag;
	 }	
     num = place * cur_unit;
     for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
     {
         place =  place * ten;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - NUM_0_CHAR;
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			/* #ifdef TRACE_ERROR
		       UART_Transmit_Str("ERR: 2: Non numeric char in str_to_num \r");
		     #endif */
			  *num_conv_from_str = 0;
			 error_flag = ERR_STR_TO_NUM_PARA; 
			 return error_flag;
		 }			 
         num += (cur_unit * place);     
     }
	 *num_conv_from_str = num; 
     return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_Len(const char *const str)
{
    uint8_t num_chars = 0;
	
	  if(str == NULL_PTR)
		{
			 error_flag = ERR_STR_PTR_NULL;	
			 return 0;
		}
    while(*(str + num_chars++));
    return num_chars - 1;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Data_ID_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.06

BUGS           :
-*------------------------------------------------------------*/
uint8_t Reset_Data_ID_Status(const uint8_t data_id, const uint8_t set_cur_data_status_reset_type)
{
	data_id_status_para_t *data_id_status_para_ptr = NULL_PTR;
	uint8_t ret_status = SUCCESS;
	
	if(data_id >= NUM_DATA_IDS)
	{
		 error_flag = ERR_DATA_ID_EXCEED;
		 return error_flag;
	}
	data_id_status_para_ptr = data_id_status_para + data_id;
	switch(set_cur_data_status_reset_type)
	{
		case DATA_ID_RESET_INIT_STATUS:
        #ifdef DMA_DATA_ID_STR
	   if(data_id_status_para_ptr->data_value.data_str != NULL_PTR)
	    {
	    	free(data_id_status_para_ptr->data_value.data_str);
		    data_id_status_para_ptr->data_value.data_str = NULL_PTR;
	    } 
		#endif
		data_id_status_para_ptr->max_allocated_data_len = 0;
		case DATA_ID_RESET_WHOLE_STATUS:		 
	    data_id_status_para_ptr->data_input_num_try = 0;		  
		case DATA_ID_RESET_RETRY_STATUS:
        data_id_status_para_ptr->data_value.data_str_len_or_pos = 0;
	    data_id_status_para_ptr->input_valid_terminator_char_flag = STATE_NO;
	    data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_NO;
	    data_id_status_para_ptr->data_value.data_num.val_uint_64  = DATA_NUM_INVALID;
	#ifdef DMA_DATA_ID_STR
      if(data_id_status_para_ptr->data_value.data_str != NULL_PTR)
    #endif		
	  {
          memset(data_id_status_para_ptr->data_value.data_str, NULL_CHAR, data_id_status_para_ptr->max_allocated_data_len * sizeof(char) );	
	  } 
	    
     break;
	 default:
    	error_flag = ERR_INVALID_FORMAT;
      return error_flag;	 
	}
	 return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Data_IDs_Status

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.07

BUGS           :
-*------------------------------------------------------------*/
void Reset_Data_IDs_Status(void)
{
	 uint8_t cur_data_id;
	
	 for(cur_data_id = 0; cur_data_id < NUM_DATA_IDS; ++cur_data_id)
	 {
		  Reset_Data_ID_Status(cur_data_id, DATA_ID_RESET_INIT_STATUS);
	 }
	 cur_data_id = DATA_ID_INVALID;
}


/*------------------------------------------------------------*
FUNCTION NAME  : Data_IDs_Set_Para

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.08 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_IDs_Set_Para(void)
{
	uint8_t data_id = 0, ret_status = SUCCESS;
	
	for(data_id = 0; data_id < NUM_DATA_IDS; ++data_id)
	{
		 if((ret_status = Data_ID_Set_Para(data_id)) != SUCCESS)
		 {
			 error_flag = ERR_DATA_ID_CONF;
			 break;
		 }
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Set_Para

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.09 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_ID_Set_Para(const uint8_t data_id)
{
	data_id_status_para_t *data_id_status_para_ptr = NULL_PTR;
		
	if(data_id >= NUM_DATA_IDS)
	{
		 error_flag = ERR_DATA_ID_EXCEED;
		 return error_flag;
	}
	data_id_status_para_ptr = data_id_status_para + data_id;
	if(data_ids_ctrl_para[data_id].max_req_data_len + 1 > DATA_MAX_NUM_ALLOCATED_CHARS)
		 	{
				  data_id_status_para_ptr->max_allocated_data_len = 0;
				  error_flag = ERR_EXCEEDS_DATA_NUM_CHARS;
		      return error_flag;
		 	}
			data_id_status_para_ptr->data_id = data_id;
	        
		    data_id_status_para_ptr->max_allocated_data_len = data_ids_ctrl_para[data_id].max_req_data_len + 1;	
			if(data_ids_ctrl_para[data_id].data_input_terminator_char == NULL_CHAR)
	    {
		      data_id_status_para_ptr->data_input_mode = DATA_ID_INPUT_MODE_TILL_ALLOC;				 
	    }
	    else
    	{
		     data_id_status_para_ptr->data_input_mode = DATA_ID_INPUT_MODE_TILL_TERMINATOR;
	    }
		
		#ifdef DMA_DATA_ID_STR
		if(data_id_status_para_ptr->data_value.data_str != NULL_PTR)
	    {
           error_flag = ERR_ALREADY_MEM_ALLOC;
		   return error_flag;
	    }
        data_id_status_para_ptr->data_value.data_str = (char *) malloc(data_id_status_para_ptr->max_allocated_data_len * sizeof(char));	
        #endif	
		
		data_id_status_para_ptr->data_input_num_try = 0;		
        data_id_status_para_ptr->data_value.data_str_len_or_pos = 0;
	    data_id_status_para_ptr->input_valid_terminator_char_flag = STATE_NO;
	    data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_NO;
      
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Power_Of

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
uint32_t Power_Of(const uint8_t base, const uint8_t power )
{
    uint32_t power_val = 1;
    uint8_t i = 0;
  
    if(power == 0)
    {
       return power_val;
    }
    for(i = 1; i <= power; ++i)
    {
      power_val *= base;
    }
    return power_val;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Delay_MS

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.11 

Bugs           : Not working   
-*------------------------------------------------------------*/
void Delay_MS(const uint32_t max_elapsed_time_in_ms )
{
    uint32_t max_elapsed_inst_cycle = max_elapsed_time_in_ms * _XTAL_FREQ * (1000 / 4), elapsed_inst_cycle;
	
	for(elapsed_inst_cycle = 0; elapsed_inst_cycle < max_elapsed_inst_cycle; ++elapsed_inst_cycle)
	{
		   __asm("NOP");
	}
}	

/*------------------------------------------------------------*
FUNCTION NAME  : Delay_US

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.12 

Bugs           :  Not working  
-*------------------------------------------------------------*/
void Delay_US(const uint32_t max_elapsed_time_in_us )
{
    uint32_t max_elapsed_inst_cycle = max_elapsed_time_in_us * (_XTAL_FREQ / 4) , elapsed_inst_cycle;
	
	for(elapsed_inst_cycle = 0; elapsed_inst_cycle < max_elapsed_inst_cycle; ++elapsed_inst_cycle)
	{
		   __asm("NOP");
	}
}	

/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit_in_Data

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 

Func ID        : 02.13 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Write_Bit_in_Data( uint32_t *const data_ptr, const uint8_t bit_pos, const uint8_t set_bit_val )
{
     if(data_ptr == NULL_PTR)
	 {
		 error_flag = ERR_NULL_PTR;
		 return error_flag;
	 }
	 switch(set_bit_val)
     {
		 case STATE_LOW:
		    Clear_Bit_in_Data(data_ptr, bit_pos );
         break;
         case STATE_HIGH:		 
            Set_Bit_in_Data(data_ptr, bit_pos);
		 break;
         default:
           error_flag = ERR_INVALID_FORMAT;
		   return error_flag;
     }
      return SUCCESS; 
}	
	
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
