/**************************************************************************
   FILE          :    dev_oper.c
 
   PURPOSE       :     
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
	CAUTION        :
	
  NOTE           :   
  
  CHANGE LOGS    :
  
  FILE ID        : 08  
	   
 **************************************************************************/ 
 #include "main.h"

/* ------------------------------ macro defination ------------------------------ */

/* ----------------------------- global variable defination --------------------- */

/* ----------------------------- global variable declaration -------------------- */

/* ----------------------------- global function declaration -------------------- */
 static uint8_t Dev_Oper_Read_Status_Proc( const uint8_t rcvd_read_status, const char read_char);
 static uint8_t Cur_Data_ID_Dev_Src_Basic_Oper_Func(const uint8_t dev_src_basic_oper_func, const dev_id_t *const dev_basic_oper_func_ptr);
 
/* ---------------------------- function pointer defination ---------------------- */
Dev_Oper_Func_t Dev_Oper_Func_Table[] = { 
                        #ifdef DAC_MOD_ENABLE
                        { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
                        #ifdef PWM_MOD_ENABLE
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
						#ifdef SEG7_MOD_ENABLE
						{ Seg7_DeInit, Seg7_Init, Seg7_No_Access, Seg7_Allow_Access, Seg7_Disable, Seg7_Enable, NULL_PTR, NULL_PTR, NULL_PTR, Seg7_Write },
						#else
						 { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
					    #endif
						#ifdef LCD_MOD_ENABLE
						 { LCD_DeInit ,LCD_Init, LCD_No_Access, LCD_Allow_Access, LCD_Disable, LCD_Enable, NULL_PTR, NULL_PTR, NULL_PTR, LCD_Write},
						#else
						 { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
					    #endif
						#ifdef LED_MATRIX_MOD_ENABLE
                         { LED_Matrix_DeInit, LED_Matrix_Init, LED_Matrix_No_Access, LED_Matrix_Allow_Access, LED_Matrix_Disable, LED_Matrix_Enable, NULL_PTR, NULL_PTR, NULL_PTR, LED_Matrix_Write},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
                      	#ifdef USART_MOD_ENABLE
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
						#ifdef I2C_MOD_ENABLE
                        { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
                        #ifdef SPI_MOD_ENABLE
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
              			#ifdef MISC_MOD_ENABLE
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif	
                        #ifdef KEYPAD_MOD_ENABLE
 						 { Keyboard_DeInit, Keyboard_Init, Keyboard_No_Access, Keyboard_Allow_Access, Keyboard_Disable, Keyboard_Enable, NULL_PTR, NULL_PTR, Keyboard_Read, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
						#ifdef ADC_MOD_ENABLE
						 { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                        { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
						#ifdef SW_MOD_ENABLE
						 { SW_DeInit, SW_Init, SW_No_Access, SW_Allow_Access, SW_Disable, SW_Enable, NULL_PTR, NULL_PTR, SW_Press_Proc, NULL_PTR},
                        #else
                        { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
						#ifdef INPUT_MISC_MOD_ENABLE
						 { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #else
                         { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR},
                        #endif
						 { NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR, NULL_PTR}
                      }; 
					  
/*------------------------------------------------------------*
FUNCTION NAME  : Cur_Data_ID_Input_Devs_Read_Oper_Func

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.01

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Cur_Data_ID_Input_Devs_Read_Oper_Func(void)
{
 	data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
    dev_id_t data_dev_read_oper_func;
	uint8_t ret_status = SUCCESS, i = 0; 
	char read_char;
	
	if(cur_data_id >= NUM_DATA_IDS)
	{
	   error_flag = ERR_DATA_ID_EXCEED;
	   return error_flag;
	}
	cur_data_id_status_para_ptr = data_id_status_para + cur_data_id;
	if(cur_data_id_status_para_ptr->input_valid_terminator_char_flag  == STATE_YES || (cur_data_id_status_para_ptr->data_input_mode == DATA_ID_INPUT_MODE_TILL_ALLOC && cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag == STATE_YES))
	{
		  return CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS;
	}
	i = 0;	
    data_dev_read_oper_func =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i];
	while(data_dev_read_oper_func.dev_id >= BEGIN_INPUT_DEV_ID && data_dev_read_oper_func.dev_id <= END_INPUT_DEV_ID && i < MAX_DATA_INPUT_DEVS)
	{
	   if(Dev_Oper_Func_Table[data_dev_read_oper_func.dev_id].Dev_Read_Func_Ptr != NULL_PTR)
	   {
	 	   ret_status = (*Dev_Oper_Func_Table[data_dev_read_oper_func.dev_id].Dev_Read_Func_Ptr)(data_dev_read_oper_func.dev_ch_id, &read_char);
	      switch(ret_status)
          {
           case DATA_CHAR_READ:
           case SW_OR_KEY_NOT_PRESSED:
           case ERR_CUR_DATA_ID_DEV_DISABLED: 
           case ERR_CUR_DATA_ID_DEV_NO_ACCESS: 
           break;           
           default: 
             error_flag = ERR_DEV_OPER_READ_FUNC;
			       return error_flag;
         }	      
          ret_status = Dev_Oper_Read_Status_Proc(ret_status, read_char);    
		  switch(ret_status)
		  {
			  case ERR_DEV_OPER_READ_FUNC:
			    error_flag = ret_status;
              case CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS:
			     return ret_status;
			  //break;	
		  }         		  
	   }
	   else
	   {
	      error_flag = ERR_NULL_PTR;
          return error_flag;
	   }
	   ++i;
	   data_dev_read_oper_func =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i]; 
	}
	return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Dev_Oper_Read_Status_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :   

Func ID        : 08.02  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Dev_Oper_Read_Status_Proc( const uint8_t rcvd_read_status, const char read_char)
{
	data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	uint8_t data_valid_read_char_flag = STATE_NO, ret_status = rcvd_read_status, comm_lcd_ch_id = CH_ID_00;
	
	if(cur_data_id >= NUM_DATA_IDS)
	{
	   error_flag = ERR_DATA_ID_EXCEED;
	   return error_flag;
	}
	cur_data_id_status_para_ptr = data_id_status_para + cur_data_id;	
    if(cur_data_id_status_para_ptr->input_valid_terminator_char_flag  == STATE_YES || (cur_data_id_status_para_ptr->data_input_mode == DATA_ID_INPUT_MODE_TILL_ALLOC && cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag == STATE_YES))
	{
		  return CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS;
	}
	switch(rcvd_read_status)
	{ 
	    case  DATA_CHAR_READ:
		case  COMM_RCVD_CHAR:
		   if(read_char > ASCII_MAX_CHAR_CODE)
		   {
			   error_flag = ERR_INVALID_DATA_CHAR_READ;
			   return error_flag;
		   }
		   if(cur_data_id_status_para_ptr->data_input_mode == DATA_ID_INPUT_MODE_TILL_TERMINATOR && data_ids_ctrl_para[cur_data_id].data_input_terminator_char == (char) read_char )
		   {
			   data_valid_read_char_flag = STATE_YES;			  
			   break;
		   }			 
		  if(read_char >= NUM_0_CHAR && read_char <= NUM_9_CHAR)
		  {  
		     if(data_ids_ctrl_para[cur_data_id].data_proc_num_char_enable_flag  ==  STATE_NO)		
		     {
				 error_flag = ERR_CUR_DATA_ID_NUM_CHAR_READ_BUT_DISABLED; 		 
		         return error_flag;
		     }
			 
		     data_valid_read_char_flag = STATE_YES;
			 break;
		  }
		  if(read_char >= ENGLISH_SMALL_ALPHA_a_CHAR && read_char <= ENGLISH_SMALL_ALPHA_z_CHAR)
		  {
		      if(data_ids_ctrl_para[cur_data_id].data_proc_small_english_alpha_char_enable_flag  ==  STATE_NO)		
		      {
			   	 error_flag = ERR_CUR_DATA_ID_SMALL_ENGLISH_ALPHA_CHAR_READ_BUT_DISABLED; 		 
		         return error_flag;
		      }
		      data_valid_read_char_flag = STATE_YES;
			  break; 
		  }
		  if(read_char >= ENGLISH_BIG_ALPHA_A_CHAR && read_char <= ENGLISH_BIG_ALPHA_Z_CHAR)
		  {
			   if(data_ids_ctrl_para[cur_data_id].data_proc_big_english_alpha_char_enable_flag  ==  STATE_NO)		
		       {
			  	   error_flag = ERR_CUR_DATA_ID_BIG_ENGLISH_ALPHA_CHAR_READ_BUT_DISABLED; 		 
		           return error_flag;
		       }
		       data_valid_read_char_flag = STATE_YES;
			   break;
		  }
		  if(read_char >= BEGIN_CTRL_CHARS_ASCII_CODE && read_char <= END_CTRL_CHARS_ASCII_CODE)
		  {
			   if(data_ids_ctrl_para[cur_data_id].data_proc_ctrl_char_enable_flag  ==  STATE_NO)		
		       {
			  	   error_flag = ERR_CUR_DATA_ID_CTRL_CHAR_READ_BUT_DISABLED; 		 
		           return error_flag;
		       }
			   switch(read_char)
			   {
			       case BACKSPACE_CHAR:
			      	  /* rcvd char is backspace */
				      if(cur_data_id_status_para_ptr->data_value.data_str_len_or_pos > 0)
				      {
						  #ifdef LCD_MOD_ENABLE
				            --lcd_status[comm_lcd_ch_id].lcd_cur_disp_loc;
				             Write_LCD_Command(comm_lcd_ch_id, lcd_status[comm_lcd_ch_id].lcd_cur_disp_loc);
				             Write_LCD_Data(comm_lcd_ch_id, ' '); 
                             Write_LCD_Command(comm_lcd_ch_id, 0x10); //shift cursor to left 
						   #endif	 
					        --cur_data_id_status_para_ptr->data_value.data_str_len_or_pos;				           
				       }
                       else
				       {
				            cur_data_id_status_para_ptr->data_value.data_str[0] = NULL_CHAR;
							#ifdef  LCD_MOD_ENABLE
					           lcd_status[comm_lcd_ch_id].lcd_cur_disp_loc = LCD_BEGIN_LOC_ECHO_UART_RCVD_STR;
							#endif
			           }
					break;   
			   }
		       data_valid_read_char_flag = STATE_YES;
			   break;
		  }
		  else
		  {
		     if(data_ids_ctrl_para[cur_data_id].data_proc_special_char_enable_flag  ==  STATE_NO)		
		     {
				 error_flag = ERR_CUR_DATA_ID_SPECIAL_CHAR_READ_BUT_DISABLED; 		 
		         return error_flag;
		      }
		     data_valid_read_char_flag = STATE_YES;
		    // break;	  
		  }
		  break;
          case ERR_CUR_DATA_ID_DEV_DISABLED:
		  case ERR_CUR_DATA_ID_DEV_NO_ACCESS:
		  case SW_OR_KEY_NOT_PRESSED:	
	      case COMM_NO_RCV_CHAR:
          break;
		  default:
            return ERR_DEV_OPER_READ_FUNC; 
	} 
	if(data_valid_read_char_flag == STATE_YES)
	{
		  ret_status = CUR_DATA_ID_VALID_CHAR_READ;
		  #ifdef TRACE
		     if(!(read_char >= BEGIN_CTRL_CHARS_ASCII_CODE && read_char <= END_CTRL_CHARS_ASCII_CODE))
		     {
		       #ifdef LCD_MOD_ENABLE
    		      Write_LCD_Data(comm_lcd_ch_id, cur_data_id_status_para_ptr->data_value.data_str[cur_data_id_status_para_ptr->data_value.data_str_len_or_pos]);
			   #endif  		
		     }
		  #endif
          switch( cur_data_id_status_para_ptr->data_input_mode) 
	      {
			 //enter data till enter key is pressed
		     case DATA_ID_INPUT_MODE_TILL_TERMINATOR:
			   if( data_ids_ctrl_para[cur_data_id].data_input_terminator_char == (char) read_char )
			   {
				   cur_data_id_status_para_ptr->data_value.data_str[cur_data_id_status_para_ptr->data_value.data_str_len_or_pos]= NULL_CHAR;	
                   cur_data_id_status_para_ptr->input_valid_terminator_char_flag = STATE_YES; 
				   if(cur_data_id_status_para_ptr->data_value.data_str_len_or_pos >= DATA_MAX_NUM_CHARS_TO_READ)
				   {
					    cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_YES;
				   }
				   return CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS;  
			   }
			   cur_data_id_status_para_ptr->data_value.data_str[cur_data_id_status_para_ptr->data_value.data_str_len_or_pos] = (char) read_char;   
               ++cur_data_id_status_para_ptr->data_value.data_str_len_or_pos;
	           if(cur_data_id_status_para_ptr->data_value.data_str_len_or_pos >= DATA_MAX_NUM_CHARS_TO_READ)
	           {
		           cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_YES;
                   return CUR_DATA_ID_REACH_MAX_CHARS_READ_WAIT_TERMINATOR_CHAR;
		       }
		     break;
			 //enter data till max nums of chars is reached
             case DATA_ID_INPUT_MODE_TILL_ALLOC:	
         		if(cur_data_id_status_para_ptr->max_allocated_data_len > DATA_MAX_NUM_CHARS_TO_READ ) 
		        {
						error_flag = ERR_CUR_DATA_ID_READ_EXCEEDS_MAX_CHARS;
				        return error_flag;
				}
				cur_data_id_status_para_ptr->data_value.data_str[cur_data_id_status_para_ptr->data_value.data_str_len_or_pos] = (char) read_char;   
                ++cur_data_id_status_para_ptr->data_value.data_str_len_or_pos;
			    if(cur_data_id_status_para_ptr->data_value.data_str_len_or_pos + 1 >= cur_data_id_status_para_ptr->max_allocated_data_len)
			    {
				       cur_data_id_status_para_ptr->data_value.data_str[cur_data_id_status_para_ptr->data_value.data_str_len_or_pos]= NULL_CHAR;	
                       cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag = STATE_YES;                        
                       return CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS; 							 
			    }      		
	      }
	}	
	return ret_status;		
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_Dev_Src_Access_Oper_Func

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.03

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_Dev_Src_Access_Oper_Func(const uint8_t prev_data_id)
{
	dev_id_t data_dev_access_oper , cur_data_devs_src_allow[MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS),MAX_DATA_COMM_DEVS)] = { {CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER}};
  uint8_t i = 0, ret_status = SUCCESS;
	
	 if(cur_data_id >= NUM_DATA_IDS)
	 {
		 error_flag = ERR_DATA_ID_EXCEED;
		 return error_flag;   		   
	 }  
	 if(cur_data_id == prev_data_id)
	 {
		  error_flag = ERR_PREV_AND_CUR_DATA_MATCH;
		  return error_flag;
	 }
	 
	 if(prev_data_id < NUM_DATA_IDS)
	 {
		 i = 0;	
     	 data_dev_access_oper =  data_ids_dev_srcs[prev_data_id].data_input_dev_ids[i];
		    while(data_dev_access_oper.dev_id >= BEGIN_INPUT_DEV_ID && data_dev_access_oper.dev_id <= END_INPUT_DEV_ID && i < MAX_DATA_INPUT_DEVS)
		    {
				   if(Dev_Oper_Func_Table[data_dev_access_oper.dev_id].Dev_No_Access_Func_Ptr != NULL_PTR)
				   {
					   if((ret_status = (*Dev_Oper_Func_Table[data_dev_access_oper.dev_id].Dev_No_Access_Func_Ptr)(data_dev_access_oper.dev_ch_id)) != SUCCESS)
				       {
						  error_flag = ERR_DEV_OPER_NO_ACCESS_FUNC;
						  return error_flag;
				       }
				   }
				   else
				   {
					   error_flag = ERR_NULL_PTR;
                       return error_flag;  
				   }
				    ++i;
				    data_dev_access_oper =  data_ids_dev_srcs[prev_data_id].data_input_dev_ids[i]; 
			 }
			 
		   i = 0;
		   data_dev_access_oper =  data_ids_dev_srcs[prev_data_id].data_output_dev_ids[i];
		   while(data_dev_access_oper.dev_id >= BEGIN_OUTPUT_DEV_ID && data_dev_access_oper.dev_id <= END_OUTPUT_DEV_ID && i < MAX_DATA_OUTPUT_DEVS)
		   {
				   if(Dev_Oper_Func_Table[data_dev_access_oper.dev_id].Dev_No_Access_Func_Ptr != NULL_PTR)
				   {
					   if((ret_status = (*Dev_Oper_Func_Table[data_dev_access_oper.dev_id].Dev_No_Access_Func_Ptr)(data_dev_access_oper.dev_ch_id)) != SUCCESS)
				       {
						  error_flag = ERR_DEV_OPER_NO_ACCESS_FUNC;
						  return error_flag;
				       }
				   }
				   else
				   {
					   error_flag = ERR_NULL_PTR;
                       return error_flag;  
				   }
			    ++i;
			    data_dev_access_oper =  data_ids_dev_srcs[prev_data_id].data_output_dev_ids[i]; 
	      }
		
		  i = 0;
		   data_dev_access_oper =  data_ids_dev_srcs[prev_data_id].data_comm_dev_ids[i];
		   while(data_dev_access_oper.dev_id >= BEGIN_COMM_DEV_ID && data_dev_access_oper.dev_id <= END_COMM_DEV_ID && i < MAX_DATA_COMM_DEVS)
		   {
				if(Dev_Oper_Func_Table[data_dev_access_oper.dev_id].Dev_No_Access_Func_Ptr != NULL_PTR)
				{
				    if((ret_status = (*Dev_Oper_Func_Table[data_dev_access_oper.dev_id].Dev_No_Access_Func_Ptr)(data_dev_access_oper.dev_ch_id)) != SUCCESS)
				    {
				  	  error_flag = ERR_DEV_OPER_NO_ACCESS_FUNC;
					  return error_flag;
				    }
				}
				else
				{
				   error_flag = ERR_NULL_PTR;
                   return error_flag;  
				}  
			    ++i;
			    data_dev_access_oper =  data_ids_dev_srcs[prev_data_id].data_comm_dev_ids[i]; 
	       } 
	 } 
	 
	    if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(INPUT_DEV_ALLOW_ACCESS_OPER_FUNC, cur_data_devs_src_allow )) != SUCCESS)
		{
			error_flag = ERR_DEV_OPER_ALLOW_ACCESS_FUNC;
			return error_flag;
		}
        if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(OUTPUT_DEV_ALLOW_ACCESS_OPER_FUNC, cur_data_devs_src_allow )) != SUCCESS)
		{
			error_flag = ERR_DEV_OPER_ALLOW_ACCESS_FUNC;
			return error_flag;
		}
		if((ret_status = Cur_Data_ID_Devs_Src_Basic_Oper_Func(COMM_DEV_ALLOW_ACCESS_OPER_FUNC, cur_data_devs_src_allow )) != SUCCESS)
		{
			error_flag = ERR_DEV_OPER_ALLOW_ACCESS_FUNC;
			return error_flag;
		}
      return SUCCESS;    
}

/*------------------------------------------------------------*
FUNCTION NAME  : Cur_Data_ID_Devs_Src_Basic_Oper_Func

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 08.04 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Cur_Data_ID_Devs_Src_Basic_Oper_Func(const uint8_t dev_src_basic_oper_func, const dev_id_t *const cur_data_devs_src_allow_ptr )
{
	  dev_id_t data_dev_basic_oper_func;
      uint8_t i = 0, ret_status = SUCCESS, j = 0, min_dev_id, max_dev_id, max_data_dev_type_srcs, dev_src_allow_match_flag = STATE_NO;
	  
	  if(cur_data_devs_src_allow_ptr == NULL_PTR ||
      !((dev_src_basic_oper_func >= START_INPUT_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_INPUT_DEV_BASIC_OPER_FUNC) || 
		 (dev_src_basic_oper_func >= START_OUTPUT_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_OUTPUT_DEV_BASIC_OPER_FUNC) ||
	     (dev_src_basic_oper_func >= START_COMM_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_COMM_DEV_BASIC_OPER_FUNC)))
	  {
		  error_flag = ERR_DEV_SRC_BASIC_OPER_FUNC_INVALID;
		  return error_flag;
	  }		 
	  if(dev_src_basic_oper_func >= START_INPUT_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_INPUT_DEV_BASIC_OPER_FUNC )
	  {
          data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i];
		  if((data_dev_basic_oper_func.dev_id < BEGIN_INPUT_DEV_ID || data_dev_basic_oper_func.dev_id > END_INPUT_DEV_ID) )
	      {
		         return SUCCESS;
	      }
	      min_dev_id = BEGIN_INPUT_DEV_ID;
		  max_dev_id = END_INPUT_DEV_ID;
		  max_data_dev_type_srcs = MAX_DATA_INPUT_DEVS;		 
	  }
	  else
	  {
	      if(dev_src_basic_oper_func >= START_OUTPUT_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_OUTPUT_DEV_BASIC_OPER_FUNC )
	      {
             data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i];
	         if((data_dev_basic_oper_func.dev_id < BEGIN_OUTPUT_DEV_ID || data_dev_basic_oper_func.dev_id > END_OUTPUT_DEV_ID) )
	         {
		         return SUCCESS;
	         }
		     min_dev_id = BEGIN_OUTPUT_DEV_ID;
		     max_dev_id = END_OUTPUT_DEV_ID;
		     max_data_dev_type_srcs = MAX_DATA_OUTPUT_DEVS;		 
	      }
		  else
		  {
			 data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_comm_dev_ids[i];
	         if((data_dev_basic_oper_func.dev_id < BEGIN_COMM_DEV_ID || data_dev_basic_oper_func.dev_id > END_COMM_DEV_ID))
	         {
		         return SUCCESS;  
	         }
		     min_dev_id = BEGIN_COMM_DEV_ID;
		     max_dev_id = END_COMM_DEV_ID;
		     max_data_dev_type_srcs = MAX_DATA_COMM_DEVS;	  
		  }
	  }
      if(cur_data_devs_src_allow_ptr->dev_id != CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER)
	  {		  
	      for(j = 0; j < max_data_dev_type_srcs; ++j)
		  {
			 dev_src_allow_match_flag = STATE_NO;
		     if((cur_data_devs_src_allow_ptr + j )->dev_id == DEV_ID_INVALID)
			 {				
				 return SUCCESS;
			 }		 
	         while(data_dev_basic_oper_func.dev_id >= min_dev_id && data_dev_basic_oper_func.dev_id <= max_dev_id && i < max_data_dev_type_srcs)
	         {
                 if((cur_data_devs_src_allow_ptr + j )->dev_id == data_dev_basic_oper_func.dev_id )
			     {
				      if((cur_data_devs_src_allow_ptr + j )->dev_ch_id == data_dev_basic_oper_func.dev_ch_id)
				      {
					      if((ret_status = Cur_Data_ID_Dev_Src_Basic_Oper_Func(dev_src_basic_oper_func, &data_dev_basic_oper_func)) != SUCCESS)
						  {
							  error_flag = ERR_DEV_SRC_BASIC_OPER_FUNC_INVALID;
							  return error_flag;
						  }
						  dev_src_allow_match_flag = STATE_YES;
				      }
				 }
				 if(dev_src_allow_match_flag == STATE_NO)
				 {
				      ++i;
		              if(dev_src_basic_oper_func >= START_INPUT_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_INPUT_DEV_BASIC_OPER_FUNC )
	                  {
		                  data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i]; 
				      }
		              else 
		              {
		        	      if(dev_src_basic_oper_func >= START_OUTPUT_DEV_OPER_FUNC && dev_src_basic_oper_func <= END_OUTPUT_DEV_OPER_FUNC)
		                  {
				               data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i];						 
			              }
			              else
			              {
				              data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_comm_dev_ids[i];						 
			              }
		              }				 
		       }
           else
           {
               break;
           }
			 }
			 if(dev_src_allow_match_flag == STATE_NO && data_dev_basic_oper_func.dev_id != DEV_ID_INVALID)
			 {
				 error_flag = ERR_CUR_DATA_DEV_SRC_ALLOW_NOT_SRC_LIST;
				 return error_flag;
			 }			       
		  }  
	  }
      else
      {
          i = 0;
		  while(data_dev_basic_oper_func.dev_id >= min_dev_id && data_dev_basic_oper_func.dev_id <= max_dev_id && i < max_data_dev_type_srcs)
	      {
              if((ret_status = Cur_Data_ID_Dev_Src_Basic_Oper_Func(dev_src_basic_oper_func, &data_dev_basic_oper_func)) != SUCCESS)
			  {
				  error_flag = ERR_DEV_SRC_BASIC_OPER_FUNC_INVALID;
			      return error_flag;
		      } 
			  ++i;
		      if(dev_src_basic_oper_func >= START_INPUT_DEV_BASIC_OPER_FUNC && dev_src_basic_oper_func <= END_INPUT_DEV_BASIC_OPER_FUNC )
	          {
		           data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i]; 
		      }
		      else 
		      {
		   	      if(dev_src_basic_oper_func >= START_OUTPUT_DEV_OPER_FUNC && dev_src_basic_oper_func <= END_OUTPUT_DEV_OPER_FUNC)
		          {
		               data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i];						 
		          }
		          else
		          {
		              data_dev_basic_oper_func =  data_ids_dev_srcs[cur_data_id].data_comm_dev_ids[i];						 
		          }
		      }	
		  } 
	  }	
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Cur_Data_ID_Output_Devs_Write_Oper_Func

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.06

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Cur_Data_ID_Output_Devs_Write_Oper_Func(const output_data_ctrl_para_t *const data_ctrl_para_ptr)
{
	data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	data_value_ptr_with_type_t data_output_value;
    dev_id_t data_dev_write_oper;
	uint8_t ret_status = SUCCESS, i = 0;
	
    if(data_ctrl_para_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}		
	if(cur_data_id >= NUM_DATA_IDS)
	{
	   error_flag = ERR_DATA_ID_EXCEED;
	   return error_flag;
	}		   
	if(data_ids_ctrl_para[cur_data_id].output_data_type == DATA_TYPE_IN_INVALID)
	{
		error_flag = ERR_DATA_TYPE_INVALID;
	    return error_flag;
	}
	cur_data_id_status_para_ptr = data_id_status_para + cur_data_id;
	data_output_value.data_value_ptr = &cur_data_id_status_para_ptr->data_value;	
    data_output_value.data_type = data_ids_ctrl_para[cur_data_id].output_data_type; 
	data_output_value.data_disp_format = data_ids_ctrl_para[cur_data_id].data_disp_format;
	data_output_value.data_ctrl_para_ptr = data_ctrl_para_ptr;
	i = 0;	
    data_dev_write_oper =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i];
	while(data_dev_write_oper.dev_id >= BEGIN_OUTPUT_DEV_ID && data_dev_write_oper.dev_id <= END_OUTPUT_DEV_ID && i < MAX_DATA_OUTPUT_DEVS)
	{
	    if(Dev_Oper_Func_Table[data_dev_write_oper.dev_id].Dev_Write_Func_Ptr != NULL_PTR)
	   {
	 	    ret_status = (*Dev_Oper_Func_Table[data_dev_write_oper.dev_id].Dev_Write_Func_Ptr)(data_dev_write_oper.dev_ch_id, &data_output_value);
	        switch(ret_status)
            {
                case SUCCESS:
                case ERR_CUR_DATA_ID_DEV_DISABLED: 
                case ERR_CUR_DATA_ID_DEV_NO_ACCESS: 
                break;           
                default: 
                   error_flag = ERR_DEV_OPER_READ_FUNC;
			       return error_flag;
            } 		  
	   }
	   else
	   {
	      error_flag = ERR_NULL_PTR;
          return error_flag;
	   }
	   ++i;
	   data_dev_write_oper =  data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i]; 
	}
	return ret_status;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Set_Data_Devs_Src_Allow

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.07

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Set_Data_Devs_Src_Allow(const uint8_t dev_type, const uint8_t data_dev_allow_type, dev_id_t *const cur_data_devs_src_allow_ptr)
{
  dev_id_t data_dev;
	uint8_t ret_status, i;
	
	if((ret_status = Reset_Data_Devs_Src_Allow(cur_data_devs_src_allow_ptr)) != SUCCESS)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
	if(data_dev_allow_type == CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER)
	{
		(cur_data_devs_src_allow_ptr + 0)->dev_id = CUR_DATA_ID_ALL_SRC_OF_SPEC_OPER;
		return SUCCESS;
	}
	switch(dev_type)
	{
		case TYPE_INPUT_DEV:
		   for(i = 0; i < MAX_DATA_INPUT_DEVS; ++i)
		   {
			     data_dev = data_ids_dev_srcs[cur_data_id].data_input_dev_ids[i];
              if(data_dev.dev_id == DEV_ID_INVALID)
              {
                   break;
			  }
			  *(cur_data_devs_src_allow_ptr + i) = data_dev;			   
		   }
        break;
        case TYPE_OUTPUT_DEV:
           for(i = 0; i < MAX_DATA_OUTPUT_DEVS; ++i)
		   {
			  data_dev = data_ids_dev_srcs[cur_data_id].data_output_dev_ids[i];
              if(data_dev.dev_id == DEV_ID_INVALID)
              {
                   break;
			  }
			  *(cur_data_devs_src_allow_ptr + i) = data_dev;	
		   }
        break;	
        case TYPE_COMM_DEV:
		   for(i = 0; i < MAX_DATA_COMM_DEVS; ++i)
		   {
			  data_dev = data_ids_dev_srcs[cur_data_id].data_comm_dev_ids[i];
              if(data_dev.dev_id == DEV_ID_INVALID)
              {
                   break;
			  }
			  *(cur_data_devs_src_allow_ptr + i) = data_dev;
		   }
        break;
        default:
		  error_flag = ERR_INVALID_FORMAT;
		  return error_flag;		
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  Reset_Data_Devs_Src_Allow

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.08

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Reset_Data_Devs_Src_Allow(dev_id_t *const cur_data_devs_src_allow_ptr)
{
	uint8_t i, cur_data_devs_allow_size =  MAX_NUM(MAX_NUM(MAX_DATA_INPUT_DEVS, MAX_DATA_OUTPUT_DEVS), MAX_DATA_COMM_DEVS);
	
	if(cur_data_devs_src_allow_ptr == NULL_PTR)
	{
		 error_flag = ERR_NULL_PTR;
         return error_flag;
	}
	for(i = 0; i < cur_data_devs_allow_size; ++i)
	{
		(cur_data_devs_src_allow_ptr + i)->dev_id = DEV_ID_INVALID;
	}
	return SUCCESS;
}	

/*------------------------------------------------------------*
FUNCTION NAME  :  Cur_Data_ID_Dev_Src_Basic_Oper_Func

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.09

BUGS           :    
-*------------------------------------------------------------*/
static uint8_t Cur_Data_ID_Dev_Src_Basic_Oper_Func(const uint8_t dev_src_basic_oper_func, const dev_id_t *const dev_basic_oper_func_ptr)
{
	uint8_t ret_status;
	
	if(dev_basic_oper_func_ptr == NULL_PTR)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
    switch(dev_src_basic_oper_func)
	{
         case INPUT_DEV_DEINIT_OPER_FUNC:
	     case OUTPUT_DEV_DEINIT_OPER_FUNC:
		 case COMM_DEV_DEINIT_OPER_FUNC:
             if(Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_DeInit_Func_Ptr != NULL_PTR)
		     {
		        if((ret_status = (*Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_DeInit_Func_Ptr)(dev_basic_oper_func_ptr->dev_ch_id)) != SUCCESS)
		        {
		    	      error_flag = ERR_DEV_OPER_DEINIT_FUNC;
				      return error_flag;
		        } 		
	        }
		    else
		    {
		        error_flag = ERR_NULL_PTR;
                return error_flag;
		    }
    	 break;
	     case INPUT_DEV_INIT_OPER_FUNC:
		 case OUTPUT_DEV_INIT_OPER_FUNC:
		 case COMM_DEV_INIT_OPER_FUNC:
		     if(Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Init_Func_Ptr != NULL_PTR)
		     {
		         if((ret_status = (*Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Init_Func_Ptr)(dev_basic_oper_func_ptr->dev_ch_id)) != SUCCESS)
				 {
			        error_flag = ERR_DEV_OPER_INIT_FUNC;
				    return error_flag;
		         } 		
	         }
		     else
		     {
		        error_flag = ERR_NULL_PTR;
                return error_flag;
		    }
		 break;
		 case INPUT_DEV_NO_ACCESS_OPER_FUNC:
		 case OUTPUT_DEV_NO_ACCESS_OPER_FUNC:
		 case COMM_DEV_NO_ACCESS_OPER_FUNC:
		    if(Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_No_Access_Func_Ptr != NULL_PTR)
		    {
		        if((ret_status = (*Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_No_Access_Func_Ptr)(dev_basic_oper_func_ptr->dev_ch_id)) != SUCCESS)
		        {
		    	      error_flag = ERR_DEV_OPER_NO_ACCESS_FUNC;
			          return error_flag;
		        } 		
	        }
		    else
		    {
		        error_flag = ERR_NULL_PTR;
                return error_flag;
		    }
        break;
        case INPUT_DEV_ALLOW_ACCESS_OPER_FUNC:
		case OUTPUT_DEV_ALLOW_ACCESS_OPER_FUNC:
		case COMM_DEV_ALLOW_ACCESS_OPER_FUNC:
		    if(Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Allow_Access_Func_Ptr != NULL_PTR)
		    {
		        if((ret_status = (*Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Allow_Access_Func_Ptr)(dev_basic_oper_func_ptr->dev_ch_id)) != SUCCESS)
		        {
				      error_flag = ERR_DEV_OPER_ALLOW_ACCESS_FUNC;
				      return error_flag;
		        } 		
	        }
		    else
		    {
		        error_flag = ERR_NULL_PTR;
                return error_flag;
		    }
        break;
        case	INPUT_DEV_DISABLE_OPER_FUNC:
		case	OUTPUT_DEV_DISABLE_OPER_FUNC:
		case	COMM_DEV_DISABLE_OPER_FUNC:
		   if(Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Disable_Func_Ptr != NULL_PTR)
		   {
		       if((ret_status = (*Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Disable_Func_Ptr)(dev_basic_oper_func_ptr->dev_ch_id)) != SUCCESS)
		       {
			      error_flag = ERR_DEV_OPER_DISABLE_FUNC;
			      return error_flag;
		       } 		
	      }
		  else
		   {
		        error_flag = ERR_NULL_PTR;
                return error_flag;
		   }
        break;
        case	INPUT_DEV_ENABLE_OPER_FUNC:
        case  OUTPUT_DEV_ENABLE_OPER_FUNC: 
        case  COMM_DEV_ENABLE_OPER_FUNC: 
		   if(Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Enable_Func_Ptr != NULL_PTR)
		   {
		      if((ret_status = (*Dev_Oper_Func_Table[dev_basic_oper_func_ptr->dev_id].Dev_Enable_Func_Ptr)(dev_basic_oper_func_ptr->dev_ch_id)) != SUCCESS)
		      {
			      error_flag = ERR_DEV_OPER_ENABLE_FUNC;
			      return error_flag;
		      } 		
	       }
		   else
		   {
		        error_flag = ERR_NULL_PTR;
                return error_flag;
		   }
        break;
        default:
		    error_flag = ERR_DEV_SRC_BASIC_OPER_FUNC_INVALID;
		    return error_flag;
    }
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Cur_Data_ID_Comm_Devs_Receive_Oper_Func

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 08.10

BUGS           :    
-*------------------------------------------------------------*/
uint8_t Cur_Data_ID_Comm_Devs_Receive_Oper_Func(void)
{
 	data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
    dev_id_t data_dev_receive_oper_func;
	uint8_t ret_status = SUCCESS, i = 0, comm_lcd_ch_id = CH_ID_00; 
	unsigned char received_char;
	
	if(cur_data_id >= NUM_DATA_IDS)
	{
	   error_flag = ERR_DATA_ID_EXCEED;
	   return error_flag;
	}
	cur_data_id_status_para_ptr = data_id_status_para + cur_data_id;
	if(cur_data_id_status_para_ptr->input_valid_terminator_char_flag  == STATE_YES || (cur_data_id_status_para_ptr->data_input_mode == DATA_ID_INPUT_MODE_TILL_ALLOC && cur_data_id_status_para_ptr->reach_max_alloc_input_chars_flag == STATE_YES))
	{
		  return CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS;
	}
	/*#ifdef  LCD_MOD_ENABLE
	    lcd_status[comm_lcd_ch_id].lcd_cur_disp_loc = LCD_BEGIN_LOC_ECHO_UART_RCVD_STR;
		Write_LCD_Command(comm_lcd_ch_id, lcd_status[comm_lcd_ch_id].lcd_cur_disp_loc);
	#endif */
	i = 0;
    data_dev_receive_oper_func =  data_ids_dev_srcs[cur_data_id].data_comm_dev_ids[i];
	while(data_dev_receive_oper_func.dev_id >= BEGIN_COMM_DEV_ID && data_dev_receive_oper_func.dev_id <= END_COMM_DEV_ID && i < MAX_DATA_COMM_DEVS)
	{
	   if(Dev_Oper_Func_Table[data_dev_receive_oper_func.dev_id].Dev_Receive_Func_Ptr != NULL_PTR)
	   {
	 	   ret_status = (*Dev_Oper_Func_Table[data_dev_receive_oper_func.dev_id].Dev_Receive_Func_Ptr)(data_dev_receive_oper_func.dev_ch_id, &received_char);
	      switch(ret_status)
          {
           case COMM_RCVD_CHAR:
           case COMM_NO_RCV_CHAR:
           case ERR_CUR_DATA_ID_DEV_DISABLED: 
           case ERR_CUR_DATA_ID_DEV_NO_ACCESS: 
           break;           
           default: 
               error_flag = ERR_DEV_OPER_RECEIVE_FUNC;
			   return error_flag;
         }	      
          ret_status = Dev_Oper_Read_Status_Proc(ret_status, received_char);    
		  switch(ret_status)
		  {
			  case ERR_DEV_OPER_READ_FUNC:
			    error_flag = ret_status;
              case CUR_DATA_ID_COMPLETE_READ_AND_READY_PROCESS:
			     return ret_status;
			  //break;	
		  }         		  
	   }
	   else
	   {
	      error_flag = ERR_NULL_PTR;
          return error_flag;
	   }
	   ++i;
	   data_dev_receive_oper_func =  data_ids_dev_srcs[cur_data_id].data_comm_dev_ids[i];
	}
	return ret_status;	
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
